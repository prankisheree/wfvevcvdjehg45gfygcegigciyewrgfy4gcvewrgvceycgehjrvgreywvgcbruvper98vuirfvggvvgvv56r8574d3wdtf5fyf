/** @format
 *
 * Fuego By Painfuego
 * Version: 6.0.0-beta
 * © 2024 1sT-Services
 */

const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: "membercount",
  aliases: ["mc"],
  cooldown: "",
  category: "utilities",
  usage: "",
  description: "Displays detailed member statistics of the server",
  args: false,
  vote: false,
  new: false,
  admin: false,
  owner: false,
  botPerms: [],
  userPerms: [],
  player: false,
  queue: false,
  inVoiceChannel: false,
  sameVoiceChannel: false,
  execute: async (client, message, args, emoji = {}) => {
    try {
      // Provide default values for emojis if not defined
      const onlineEmoji = emoji.online || "<:emoji_51:1333314077199433789>";
      const idleEmoji = emoji.idle || "<:emoji_52:1333314093205160026>";
      const dndEmoji = emoji.dnd || "<:emoji_54:1333314113115390043>";
      const offlineEmoji = emoji.offline || "<:emoji_55:1333314875274956800>";
      const botEmoji = emoji.bot || "<:emoji_49:1333314026566062141>";
      const voiceEmoji = emoji.voice || "<:emoji_50:1333314060997099580>";
      const membersEmoji = emoji.members || "<:emoji_49:1333314042852544582>";

      const guild = message.guild;

      // Ensure members are fetched for accurate counting
      await guild.members.fetch();

      // Count members based on their presence status
      const totalMembers = guild.memberCount;
      const bots = guild.members.cache.filter(m => m.user.bot).size;
      const humans = totalMembers - bots;

      const onlineMembers = guild.members.cache.filter(m => m.presence?.status === 'online' && !m.user.bot).size;
      const idleMembers = guild.members.cache.filter(m => m.presence?.status === 'idle' && !m.user.bot).size;
      const dndMembers = guild.members.cache.filter(m => m.presence?.status === 'dnd' && !m.user.bot).size;
      const offlineMembers = humans - (onlineMembers + idleMembers + dndMembers);
      const voiceMembers = guild.members.cache.filter(m => m.voice.channel).size;

      // Create embed message
      const embed = new EmbedBuilder()
        .setTitle(`${guild.name} Member Statistics`)
        .setDescription(
          `> ${membersEmoji} **Total Members:** \`${totalMembers}\`\n` +
          `> ${botEmoji} **Bots:** \`${bots}\`\n` +
          `> ${voiceEmoji} **In Voice Channels:** \`${voiceMembers}\``
        )
        .setThumbnail(guild.iconURL({ dynamic: true }))
        .setColor("#feebce")
        

      await message.reply({ embeds: [embed] });
    } catch (error) {
      console.error("Error fetching member count:", error);
      message.reply(`${emoji.no || "<a:emoji_4:1309094791950372965>"} **An error occurred while fetching member statistics. Please try again later!**`);
    }
  },
};