/** @format

 *

 * Peak Mic Bot - dcmeafter Command

 * Version: 1.1.0

 * © 2025 1sT-Services

 */

const ms = require("ms");

module.exports = {

  name: "dcmeafter",

  aliases: ["dcafter", "disconnectme"],

  cooldown: "",

  category: "utilities",

  usage: "<time>",

  description: "Disconnects you from VC after given time",

  args: true,

  vote: false,

  new: false,

  admin: false,

  owner: false,

  botPerms: ["MoveMembers"],

  userPerms: [],

  player: false,

  queue: false,

  inVoiceChannel: true,

  sameVoiceChannel: false,

  execute: async (client, message, args) => {

    if (!client.dcTimers) client.dcTimers = new Map();

    const member = message.member;

    if (!member.voice.channel) {

      return message.reply({

        embeds: [

          new client.embed().setColor("Red").desc(

            "You're not in a voice channel!"

          ),

        ],

      });

    }

    const time = args[0];

    const msTime = ms(time);

    if (!msTime || msTime < 10000 || msTime > 43200000) {

      return message.reply({

        embeds: [

          new client.embed().setColor("Red").desc(

            `Invalid time format or out of range.\n\n**Examples:** \`10s\`, \`5m\`, \`1h\`\n**Min:** \`10s\`, **Max:** \`12h\``

          ),

        ],

      });

    }

    if (client.dcTimers.has(member.id)) {

      clearTimeout(client.dcTimers.get(member.id));

    }

    await message.reply({

      embeds: [

        new client.embed().setColor("Green").desc(

          `Alright! I will disconnect you from <#${member.voice.channel.id}> after **${time}**.`

        ),

      ],

    });

    const timeout = setTimeout(() => {

      if (member.voice.channel) {

        member.voice.disconnect().catch(() => {});

      }

      client.dcTimers.delete(member.id);

    }, msTime);

    client.dcTimers.set(member.id, timeout);

  },

};