const {

  PermissionFlagsBits,

  ActionRowBuilder,

  ButtonBuilder,

  ButtonStyle,

} = require("discord.js");

const wait = (ms) => new Promise(resolve => setTimeout(resolve, ms));

module.exports = {

  name: "nukethisserver",

  aliases: [],

  cooldown: "",

  category: "owner",

  usage: "",

  description: "A fun nuke simulation command",

  args: false,

  vote: false,

  new: true,

  admin: false,

  owner: false,

  botPerms: [],

  userPerms: [],

  inVoiceChannel: false,

  sameVoiceChannel: false,

  execute: async (client, message, args, emoji = {}) => {

    try {

      let supportServerId = "1291467490379042847"; // Support Server ID

      let allowedRoles = [

        "1335332682191736893",
         "1335340285131100334",// Admin

        "1335331984771121233", // Owner

        "1335332575073271861", // Co-Owner

        "1335332651246026782", // Manager

      ]; // Allowed roles

      emoji.no = emoji.no || "<a:emoji_4:1309094791950372965>";

      emoji.success = emoji.success || "<:emoji_1:1309093521357013022>";

      emoji.loading = "<a:emoji_14:1309920016015294555>";

      emoji.warn = "<:emoji_warn:1309900000000000000>"; // Replace with your own warning emoji

      // Permission Check

      let hasBypassRole = message.member.roles.cache.some(role => allowedRoles.includes(role.id));

      const owners = client.config?.owners || ["1207080102974980136","1262140531341787307","1107521454049857627"];

      if (!hasBypassRole && !owners.includes(message.author.id)) {

        return message.reply({

          embeds: [new client.embed().desc(`${emoji.no} **You don't have permission to use this command!**`)],

        });

      }

      // Ask for confirmation

      const row1 = new ActionRowBuilder().addComponents(

        new ButtonBuilder().setCustomId("nuke_confirm").setLabel("Yes").setStyle(ButtonStyle.Danger),

        new ButtonBuilder().setCustomId("nuke_cancel").setLabel("No").setStyle(ButtonStyle.Secondary)

      );

      let msg = await message.reply({

        embeds: [new client.embed().desc(`**Are you sure you want to nuke this server?<a:emoji_4:1309094791950372965> **`)],

        components: [row1],

      });

      const collector = msg.createMessageComponentCollector({

        filter: (i) => i.user.id === message.author.id,

        time: 25000,

      });

      collector.on("collect", async (interaction) => {

        if (interaction.customId === "nuke_cancel") {

          collector.stop();

          return interaction.update({

            embeds: [new client.embed().desc(`${emoji.no} **Nuke process has been cancelled.**`)],

            components: [],

          });

        }

        if (interaction.customId === "nuke_confirm") {

          await interaction.update({

            embeds: [new client.embed().desc(`**Alright the process has been started, please wait...**`)],

            components: [],

          });

          const steps = [

            "Verifying bot permissions",

            "Bypassing server security protocols",

            "Injecting privileged/Worm roles and Bots",

            "Turning on administrator on everyone",

            "Executing final integrity verification",

          ];

          let content = steps.map(step => `**${step}** ${emoji.loading}`).join("\n");

          const statusMsg = await message.channel.send({ embeds: [new client.embed().desc(content)] });

          for (let i = 0; i < steps.length; i++) {

            await wait(2000);

            content = steps.map((step, idx) =>

              `**${step}** ${i >= idx ? emoji.success : emoji.loading}`

            ).join("\n");

            await statusMsg.edit({ embeds: [new client.embed().desc(content)] });

          }

          // Final confirmation

          const row2 = new ActionRowBuilder().addComponents(

            new ButtonBuilder().setCustomId("final_yes").setLabel("Yes").setStyle(ButtonStyle.Danger),

            new ButtonBuilder().setCustomId("final_no").setLabel("No").setStyle(ButtonStyle.Secondary)

          );

          const warnEmbed = new client.embed().desc(

            `**<a:emoji_4:1309094791950372965> Are you *really* sure you want to nuke this server?**\n\n` +

            `**The following actions will be executed:**\n` +

            `<:emoji_22:1309927196395048991> - All server roles will be deleted\n` +

            `<:emoji_22:1309927196395048991> - All channels will be removed\n` +

            `<:emoji_22:1309927196395048991> - All members will be banned\n\n` +

            `Choose wisely.`

          );

          const finalMsg = await message.channel.send({ embeds: [warnEmbed], components: [row2] });

          const finalCollector = finalMsg.createMessageComponentCollector({

            filter: (i) => i.user.id === message.author.id,

            time: 25000,

          });

          finalCollector.on("collect", async (i) => {

            if (i.customId === "final_no") {

              finalCollector.stop();

              return i.update({

                embeds: [new client.embed().desc(`${emoji.no} **Nuke process has been cancelled.**`)],

                components: [],

              });

            }

            if (i.customId === "final_yes") {

              finalCollector.stop();

              const buttonRow = new ActionRowBuilder().addComponents(

                new ButtonBuilder()

                  .setLabel("Click on this")

                  .setStyle(ButtonStyle.Link)

                  .setURL("https://youtu.be/JHSEa4twthw?si=3b9B49jLUL2rrlYe")

              );

              return i.update({

                embeds: [

                  new client.embed().desc(`**Please take a look at this before continuing <a:emoji_63:1340606133458698301> **`),

                ],

                components: [buttonRow],

              });

            }

          });

        }

      });

    } catch (err) {

      console.error("Nuke command error:", err);

      message.reply({

        embeds: [new client.embed().desc(`${emoji.no} **An error occurred during the nuke simulation. Try again later.**`)],

      });

    }

  },

};