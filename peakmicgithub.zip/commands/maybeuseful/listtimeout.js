const {

  EmbedBuilder,

  ActionRowBuilder,

  ButtonBuilder,

  ButtonStyle

} = require("discord.js");

module.exports = {

  name: "listtimeout",

  aliases: ["timeouts", "timeoutlist","lt"],

  category: "maybeuseful",

  usage: "listtimeout",

  description: "List all users who are currently timed out in the server.",

  args: false,

  botPerms: ["ModerateMembers"],

  userPerms: ["ModerateMembers"],

  execute: async (client, message) => {

    const noEmoji = "<a:emoji_4:1309094791950372965>";

    const timeEmoji = "<:emoji_61:1336350701252640899>";

    const userEmoji = "<:emoji_49:1333314042852544582>";

    try {

      const members = await message.guild.members.fetch();

      const timedOutMembers = members.filter(

        (m) => m.communicationDisabledUntilTimestamp && m.communicationDisabledUntilTimestamp > Date.now()

      );

      if (timedOutMembers.size === 0) {

        const noEmbed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **No members are currently timed out in this server.**`);

        return message.reply({ embeds: [noEmbed] });

      }

      const pages = [];

      const membersArray = Array.from(timedOutMembers.values());

      for (let i = 0; i < membersArray.length; i++) {

        const member = membersArray[i];

        const timeoutEnd = `<t:${Math.floor(member.communicationDisabledUntilTimestamp / 1000)}:R>`;

        const avatar = member.user.displayAvatarURL({ dynamic: true, size: 512 });

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setAuthor({

            name: `${member.user.tag}`,

            iconURL: avatar

          })

          .setThumbnail(avatar)

          .setTitle(" <:sed_kutta:1374662236303523840> Timed Out Member")

          .setDescription(

            `${userEmoji} **User:** ${member}\n` +

            `${timeEmoji} **Timeout Ends:** ${timeoutEnd}`

          )

          .setFooter({

            text: `Page ${i + 1} of ${membersArray.length} • Requested by ${message.author.tag}`,

            iconURL: message.author.displayAvatarURL({ dynamic: true })

          });

        pages.push(embed);

      }

      let page = 0;

      const backBtn = new ButtonBuilder()

        .setCustomId("prev")

        .setLabel("◀️")

        .setStyle(ButtonStyle.Secondary)

        .setDisabled(true);

      const nextBtn = new ButtonBuilder()

        .setCustomId("next")

        .setLabel("▶️")

        .setStyle(ButtonStyle.Secondary)

        .setDisabled(pages.length === 1);

      const row = new ActionRowBuilder().addComponents(backBtn, nextBtn);

      const msg = await message.reply({

        embeds: [pages[page]],

        components: [row]

      });

      const collector = msg.createMessageComponentCollector({

        time: 15000

      });

      collector.on("collect", async (interaction) => {

        if (interaction.user.id !== message.author.id) {

          return interaction.reply({

            content: "Only the command author can navigate!",

            ephemeral: true

          });

        }

        await interaction.deferUpdate();

        if (interaction.customId === "next") page++;

        else if (interaction.customId === "prev") page--;

        backBtn.setDisabled(page === 0);

        nextBtn.setDisabled(page === pages.length - 1);

        await msg.edit({ embeds: [pages[page]], components: [row] });

        collector.resetTimer();

      });

      collector.on("end", async () => {

        backBtn.setDisabled(true);

        nextBtn.setDisabled(true);

        await msg.edit({ components: [row] });

      });

    } catch (error) {

      console.error("Timeout List Error:", error);

      const errorEmbed = new EmbedBuilder()

        .setColor("#fb5984")

        .setDescription(

          `${noEmoji} **An error occurred while fetching timeouts. Please try again later!**`

        );

      return message.reply({ embeds: [errorEmbed] });

    }

  }

};