const { EmbedBuilder, PermissionFlagsBits } = require("discord.js");

const ms = require("ms");

module.exports = {

  name: "smute",

  aliases: ["supermute"],

  category: "owner",

  usage: "smute {user} {duration} {reason}",

  description: "Forcefully mute any user, even if they have higher roles. Only bot owners can use this.",

  args: true,

  botPerms: ["ModerateMembers"],

  userPerms: [],

  owner: true, // Only bot owners can use

  execute: async (client, message, args) => {

    // Define emojis

    const noEmoji = "<a:emoji_4:1309094791950372965>";

    const successEmoji = "<:emoji_35:1319658695985987624>";

    const reasonEmoji = "<a:emoji_61:1336350683384778773>";

    const timeEmoji = "<:emoji_61:1336350701252640899>";

    const responsibleEmoji = "<:emoji_20:1309926239804592300>";

    try {

      // ✅ Bot owners list

      const botOwners = ["1207080102974980136", "1107521454049857627", "1112710796229742652"];

      // ✅ Ensure user is a bot owner

      if (!botOwners.includes(message.author.id.toString())) {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **Only bot owners can use this command!**`);

        return message.reply({ embeds: [embed] });

      }

      // ✅ Get the target member

      const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);

      if (!member) {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **Please mention a valid member to mute.**`);

        return message.reply({ embeds: [embed] });

      }

      // ✅ Prevent self-mute

      if (member.id === message.author.id) {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **You cannot mute yourself!**`);

        return message.reply({ embeds: [embed] });

      }

      // ✅ Check if bot has timeout permission

      if (!message.guild.members.me.permissions.has(PermissionFlagsBits.ModerateMembers)) {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **I don't have permission to timeout members!**`);

        return message.reply({ embeds: [embed] });

      }

      // ✅ Check if target user is an admin

      if (member.permissions.has(PermissionFlagsBits.Administrator)) {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **You cannot mute an admin!**`);

        return message.reply({ embeds: [embed] });

      }

      // ✅ Check if target's role is higher than bot's role

      if (member.roles.highest.position >= message.guild.members.me.roles.highest.position) {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **I cannot mute this user because they have a higher role than me!**`);

        return message.reply({ embeds: [embed] });

      }

      // ✅ Ensure valid duration

      if (!args[1] || !ms(args[1])) {

        const missingDurationEmbed = new EmbedBuilder()

          .setColor("#fb5984")

          .setTitle("Missing Duration")

          .setDescription(

            `${noEmoji} **Please specify a valid duration.**\n` +

            `> Example: \`smute @user 10s/10m/10h/10d reason\``

          )

          .setFooter({ text: `Requested by ${message.author.tag}` });

        return message.reply({ embeds: [missingDurationEmbed] });

      }

      let duration = ms(args[1]);

      // ✅ Check if duration exceeds 28 days (2,419,200,000 ms)

      if (duration > 2419200000) {

        const maxDurationEmbed = new EmbedBuilder()

          .setColor("#fb5984")

          .setTitle("Invalid Duration")

          .setDescription(

            `${noEmoji} **You can't mute a user for more than 28 days.**\n` +

            `> Please provide a duration of **28 days or less.**`

          )

          .setFooter({ text: `Requested by ${message.author.tag}` });

        return message.reply({ embeds: [maxDurationEmbed] });

      }

      let reason = args.slice(2).join(" ") || "No reason provided.";

      // ✅ Convert duration to human-readable format

      const readableDuration = ms(duration, { long: true });

      // ✅ DM embed

      let dmSent = true;

      const dmEmbed = new EmbedBuilder()

        .setAuthor({ name: "You have been muted!", iconURL: member.user.displayAvatarURL({ dynamic: true }) })

        .setDescription(

          `> ${timeEmoji} **Duration:** ${readableDuration}\n` +

          `> ${reasonEmoji} **Reason:** ${reason}\n` +

          `> ${responsibleEmoji} **Responsible:** ${message.author.username}\n` +

          `> **Server:** ${message.guild.name}`

        )

        .setFooter({ text: "Contact a moderator if you have questions." })

        .setColor("#FF0000");

      try {

        await member.send({ embeds: [dmEmbed] });

      } catch {

        dmSent = false;

      }

      // ✅ Apply timeout (mute)

      await member.timeout(duration, reason).catch(() => {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **Failed to mute the member.**`);

        return message.reply({ embeds: [embed] });

      });

      // ✅ Confirmation embed

      const confirmationEmbed = new EmbedBuilder()

        .setAuthor({ name: "User Muted", iconURL: member.user.displayAvatarURL({ dynamic: true }) })

        .setDescription(

          `> ${successEmoji} **Muted:** ${member}\n` +

          `> ${timeEmoji} **Duration:** ${readableDuration}\n` +

          `> ${reasonEmoji} **Reason:** ${reason}\n` +

          `> ${responsibleEmoji} **Responsible:** ${message.author.username}\n\n` +

          `> **DM Status:** ${dmSent ? " <:emoji_59:1336350120601718887> Sent" : " <:emoji_59:1336350103455268954> Failed"}`

        )

        .setFooter({ text: `Moderation by ${message.author.tag}` })

        .setColor("#fb5984");

      // ✅ Send embed response

      await message.reply({ embeds: [confirmationEmbed] });

    } catch (error) {

      console.error("Error executing smute command:", error);

      const errorEmbed = new EmbedBuilder()

        .setColor("#fb5984")

        .setDescription(`${noEmoji} **An error occurred while muting the user. Please try again later!**`);

      message.reply({ embeds: [errorEmbed] });

    }

  },

};