/** @format
 *
 * Unban Command for Peak Mic
 * Category: Moderation
 */

const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "unban",
  aliases: [],
  category: "moderation",
  usage: "unban {userID} {reason}",
  description: "Unban a user from the server with a reason.",
  args: true,
  botPerms: ["BanMembers"],
  userPerms: ["BanMembers"],
  execute: async (client, message, args) => {
    // Define emojis
    const noEmoji = "<a:emoji_4:1309094791950372965>";
    const successEmoji = "<:emoji_35:1319658695985987624>";
    const reasonEmoji = "<a:emoji_61:1336350683384778773>";
    const responsibleEmoji = "<:emoji_20:1309926239804592300>";

    try {
      // Get the user ID
      const userID = args[0];
      if (!userID || isNaN(userID)) {
        const embed = new EmbedBuilder()
          .setColor("#fb5984")
          .setDescription(`${noEmoji} **Please provide a valid user ID to unban.**`);
        return message.reply({ embeds: [embed] });
      }

      let reason = args.slice(1).join(" ") || "No reason provided.";

      // Fetch bans and check if user is banned
      const bans = await message.guild.bans.fetch();
      const bannedUser = bans.get(userID);

      if (!bannedUser) {
        const embed = new EmbedBuilder()
          .setColor("#fb5984")
          .setDescription(`${noEmoji} **This user is not banned.**`);
        return message.reply({ embeds: [embed] });
      }

      // Unban the user
      await message.guild.members.unban(userID, reason).catch(() => {
        const embed = new EmbedBuilder()
          .setColor("#fb5984")
          .setDescription(`${noEmoji} **Failed to unban the user.**`);
        return message.reply({ embeds: [embed] });
      });

      // Confirmation embed
      const confirmationEmbed = new EmbedBuilder()
        .setAuthor({ name: "User Unbanned" })
        .setDescription(
          `> ${successEmoji} **Unbanned:** <@${userID}> (${userID})\n` +
          `> ${reasonEmoji} **Reason:** ${reason}\n` +
          `> ${responsibleEmoji} **Responsible:** ${message.author.username}`
        )
        .setFooter({ text: `Moderation by ${message.author.tag}` })
        .setColor("#fb5984");

      // Send embed response
      await message.reply({ embeds: [confirmationEmbed] });
    } catch (error) {
      console.error("Error executing unban command:", error);
      const errorEmbed = new EmbedBuilder()
        .setColor("#fb5984")
        .setDescription(`${noEmoji} **An error occurred while unbanning the user. Please try again later!**`);
      message.reply({ embeds: [errorEmbed] });
    }
  },
};