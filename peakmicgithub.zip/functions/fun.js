/** @format */

const axios = require("axios");

module.exports = async function randomNekoImage(endpoint) {

  return await axios

    .get(`https://nekos.best/api/v2/${endpoint}`)

    .then((res) => `${res.data.results[0].url}`)

}