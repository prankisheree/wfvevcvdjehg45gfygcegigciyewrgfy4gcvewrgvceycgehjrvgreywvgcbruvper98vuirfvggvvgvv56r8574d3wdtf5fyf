/** @format
 *
 * Manager By Painfuego
 * Version: 6.0.0-beta
 * © 2024 1sT-Services
 */

module.exports = (client) => {
  // Your existing functions
  client.log = (message, type = "log") => {
    return client.logger.log(message, type, client.user?.username || "Manager");
  };

  client.sleep = (t) => {
    return new Promise((r) => setTimeout(r, t));
  };

  client.send = async (user, desc) => {
    try {
      await user.send({ embeds: [new client.embed().desc(desc)] });
      console.log(`Sent message to user ${user.username}[${user.id}]`);
    } catch (error) {
      console.error(
        `Failed to send message to user ${user.username}[${user.id}]: ${error.message}`,
      );
    }
  };

  // NEW: Enhanced player getter
  client.getPlayer = async (guildId) => {
    return client.manager.players.get(guildId);
  };

  // NEW: Voice connection manager reference
  client.voiceManager = require("@functions/voiceConnectionManager");

  // NEW: Enhanced player cleanup with voice manager notification
  client.cleanupPlayer = async (guildId) => {
    const player = client.manager.players.get(guildId);
    if (player) {
      try {
        await player.destroy();
        client.voiceManager.onPlayerDestroy(guildId);
        client.log(`Cleaned up player for guild: ${guildId}`, "debug");
      } catch (error) {
        client.log(`Error cleaning up player for ${guildId}: ${error.message}`, "error");
      }
    }
  };

  // NEW: Store global client reference for voice manager
  global.client = client;

  // NEW: Voice connection status checker
  client.getVoiceStatus = () => {
    return client.voiceManager.getStatus();
  };

  // NEW: Force cleanup stale connections
  client.forceCleanupVoice = () => {
    client.voiceManager.cleanupStaleConnections(client);
  };

  // NEW: Get active voice connections count
  client.getActiveVoiceConnections = () => {
    return client.manager.players.size;
  };
};
