/** @format
 *
 * Fuego By Painfuego
 * Version: 6.0.0-beta
 * © 2024 1sT-Services
 */

module.exports = {
  name: "svrleave",
  aliases: [],
  cooldown: "",
  category: "owner",
  usage: "[server id]",
  description: "Makes the bot leave a specific server",
  args: true,
  vote: false,
  new: false,
  admin: false,
  owner: true,
  botPerms: [],
  userPerms: [],
  player: false,
  queue: false,
  inVoiceChannel: false,
  sameVoiceChannel: false,
  execute: async (client, message, args, emoji) => {
    // Check if user has permissions
    if (message.author.id !== "1207080102974980136") {
      return message.reply("<a:emoji_4:1309094791950372965> You don't have permission to use this command.");
    }

    // Validate server ID
    const serverId = args[0];
    if (!serverId) {
      return message.reply("<a:emoji_4:1309094791950372965> Please provide a valid server ID.");
    }

    // Fetch the server
    const guild = client.guilds.cache.get(serverId);
    if (!guild) {
      return message.reply("<a:emoji_4:1309094791950372965> I'm not in a server with that ID.");
    }

    try {
      // Leave the server
      await guild.leave();
      message.reply(`<:emoji_1:1309093521357013022> Successfully left the server: **${guild.name}** | \`${guild.id}\``);
    } catch (error) {
      console.error(error);
      message.reply("<a:emoji_4:1309094791950372965> Failed to leave the server. Please try again later.");
    }
  },
};