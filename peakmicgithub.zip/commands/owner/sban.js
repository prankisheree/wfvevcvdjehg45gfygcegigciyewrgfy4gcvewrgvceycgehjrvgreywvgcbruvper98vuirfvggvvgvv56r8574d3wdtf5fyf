const { EmbedBuilder, PermissionFlagsBits } = require("discord.js");

module.exports = {

  name: "sban",

  aliases: ["superban"],

  category: "owner",

  usage: "sban {user} {reason}",

  description: "Forcefully ban any user, even if they have higher roles. Only bot owners can use this.",

  args: true,

  botPerms: ["BanMembers"],

  userPerms: [],

  owner: true, // Ensures only bot owners can use this

  execute: async (client, message, args) => {

    // Define emojis

    const noEmoji = "<a:emoji_4:1309094791950372965>";

    const successEmoji = "<:emoji_35:1319658695985987624>";

    const reasonEmoji = "<a:emoji_61:1336350683384778773>";

    const responsibleEmoji = "<:emoji_20:1309926239804592300>";

    try {

      // ✅ Bot owners list (multiple allowed)

      const botOwners = ["1207080102974980136", "1107521454049857627"];

      // ✅ Ensure user is a bot owner

      if (!botOwners.includes(message.author.id.toString())) {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **Only bot owners can use this command!**`);

        return message.reply({ embeds: [embed] });

      }

      // ✅ Get the target member

      const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);

      if (!member) {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **Please mention a valid member to ban.**`);

        return message.reply({ embeds: [embed] });

      }

      // ✅ Prevent self-ban

      if (member.id === message.author.id) {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **You cannot ban yourself!**`);

        return message.reply({ embeds: [embed] });

      }

      // ✅ Check if bot has ban permission

      if (!message.guild.members.me.permissions.has(PermissionFlagsBits.BanMembers)) {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **I don't have permission to ban members!**`);

        return message.reply({ embeds: [embed] });

      }

      // ✅ Check if target's role is higher than bot's role

      if (member.roles.highest.position >= message.guild.members.me.roles.highest.position) {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **I cannot ban this user because they have a higher role than me!**`);

        return message.reply({ embeds: [embed] });

      }

      let reason = args.slice(1).join(" ") || "No reason provided.";

      // ✅ DM embed

      let dmSent = true;

      const dmEmbed = new EmbedBuilder()

        .setAuthor({ name: "You have been banned!", iconURL: member.user.displayAvatarURL({ dynamic: true }) })

        .setDescription(

          `> ${reasonEmoji} **Reason:** ${reason}\n` +

          `> ${responsibleEmoji} **Responsible:** ${message.author.username}\n` +

          `> **Server:** ${message.guild.name}`

        )

        .setFooter({ text: "Contact a moderator if you have questions." })

        .setColor("#FF0000");

      try {

        await member.send({ embeds: [dmEmbed] });

      } catch {

        dmSent = false;

      }

      // ✅ Ban the user

      await member.ban({ reason }).catch(() => {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **Failed to ban the member.**`);

        return message.reply({ embeds: [embed] });

      });

      // ✅ Confirmation embed

      const confirmationEmbed = new EmbedBuilder()

        .setAuthor({ name: "User Banned", iconURL: member.user.displayAvatarURL({ dynamic: true }) })

        .setDescription(

          `> ${successEmoji} **Banned:** ${member}\n` +

          `> ${reasonEmoji} **Reason:** ${reason}\n` +

          `> ${responsibleEmoji} **Responsible:** ${message.author.username}\n\n` +

          `> **DM Status:** ${dmSent ? " <:emoji_59:1336350120601718887> Sent" : " <:emoji_59:1336350103455268954> Failed"}`

        )

        .setFooter({ text: `Moderation by ${message.author.tag}` })

        .setColor("#fb5984");

      // ✅ Send embed response

      await message.reply({ embeds: [confirmationEmbed] });

    } catch (error) {

      console.error("Error executing sban command:", error);

      const errorEmbed = new EmbedBuilder()

        .setColor("#fb5984")

        .setDescription(`${noEmoji} **An error occurred while banning the user. Please try again later!**`);

      message.reply({ embeds: [errorEmbed] });

    }

  },

};