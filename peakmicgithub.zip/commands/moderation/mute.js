/** @format

Mute Command for Peak Mic

Category: Moderation

*/

const { EmbedBuilder } = require("discord.js");

const ms = require("ms");

module.exports = {

name: "mute",

aliases: ["timeout"],

category: "moderation",

usage: "mute {user} {duration} {reason}",

description: "Mute a user for a specified duration with a reason.",

args: true,

botPerms: ["ModerateMembers"],

userPerms: ["ModerateMembers"],

execute: async (client, message, args) => {

// Define emojis

const noEmoji = "<a:emoji_4:1309094791950372965>";

const dmSentEmoji = "<:emoji_59:1336350120601718887>";

const dmFailedEmoji = "<:emoji_59:1336350103455268954>";

const reasonEmoji = "<a:emoji_61:1336350683384778773>";

const timeEmoji = "<:emoji_61:1336350701252640899>";

const responsibleEmoji = "<:emoji_20:1309926239804592300>";

const successEmoji = "<:emoji_35:1319658695985987624>";

try {

  // Get the target member

  const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);

  if (!member) {

    const embed = new EmbedBuilder()

      .setColor("#fb5984")

      .setDescription(`${noEmoji} **Please mention a valid member to mute.**`);

    return message.reply({ embeds: [embed] });

  }

  // Check role hierarchy

  if (member.roles.highest.position >= message.member.roles.highest.position) {

    const embed = new EmbedBuilder()

      .setColor("#fb5984")

      .setDescription(`${noEmoji} **You cannot mute this member.**`);

    return message.reply({ embeds: [embed] });

  }

  if (!member.moderatable) {

    const embed = new EmbedBuilder()

      .setColor("#fb5984")

      .setDescription(`${noEmoji} **I don't have permission to mute this member.**`);

    return message.reply({ embeds: [embed] });

  }

  // Ensure duration is provided

  if (!args[1] || !ms(args[1])) {

    const missingDurationEmbed = new EmbedBuilder()

      .setColor("#fb5984")

      .setTitle("Missing Duration")

      .setDescription(

        `${noEmoji} **Please specify a valid duration.**\n` +

        `> Example: \`mute @user 10s/10m/10h/10d reason\``

      )

      .setFooter({ text: `Requested by ${message.author.tag}` });

    return message.reply({ embeds: [missingDurationEmbed] });

  }

  let duration = ms(args[1]);

  // Check if duration exceeds 28 days (2,419,200,000 ms)

  if (duration > 2419200000) {

    const maxDurationEmbed = new EmbedBuilder()

      .setColor("#fb5984")

      .setTitle("Invalid Duration")

      .setDescription(

        `${noEmoji} **You can't mute a user for more than 28 days.**\n` +

        `> Please provide a duration of **28 days or less.**`

      )

      .setFooter({ text: `Requested by ${message.author.tag}` });

    return message.reply({ embeds: [maxDurationEmbed] });

  }

  let reason = args.slice(2).join(" ") || "No reason provided.";

  // Convert duration to human-readable format

  const readableDuration = ms(duration, { long: true });

  // DM embed

  let dmSent = true;

  const dmEmbed = new EmbedBuilder()

    .setAuthor({ name: "You have been muted!", iconURL: member.user.displayAvatarURL({ dynamic: true }) })

    .setDescription(

      `> ${timeEmoji} **Duration:** ${readableDuration}\n` +

      `> ${reasonEmoji} **Reason:** ${reason}\n` +

      `> ${responsibleEmoji} **Responsible:** ${message.author.username}\n` +

      `> **Server:** ${message.guild.name}`

    )

    .setFooter({ text: "Contact a moderator if you have questions." })

    .setColor("#FF0000");

  try {

    await member.send({ embeds: [dmEmbed] });

  } catch {

    dmSent = false;

  }

  // Apply timeout (mute)

  await member.timeout(duration, reason).catch(() => {

    const embed = new EmbedBuilder()

      .setColor("#fb5984")

      .setDescription(`${noEmoji} **Failed to mute the member.**`);

    return message.reply({ embeds: [embed] });

  });

  // Confirmation embed

  const confirmationEmbed = new EmbedBuilder()

    .setAuthor({ name: "User Muted", iconURL: member.user.displayAvatarURL({ dynamic: true }) })

    .setDescription(

      `> ${successEmoji} **Muted:** ${member}\n` +

      `> ${timeEmoji} **Duration:** ${readableDuration}\n` +

      `> ${reasonEmoji} **Reason:** ${reason}\n` +

      `> ${responsibleEmoji} **Responsible:** ${message.author.username}\n\n` +

      `> **DM Status:** ${dmSent ? `${dmSentEmoji} Sent` : `${dmFailedEmoji} Failed`}`

    )

    .setFooter({ text: `Moderation by ${message.author.tag}` })

    .setColor("#fb5984");

  // Send embed response

  await message.reply({ embeds: [confirmationEmbed] });

} catch (error) {

  console.error("Error executing mute command:", error);

  const errorEmbed = new EmbedBuilder()

    .setColor("#fb5984")

    .setDescription(`${noEmoji} **An error occurred while muting the user. Please try again later!**`);

  message.reply({ embeds: [errorEmbed] });

}

},

};