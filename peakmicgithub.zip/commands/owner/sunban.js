const { EmbedBuilder, PermissionFlagsBits } = require("discord.js");

module.exports = {

  name: "sunban",

  aliases: ["superunban"],

  category: "owner",

  usage: "sunban {user_id} {reason}",

  description: "Forcefully unban any user. Only bot owners can use this.",

  args: true,

  botPerms: ["BanMembers"],

  userPerms: [],

  owner: true, // Ensures only bot owners can use this

  execute: async (client, message, args) => {

    // Define emojis

    const noEmoji = "<a:emoji_4:1309094791950372965>";

    const successEmoji = "<:emoji_35:1319658695985987624>";

    const reasonEmoji = "<a:emoji_61:1336350683384778773>";

    const responsibleEmoji = "<:emoji_20:1309926239804592300>";

    try {

      // ✅ Bot owners list (multiple allowed)

      const botOwners = ["1207080102974980136", "1107521454049857627", "1112710796229742652"];

      // ✅ Ensure user is a bot owner

      if (!botOwners.includes(message.author.id.toString())) {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **Only bot owners can use this command!**`);

        return message.reply({ embeds: [embed] });

      }

      // ✅ Ensure bot has unban permission

      if (!message.guild.members.me.permissions.has(PermissionFlagsBits.BanMembers)) {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **I don't have permission to unban members!**`);

        return message.reply({ embeds: [embed] });

      }

      // ✅ Get user ID

      const userId = args[0];

      if (!userId || isNaN(userId)) {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **Please provide a valid user ID to unban.**`);

        return message.reply({ embeds: [embed] });

      }

      let reason = args.slice(1).join(" ") || "No reason provided.";

      // ✅ Fetch ban list and check if user is banned

      const bans = await message.guild.bans.fetch();

      const bannedUser = bans.get(userId);

      if (!bannedUser) {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **This user is not banned!**`);

        return message.reply({ embeds: [embed] });

      }

      // ✅ Unban the user

      await message.guild.members.unban(userId, reason).catch(() => {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **Failed to unban the user.**`);

        return message.reply({ embeds: [embed] });

      });

      // ✅ Confirmation embed

      const confirmationEmbed = new EmbedBuilder()

        .setAuthor({ name: "User Unbanned", iconURL: bannedUser.user.displayAvatarURL({ dynamic: true }) })

        .setDescription(

          `> ${successEmoji} **Unbanned:** <@${userId}>\n` +

          `> ${reasonEmoji} **Reason:** ${reason}\n` +

          `> ${responsibleEmoji} **Responsible:** ${message.author.username}`

        )

        .setFooter({ text: `Moderation by ${message.author.tag}` })

        .setColor("#fb5984");

      // ✅ Send confirmation message

      await message.reply({ embeds: [confirmationEmbed] });

    } catch (error) {

      console.error("Error executing sunban command:", error);

      const errorEmbed = new EmbedBuilder()

        .setColor("#fb5984")

        .setDescription(`${noEmoji} **An error occurred while unbanning the user. Please try again later!**`);

      message.reply({ embeds: [errorEmbed] });

    }

  },

};