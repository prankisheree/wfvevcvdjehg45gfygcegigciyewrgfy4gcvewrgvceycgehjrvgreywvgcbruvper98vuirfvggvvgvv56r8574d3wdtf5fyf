/** @format
 *
 * Fuego By Painfuego
 * Version: 6.0.0-beta
 * © 2024 1sT-Services
 */

module.exports = {
  name: "voiceStateUpdate",
  run: async (client, oldState, newState) => {
    let guildId = newState.guild.id;
    
    // Enhanced handling for bot's voice state changes
    if (newState.id === client.user.id) {
      // Bot's voice state changed
      const player = client.manager.players.get(guildId);
      
      if (oldState.channelId && !newState.channelId && player) {
        // Bot was disconnected from voice channel
        client.log(`Bot disconnected from voice in guild: ${guildId}`, "warning");
        
        // Delay before cleanup to allow for reconnection attempts
        setTimeout(async () => {
          const currentPlayer = client.manager.players.get(guildId);
          const stillInVC = newState.guild.members.cache.get(client.user.id)?.voice.channelId;
          
          if (currentPlayer && !stillInVC) {
            try {
              await currentPlayer.destroy();
              client.log(`Cleaned up disconnected player for guild: ${guildId}`, "debug");
              // Notify voice manager
              if (client.voiceManager) {
                client.voiceManager.onPlayerDestroy(guildId);
              }
            } catch (error) {
              client.log(`Error cleaning up player for ${guildId}: ${error.message}`, "error");
            }
          }
        }, 10000); // 10 second delay for reconnection attempts
      }
      
      // Bot moved to a different channel
      if (oldState.channelId && newState.channelId && oldState.channelId !== newState.channelId && player) {
        client.log(`Bot moved voice channels in guild: ${guildId}`, "debug");
      }
    }
    
    // Original cleanup logic - enhanced with voice manager notification
    if (!newState.guild.members.cache.get(client.user.id).voice.channelId) {
      await client.sleep(1500);
      
      try {
        const player = await client.getPlayer(guildId);
        if (player) {
          await player.destroy();
          client.log(`Destroyed player due to voice state change in guild: ${guildId}`, "debug");
          
          // Notify voice manager
          if (client.voiceManager) {
            client.voiceManager.onPlayerDestroy(guildId);
          }
        }
      } catch (error) {
        client.log(`Error in voiceStateUpdate cleanup for ${guildId}: ${error.message}`, "error");
      }
    }
  },
};
