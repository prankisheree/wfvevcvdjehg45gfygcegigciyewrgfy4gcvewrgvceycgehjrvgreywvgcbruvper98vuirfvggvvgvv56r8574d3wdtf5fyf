/** @format
 *
 * Fuego By Painfuego
 * Version: 6.0.0-beta
 * © 2024 1sT-Services
 */

const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: "banner",
  aliases: ["getbanner"],
  cooldown: "",
  category: "utilities",
  usage: "<@user | userID>",
  description: "Displays a user's banner by mention or ID",
  args: false,
  vote: false,
  new: false,
  admin: false,
  owner: false,
  botPerms: [],
  userPerms: [],
  player: false,
  queue: false,
  inVoiceChannel: false,
  sameVoiceChannel: false,
  execute: async (client, message, args, emoji = {}) => {
    try {
      // Provide default values for emojis if not defined
      const noEmoji = emoji.no || "<a:emoji_4:1309094791950372965>";
      const dataEmoji = emoji.data || "<a:emoji_13:1309906833716150272>";
      const linkEmoji = emoji.link || "🔗";

      // Get user by mention, ID, or fallback to message author
      const userInput = args[0];
      const user =
        message.mentions.users.first() ||
        (userInput ? await client.users.fetch(userInput, { force: true }).catch(() => null) : message.author);

      if (!user) {
        return message.reply(`${noEmoji} **Invalid user ID or mention! Please provide a valid user.**`);
      }

      // Fetch the user from the Discord API to ensure banner data is up to date
      const fetchedUser = await client.users.fetch(user.id, { force: true });

      // Check if the fetched user has a banner
      const bannerURL = fetchedUser.bannerURL({ dynamic: true, size: 1024 });

      // If there's no banner URL, inform the user
      if (!bannerURL) {
        return message.reply(`${noEmoji} **This user does not have a banner!**`);
      }

      // Create the embed
      const embed = new EmbedBuilder()
        .setDescription(
          `> ${dataEmoji} - **User Banner**\n` +
          `> ${linkEmoji} - [Click here to view the banner](${bannerURL})`
        )
        .setImage(bannerURL) // Display the banner in the embed
        .setThumbnail(user.displayAvatarURL({ dynamic: true })) // Display user's avatar as thumbnail
        .setFooter({ text: "Nice Banner | Can i Download It?🥰" })
        .setColor("#fb5984");

      // Reply with the embed
      await message.reply({ embeds: [embed] }).catch(() => {});
    } catch (error) {
      console.error("Error fetching banner:", error);
      message.reply(`${emoji.no || "<a:emoji_4:1309094791950372965>"} **An error occurred while fetching the banner. Please try again later!**`);
    }
  },
};