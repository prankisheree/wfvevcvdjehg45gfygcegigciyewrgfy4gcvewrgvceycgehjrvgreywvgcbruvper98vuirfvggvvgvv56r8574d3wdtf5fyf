/** @format

 *

 * Fuego By Painfuego

 * Version: 6.0.0-beta

 * Â© 2024 1sT-Services

 */

 module.exports = {

  name: "playerDestroy",

  run: async (client, player) => {

    if (player.data.get("message")) {

      player.data.get("message").edit({

        embeds: [client.endEmbed],

        components: [],

        files: [],

      }).catch(() => {});

    }

    if (player.data.get("autoplay")) {

      try {

        player.data.delete("autoplay");

      } catch (err) {}

    }

    await client.webhooks.player.send({

      username: client.user.username,

      avatarURL: client.user.displayAvatarURL(),

      embeds: [

        new client.embed().desc(

          `**Player Destroyed** in [ ${client.guilds.cache.get(player.guildId)} ]`

        ),

      ],

    }).catch(() => {});

    
    const vc = client.guilds.cache.get(player.guildId)?.members.me?.voice?.channel;

    if (vc) {

      const status = `Peak Mic <a:emoji_63:1340606133458698301> <:emoji_57:1335528825286561822>`;

      await setVCStatus(client, vc.id, status);

    }

  },

};

async function setVCStatus(client, channelId, status) {

  try {

    if (typeof status !== "string" || status.length > 100) return false;

    const channel = client.channels.cache.get(channelId);

    if (!channel) return false;

    if (!channel.permissionsFor(client.user)?.has("ManageChannels")) return false;

    await client.rest.put(`/channels/${channel.id}/voice-status`, {

      body: { status },

    });

    return true;

  } catch (error) {

    return false;

  }

}