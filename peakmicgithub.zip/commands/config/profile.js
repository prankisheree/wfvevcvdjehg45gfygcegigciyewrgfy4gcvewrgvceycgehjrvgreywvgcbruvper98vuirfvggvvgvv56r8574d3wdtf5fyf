const { EmbedBuilder } = require("discord.js");

module.exports = {

  name: "profile",

  aliases: ["pr"],

  category: "config",

  description: "Check your profile and server perks.",

  usage: "profile",

  args: false,

  vote: false,

  admin: false,

  owner: false,

  botPerms: [],

  userPerms: [],

  player: false,

  queue: false,

  inVoiceChannel: false,

  sameVoiceChannel: false,

  execute: async (client, message, args, emoji) => {

    try {

      const [prefix, premiumUser, isDev, isAdmin] = await Promise.all([

        client.db.pfx.get(`${client.user.id}_${message.author.id}`),

        client.db.premium.get(`${client.user.id}_${message.author.id}`),

        client.owners.includes(message.author.id),

        client.admins.includes(message.author.id),

      ]);

      const supportServerId = "1291467490379042847";

      let isInSupportServer = false;

      try {

        const supportGuild = await client.guilds.fetch(supportServerId);

        const supportMember = await supportGuild.members.fetch(message.author.id).catch(() => null);

        isInSupportServer = !!supportMember;

      } catch (err) {

        console.error("Support server check failed:", err);

      }

      // Collecting badges from mutual servers

      const allTitles = new Set();

      client.guilds.cache.forEach(guild => {

        const member = guild.members.cache.get(message.author.id);

        if (!member) return;

        const roles = member.roles.cache;

        if (roles.has("1335332651246026782")) allTitles.add(`${emoji.manager} - Manager`);

        if (roles.has("1335340285131100334")) allTitles.add(`${emoji.friends} - Friends`);

        if (roles.has("1335340285131100334")) allTitles.add(`${emoji.staff} - Staff`);

        if (roles.has("1335531460962156566")) allTitles.add(`${emoji.vip} - VIP`);

        if (roles.has("1303999177423982654")) allTitles.add(`${emoji.admin} - Administrator`);

        if (roles.has("1303999099057733662")) allTitles.add(`${emoji.staff} - Moderator`);

        if (roles.has("1303999138937176155")) allTitles.add(`${emoji.premium} - Premium Subscriber`);

      });

      // Premium status

      const premiumStatus = premiumUser === true

        ? "Lifetime"

        : premiumUser

        ? `Expiring <t:${String(premiumUser).slice(0, -3)}:R>`

        : "`Not Activated`";

      // All badges

      const badges = [

        isDev ? `${emoji.dev} - Developer` : null,

        isInSupportServer ? `${emoji.supportjoined} - Support Server Member` : null,

        ...allTitles,

        `${emoji.user} - My precious user(s)`

      ].filter(Boolean).join("\n");

      // Embed

      const profileEmbed = new EmbedBuilder()

        .setAuthor({ name: "👤 Profile Overview", iconURL: client.user.displayAvatarURL() })

        .setThumbnail(message.member.displayAvatarURL())

        .setColor("#5865F2")

        .setDescription(

          `> **Prefix:** \`${prefix || "Not Set"}\`\n` +

          `> **Premium:** ${premiumStatus}\n\n` +

          `__**Acknowledgements:**__\n${badges}`

        )

        .setFooter({ text: "We hope you enjoy using Peak Mic 🚀" });

      await message.reply({ embeds: [profileEmbed] });

    } catch (err) {

      console.error("Profile command error:", err);

      message.reply({ content: "❌ An error occurred while fetching your profile." }).catch(() => {});

    }

  },

};