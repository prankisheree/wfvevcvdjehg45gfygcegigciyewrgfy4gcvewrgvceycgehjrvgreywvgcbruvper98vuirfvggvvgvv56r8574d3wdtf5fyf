/** @format
 *
 * Fuego By Painfuego
 * Version: 6.0.0-beta
 * © 2024 1sT-Services
 */

const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: "serverbanner",
  aliases: [],
  cooldown: "",
  category: "utilities",
  usage: "",
  description: "Displays the server's banner",
  args: false,
  vote: false,
  new: false,
  admin: false,
  owner: false,
  botPerms: [],
  userPerms: [],
  player: false,
  queue: false,
  inVoiceChannel: false,
  sameVoiceChannel: false,
  execute: async (client, message, args, emoji = {}) => {
    try {
      // Provide default values for emojis if not defined
      const noEmoji = emoji.no || "<a:emoji_4:1309094791950372965>";
      const dataEmoji = emoji.data || "<a:emoji_13:1309906833716150272>";
      const linkEmoji = emoji.link || "🔗";

      // Fetch the server banner URL
      const serverBannerURL = message.guild.bannerURL({ dynamic: true, size: 1024 });

      if (!serverBannerURL) {
        return message.reply(`${noEmoji} **This server does not have a banner!**`);
      }

      // Create the embed
      const embed = new EmbedBuilder()
        .setDescription(
          `> ${dataEmoji} - **Server Banner**\n` +
          `> ${linkEmoji} - [Click here to view the banner](${serverBannerURL})`
        )
        .setImage(serverBannerURL) // Display the server banner in the embed
        .setThumbnail(message.guild.iconURL({ dynamic: true })) // Display server icon as thumbnail
        .setFooter({ text: "This server banner looks impressive" })
        .setColor("#fb5984");

      // Reply with the embed
      await message.reply({ embeds: [embed] }).catch(() => {});
    } catch (error) {
      console.error("Error fetching server banner:", error);
      message.reply(`${emoji.no || "<a:emoji_4:1309094791950372965>"} **An error occurred while fetching the server banner. Please try again later!**`);
    }
  },
};