/** @format

 *

 * Peak Mic - Server Info Command

 * Version: 1.1.0

 * © 2024 Bhootiya Bangla

 */

const { EmbedBuilder } = require("discord.js");

module.exports = {

  name: "serverinfo",

  aliases: ["si"],

  cooldown: "",

  category: "utilities",

  usage: "serverinfo",

  description: "Displays detailed information about the server.",

  args: false,

  vote: false,

  new: false,

  admin: false,

  owner: false,

  botPerms: [],

  userPerms: [],

  player: false,

  queue: false,

  inVoiceChannel: false,

  sameVoiceChannel: false,

  execute: async (client, message, args, emoji = {}) => {

    try {

      const { guild } = message;

      const owner = await guild.fetchOwner();

      const rolesCount = guild.roles.cache.size;

      const emojisCount = guild.emojis.cache.size;

      const channels = {

        text: guild.channels.cache.filter(c => c.type === 0).size,

        voice: guild.channels.cache.filter(c => c.type === 2).size,

        categories: guild.channels.cache.filter(c => c.type === 4).size,

      };

      const verificationLevels = {

        0: "None",

        1: "Low",

        2: "Medium",

        3: "High",

        4: "Very High"

      };

      const embed = new EmbedBuilder()

        .setColor("#3498db")

        .setTitle(`${emoji.server || "<a:emoji_63:1340606133458698301>"} ${guild.name}'s Information`)

        .setThumbnail(guild.iconURL({ dynamic: true, size: 1024 }))

        .addFields(

          { name: `${emoji.id || "<:emoji_24:1309927239571341393>"} Server ID`, value: `\`${guild.id}\``, inline: true },

          { name: `${emoji.owner || "<:emoji_19:1309926223429898302>"} Owner`, value: `${owner.user.tag}`, inline: true },

          { name: `${emoji.members || "<:emoji_49:1333314042852544582>"} Members`, value: `${guild.memberCount}`, inline: true },

          { name: `${emoji.channels || "<:emoji_50:1333314060997099580>"} Channels`, value: `Text: ${channels.text} | Voice: ${channels.voice} | Categories: ${channels.categories}`, inline: false },

          { name: `${emoji.boost || "<:emoji_61:1368701953483473067>"} Boosts`, value: `Level ${guild.premiumTier} with ${guild.premiumSubscriptionCount} boosts`, inline: true },

          { name: `${emoji.emoji || "<:kutta:1273260251298402406>"} Emojis`, value: `${emojisCount}`, inline: true },

          { name: `${emoji.roles || "<:achabkl:1279878175958241290>"} Roles`, value: `${rolesCount}`, inline: true },

          { name: `${emoji.verif || "<:emoji_57:1333321269491269672>"} Verification`, value: `${verificationLevels[guild.verificationLevel]}`, inline: true },

          { name: `${emoji.created || "<a:emoji_48:1332570355914641499>"} Created`, value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:R>`, inline: false }

        )

        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) });

      if (guild.banner) {

        embed.setImage(guild.bannerURL({ size: 1024, dynamic: true }));

      }

      await message.reply({ embeds: [embed] });

    } catch (error) {

      console.error("Error executing serverinfo command:", error);

      message.reply(`${emoji.error || "<a:emoji_4:1309094791950372965>"} **An error occurred while fetching server information. Please try again later!**`);

    }

  },

};