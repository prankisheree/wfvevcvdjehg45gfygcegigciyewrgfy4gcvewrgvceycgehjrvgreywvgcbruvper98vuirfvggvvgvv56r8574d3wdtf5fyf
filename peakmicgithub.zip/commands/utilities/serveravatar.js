/** @format
 *
 * Fuego By Painfuego
 * Version: 6.0.0-beta
 * © 2024 1sT-Services
 */

const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: "serveravatar",
  aliases: ["servericon"],
  cooldown: "",
  category: "utilities",
  usage: "",
  description: "Displays the server's avatar",
  args: false,
  vote: false,
  new: false,
  admin: false,
  owner: false,
  botPerms: [],
  userPerms: [],
  player: false,
  queue: false,
  inVoiceChannel: false,
  sameVoiceChannel: false,
  execute: async (client, message, args, emoji = {}) => {
    try {
      // Provide default values for emojis if not defined
      const noEmoji = emoji.no || "<a:emoji_4:1309094791950372965>";
      const dataEmoji = emoji.data || "<a:emoji_13:1309906833716150272>";
      const linkEmoji = emoji.link || "🔗";

      // Fetch the server avatar URL
      const serverIconURL = message.guild.iconURL({ dynamic: true, size: 1024 });

      if (!serverIconURL) {
        return message.reply(`${noEmoji} **This server doesn't have an avatar set!**`);
      }

      // Create the embed
      const embed = new EmbedBuilder()
        .setDescription(
          `> ${dataEmoji} - **Server Avatar**\n` +
          `> ${linkEmoji} - [Click here to view the avatar](${serverIconURL})`
        )
        .setImage(serverIconURL) // Display the server avatar in the embed
        .setThumbnail(serverIconURL) // Display server avatar as thumbnail
        .setFooter({ text: "This server avatar looks amazing." })
        .setColor("#fb5984");

      // Reply with the embed
      await message.reply({ embeds: [embed] }).catch(() => {});
    } catch (error) {
      console.error("Error fetching server avatar:", error);
      message.reply(`${emoji.no || "<a:emoji_4:1309094791950372965>"} **An error occurred while fetching the server avatar. Please try again later!**`);
    }
  },
};