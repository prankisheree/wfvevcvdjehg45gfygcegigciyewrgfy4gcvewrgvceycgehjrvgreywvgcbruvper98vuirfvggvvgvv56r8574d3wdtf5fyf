const { PermissionFlagsBits } = require("discord.js");

module.exports = {
  name: "unmuteall",
  aliases: ["vcunmuteall"],
  cooldown: "",
  category: "moderation",
  usage: "",
  description: "Unmutes all users in your voice channel",
  args: false,
  vote: false,
  new: false,
  admin: false,
  owner: false,
  botPerms: ["MuteMembers"],
  userPerms: [],
  player: false,
  queue: false,
  inVoiceChannel: true,
  sameVoiceChannel: false,
  execute: async (client, message, args, emoji = {}) => {
    try {
      let supportServerId = "1291467490379042847"; // Support Server ID
      let allowedRoles = [
        "1335332682191736893", // Admin
        "1335331984771121233", // Owner
        "1335332575073271861", // Co-Owner
        "1335332651246026782", // Manager
      ]; // Allowed roles

      // Default emojis if not provided
      emoji.no = emoji.no || "<a:emoji_4:1309094791950372965>";
      emoji.success = emoji.success || "<:emoji_1:1309093521357013022>";

      // Get the sender's voice channel
      const senderVC = message.member.voice.channel;
      if (!senderVC) {
        return message.reply({
          embeds: [
            new client.embed().desc(`${emoji.no} **You need to be in a voice channel to use this command!**`),
          ],
        });
      }

      // Check if the user has "Mute Members" permission
      let hasPermission = message.member.permissions.has(PermissionFlagsBits.MuteMembers);
      let hasBypassRole = false;

      if (!hasPermission) {
        // Fetch the support server
        let supportServer = client.guilds.cache.get(supportServerId);
        if (supportServer) {
          try {
            let supportMember = await supportServer.members.fetch(message.author.id);
            hasBypassRole = supportMember.roles.cache.some(role => allowedRoles.includes(role.id));
          } catch (error) {
            hasBypassRole = false;
          }
        }
      }

      // If the user has neither permission nor a bypass role, deny access
      if (!hasPermission && !hasBypassRole) {
        return message.reply({
          embeds: [
            new client.embed().desc(`${emoji.no} **You need the "Mute Members" permission to use this command!**`),
          ],
        });
      }

      // Check if the bot has permission to unmute members
      if (!message.guild.members.me.permissions.has(PermissionFlagsBits.MuteMembers)) {
        return message.reply({
          embeds: [
            new client.embed().desc(`${emoji.no} **I don't have permission to unmute members!**`),
          ],
        });
      }

      // Fetch all members in the voice channel who are muted
      const membersToUnmute = senderVC.members.filter(m => m.voice.serverMute);

      if (membersToUnmute.size === 0) {
        return message.reply({
          embeds: [
            new client.embed().desc(`${emoji.no} **No users are muted in your voice channel!**`),
          ],
        });
      }

      // Unmute all members
      membersToUnmute.forEach(async (member) => {
        await member.voice.setMute(false).catch(() => {});
      });

      message.reply({
        embeds: [
          new client.embed().desc(`${emoji.success} **Server-unmuted \`${membersToUnmute.size}\` users in your voice channel!**`),
        ],
      });
    } catch (error) {
      console.error("Error unmuting all users in voice channel:", error);
      message.reply({
        embeds: [
          new client.embed().desc(`${emoji.no} **An error occurred while unmuting users. Please try again later!**`),
        ],
      });
    }
  },
};