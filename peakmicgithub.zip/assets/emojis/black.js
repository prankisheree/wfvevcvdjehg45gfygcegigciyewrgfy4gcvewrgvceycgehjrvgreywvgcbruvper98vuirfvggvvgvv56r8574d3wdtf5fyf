/** @format
 *
 * Fuego By Painfuego
 * Version: 6.0.0-beta
 * © 2024 1sT-Services
 */

module.exports = {
  //commands/config/247
  247: {
    247: "<:emoji_15:1309925118054629548>",
    bell: "<a:emoji_13:1309906833716150272>",
    cool: "<a:emoji_14:1309920016015294555>",
    no: "<a:emoji_5:1309094939841269760>",
    off: "<a:emoji_2:1309093853508407296>",
    on: "<a:emoji_2:1309093853508407296>",
  },
  //commands/config/buy
  buy: {
    bell: "<a:emoji_13:1309906833716150272>",
    coin: "<:emoji_12:1309541637986455552>",
    cool: "<a:emoji_14:1309920016015294555>",
    danger: "<a:emoji_4:1309094791950372965>",
    free: "<:emoji_25:1309927257925615636>",
    no: "<a:emoji_5:1309094939841269760>",
    on: "<a:emoji_2:1309093853508407296>",
    point: "<:emoji_22:1309927196395048991>",
    premium: "<:emoji_20:1309926239804592300>",
    rich: "<:emoji_19:1309926206296166562>",
    warn: "<a:emoji_4:1309094791950372965>",
  },

  //commands/config/config
  config: {
    cog: "<:emoji_26:1309927898433454080>",
    off: "<:emoji_22:1309927196395048991>",
    on: "<a:emoji_2:1309093853508407296>",
    point: "<:emoji_22:1309927196395048991>",
  },
   

  //commands/config/ignore
  ignore: {
    cog: "<:emoji_26:1309927898433454080>",
    rem: "<:emoji_22:1309927196395048991>",
    add: "<a:emoji_2:1309093853508407296>",
    point: "<:emoji_22:1309927196395048991>",
    no: "<a:emoji_5:1309094939841269760>",
    yes: "<:emoji_1:1309093521357013022>",
  },

  //commands/config/premium
  premium: {
    admin: "<:emoji_8:1309540446971887699>",
    bell: "<a:emoji_13:1309906833716150272>",
    free: "<:emoji_25:1309927257925615636>",
    rich: "<:emoji_19:1309926206296166562>",
    danger: "<a:emoji_4:1309094791950372965>",
    diamond: "<:emoji_19:1309926206296166562>",
  },

  //commands/config/prefix
  prefix: {
    bell: "<a:emoji_13:1309906833716150272>",
    cog: "<:emoji_26:1309927898433454080>",
    cool: "<a:emoji_14:1309920016015294555>",
    no: "<a:emoji_5:1309094939841269760>",
    yes: "<:emoji_1:1309093521357013022>",
  },

  //commands/config/preset
  preset: {
    cog: "<:emoji_26:1309927898433454080>",
    no: "<a:emoji_5:1309094939841269760>",
    yes: "<:emoji_1:1309093521357013022>",
  },

  //commands/config/profile
  profile: {
    coin: "<:emoji_12:1309541637986455552>",
    dev: "<:emoji_6:1309539166328979476>",
    admin: "<:emoji_8:1309540446971887699>",
     supportjoined:"<:emoji_57:1335528825286561822>",
  staff:"<:emoji_58:1335529086474256427>",
  manager:"<:emoji_35:1319658695985987624>",
  voted:"<:emoji_31:1309940852788822097>",
  vip:"<:emoji_10:1309540701771530310>",
  friends:"<:emoji_43:1322086110788059177>",
    premium: "<:emoji_10:1309540701771530310>",
    user: "<a:emoji_2:1309093853508407296>",
  },

  //commands/config/redeem
  redeem: {
    bell: "<a:emoji_13:1309906833716150272>",
    cool: "<a:emoji_14:1309920016015294555>",
    no: "<a:emoji_5:1309094939841269760>",
    on: "<:emoji_1:1309093521357013022>",
    point: "<:emoji_22:1309927196395048991>",
    premium:"<:emoji_19:1309926223429898302>",
  },

  /////////////////////////////////////////////////////

  //commands/filter/filter
  enhance: {
    bell: "<a:emoji_13:1309906833716150272>",
    cool: "<a:emoji_14:1309920016015294555>",
    yes: "<:emoji_1:1309093521357013022>",
  },

  optimize: {
    bell: "<a:emoji_13:1309906833716150272>",
    cool: "<a:emoji_14:1309920016015294555>",
    yes: "<:emoji_1:1309093521357013022>",
  },

  //commands/filter/filter
  equalizer: {
    bell: "<a:emoji_13:1309906833716150272>",
    cog: "<:emoji_26:1309927898433454080>",
    cool: "<a:emoji_14:1309920016015294555>",
    no: "<a:emoji_5:1309094939841269760>",
    yes: "<:emoji_1:1309093521357013022>",
  },

  //commands/filter/equalizer
  filter: {
    cog: "<:emoji_26:1309927898433454080>",
    cool: "<a:emoji_14:1309920016015294555>",
    no: "<a:emoji_5:1309094939841269760>",
    yes: "<:emoji_1:1309093521357013022>",
  },

  /////////////////////////////////////////////////////

  //commands/information/balance
  balance: {
    coin: "<:emoji_12:1309541637986455552>",
    danger: "<a:emoji_4:1309094791950372965>",
    free: "<:emoji_25:1309927257925615636>",
    rich: "<:emoji_19:1309926206296166562>",
  },

  //commands/information/help
  help: {
    arrow: "<:emoji_23:1309927218398367825>",
    no: "<a:emoji_5:1309094939841269760>",
    point: "<:emoji_22:1309927196395048991>",
    home: "<:emoji_25:1309927257925615636>",
    music: "<a:emoji_30:1309939554656194570>",
    maybeuseful:"<a:Prank_Mad:1378680611128082432>",
     fun:"<:sed_kutta:1374662236303523840>",
     games:"<a:emoji_63:1340606133458698301>",
    config: "<:emoji_26:1309927898433454080>",
    filter: "<:emoji_27:1309939194709413928>",
    information: "<:emoji_29:1309939443641225287>",
    utilities:"<a:emoji_37:1320275750758252584>",
    moderation:"<:emoji_57:1333321269491269672>",
    all: "<a:emoji_2:1309093853508407296>",
  },

  //commands/information/info
  info: {
    ver: "<a:emoji_2:1309093853508407296>",
    web: "<a:emoji_2:1309093853508407296>",
    partner: "<:emoji_20:1309926239804592300>",
    verified: "<:emoji_20:1309926239804592300>",
    nodejs: "<:emoji_20:1309926239804592300>",
    djs: "<:emoji_20:1309926239804592300>",
    link: "<a:emoji_2:1309093853508407296>",
    cog: "<:emoji_26:1309927898433454080>",
    dev: "<:emoji_6:1309539166328979476>",
    admin: "<:emoji_8:1309540446971887699>",
    king: "<a:emoji_7:1309539322139119626>",
    no: "<a:emoji_5:1309094939841269760>",
    dir: "<:dir:1189088959544967238>",
    lines: "<:line:1187277316154466346>",
  },

  //commands/information/invite
  invite: {
    bell: "<a:emoji_2:1309093853508407296>",
  },

  //commands/information/notice
  notice: {
    no: "<a:emoji_5:1309094939841269760>",
    yes: "<:emoji_1:1309093521357013022>",
    bug: "<a:emoji_4:1309094791950372965>",
  },

  //commands/information/ping
  ping: {
    link: "<a:emoji_2:1309093853508407296>",
    cool: "<a:emoji_14:1309920016015294555>",
    message: "<a:emoji_2:1309093853508407296>",
    data: "<:emoji_14:1309920278935113869>",
    node: "<:emoji_14:1309920278935113869>",
  },

  //commands/information/report
  report: {
    bell: "<a:emoji_13:1309906833716150272>",
    bug: "<a:emoji_4:1309094791950372965>",
    danger: "<a:emoji_4:1309094791950372965>",
    no: "<a:emoji_5:1309094939841269760>",
  },

  //commands/information/stats
  stats: {
    cool: "<a:emoji_14:1309920016015294555>",
    no: "<a:emoji_5:1309094939841269760>",
  },

  //commands/information/support
  support: {
    support: "<:emoji_14:1309920278935113869>",
  },

  //commands/information/vote
  vote: {
    vote: "<:emoji_31:1309940852788822097>",
  },

  /////////////////////////////////////////////////////

  //commands/music/autoplay
  autoplay: {
    autoplay: "<a:emoji_2:1309093853508407296>",
    bell: "<a:emoji_13:1309906833716150272>",
    cool: "<a:emoji_14:1309920016015294555>",
    no: "<a:emoji_5:1309094939841269760>",
    off: "<:emoji_1:1309093521357013022>",
    on: "<:emoji_1:1309093521357013022>",
  },

  //commands/music/clear
  clear: {
    bell: "<a:emoji_13:1309906833716150272>",
    cog: "<:emoji_26:1309927898433454080>",
    list: "<:emoji_14:1309920278935113869>",
    yes: "<:emoji_1:1309093521357013022>",
  },

  //commands/music/grab
  grab: {
    yes: "<:emoji_1:1309093521357013022>",
    no: "<a:emoji_5:1309094939841269760>",
    cool: "<a:emoji_14:1309920016015294555>",
    user: "<:emoji_25:1309927257925615636>",
  },

  //commands/music/join
  join: {
    bell: "<a:emoji_13:1309906833716150272>",
    cool: "<a:emoji_14:1309920016015294555>",
    no: "<a:emoji_5:1309094939841269760>",
    on: "<a:emoji_13:1309906833716150272>",
    warn: "<a:emoji_4:1309094791950372965>",
  },

  //commands/music/leave
  leave: {
    cool: "<a:emoji_14:1309920016015294555>",
    off: "<a:emoji_13:1309906833716150272>",
  },

  rejoin: {
    cool: "<a:emoji_14:1309920016015294555>",
    on: "<a:emoji_13:1309906833716150272>",
  },

  //commands/music/loop
  loop: {
    loop: "<a:emoji_2:1309093853508407296>",
    bell: "<a:emoji_13:1309906833716150272>",
    cool: "<a:emoji_14:1309920016015294555>",
    on: "<a:emoji_2:1309093853508407296>",
    off: "<a:emoji_2:1309093853508407296>",
    no: "<a:emoji_5:1309094939841269760>",
    queue: "<a:emoji_2:1309093853508407296>",
    track: "<a:emoji_2:1309093853508407296>",
  },

  //commands/music/nowPlaying
  nowplaying: {},

  //commands/music/pause
  pause: {
    yes: "<:emoji_1:1309093521357013022>",
    no: "<a:emoji_5:1309094939841269760>",
  },

  //commands/music/play
  play: {
    bell: "<a:emoji_13:1309906833716150272>",
    warn: "<a:emoji_4:1309094791950372965>",
    yes: "<:emoji_1:1309093521357013022>",
    no: "<a:emoji_5:1309094939841269760>",
    search: "<a:emoji_30:1309940564887736370>",
  },

  //commands/music/previous
  previous: {
    yes: "<:emoji_1:1309093521357013022>",
    no: "<a:emoji_5:1309094939841269760>",
  },

  //commands/music/queue
  queue: {
    cool: "<:emoji_14:1309920278935113869>",
  },

  //commands/music/radio
  radio: {
    cool: "<:emoji_14:1309920278935113869>",
    no: "<a:emoji_5:1309094939841269760>",
    radio: "<a:emoji_2:1309093853508407296>",
    support: "<a:emoji_2:1309093853508407296>",
    warn: "<a:emoji_4:1309094791950372965>",
    yes: "<:emoji_1:1309093521357013022>",
  },

  //commands/music/remove
  remove: {
    yes: "<:emoji_1:1309093521357013022>",
    no: "<a:emoji_5:1309094939841269760>",
  },

  //commands/music/resume
  resume: {
    yes: "<:emoji_1:1309093521357013022>",
    no: "<a:emoji_5:1309094939841269760>",
  },

  //commands/music/search
  search: {
    yes: "<:emoji_1:1309093521357013022>",
    warn: "<a:emoji_4:1309094791950372965>",
    no: "<a:emoji_5:1309094939841269760>",
    youtube: "<:emoji_16:1309925135062663240>",
    soundcloud: "<:emoji_17:1309925155665084416>",
    spotify: "<:emoji_17:1309925173310259280>",
    search: "<a:emoji_14:1309920016015294555>",
    track: "<a:emoji_2:1309093853508407296>",
  },

  //commands/music/seek
  seek: {
    bell: "<a:emoji_14:1309920016015294555>",
    yes: "<:emoji_1:1309093521357013022>",
    no: "<a:emoji_5:1309094939841269760>",
  },

  //commands/music/shuffle
  shuffle: {
    yes: "<:emoji_1:1309093521357013022>",
  },

  similar: {
    yes: "<:emoji_1:1309093521357013022>",
    warn: "<:warn:1187279948449337384>",
    no: "<a:emoji_5:1309094939841269760>",
    youtube: "<:emoji_16:1309925135062663240>",
    soundcloud: "<:emoji_17:1309925155665084416>",
    spotify: "<:emoji_17:1309925173310259280>",
    search: "<a:emoji_14:1309920016015294555>",
    track: "<a:emoji_2:1309093853508407296>",
  },

  //commands/music/skip
  skip: {
    yes: "<:emoji_1:1309093521357013022>",
    no: "<a:emoji_5:1309094939841269760>",
  },

  //commands/music/stop
  stop: {
    yes: "<:emoji_1:1309093521357013022>",
  },

  //commands/music/volume
  volume: {
    bell: "<a:emoji_13:1309906833716150272>",
    yes: "<:emoji_1:1309093521357013022>",
    no: "<a:emoji_5:1309094939841269760>",
  },

  /////////////////////////////////////////////////////

  //commands/owner/add
  add: {
    admin: "<:emoji_8:1309540446971887699>",
    bell: "<a:emoji_13:1309906833716150272>",
    no: "<a:emoji_5:1309094939841269760>",
    on: "<a:emoji_2:1309093853508407296>",
    user: "<:emoji_25:1309927257925615636>",
    yes: "<:emoji_1:1309093521357013022>",
  },

  //commands/owner/backup
  backup: {
    cool: "<a:emoji_14:1309920016015294555>",
    yes: "<:emoji_1:1309093521357013022>",
    no: "<a:emoji_5:1309094939841269760>",
  },

  //commands/owner/coin
  coin: {
    coin: "<:emoji_12:1309541637986455552>",
    yes: "<:emoji_1:1309093521357013022>",
    no: "<a:emoji_5:1309094939841269760>",
  },

  //commands/owner/list
  list: {
    bell: "<a:emoji_13:1309906833716150272>",
    no: "<a:emoji_5:1309094939841269760>",
    cool: "<:emoji_14:1309920278935113869>",
    user: "<a:emoji_2:1309093853508407296>",
    list: "<a:emoji_14:1309920016015294555>",
  },

  //commands/owner/panel
  panel: {
    cool: "<a:emoji_14:1309920016015294555>",
  },

  //commands/owner/pi
  pi: {},

  //commands/owner/reload
  reload: {},

  //commands/owner/restart
  restart: {
    bell: "<a:emoji_13:1309906833716150272>",
    cool: "<a:emoji_2:1309093853508407296>",
    no: "<a:emoji_5:1309094939841269760>",
    yes: "<:emoji_1:1309093521357013022>",
  },
  avatar: {
    yes: "<:emoji_1:1309093521357013022>",
    no:"<a:emoji_4:1309094791950372965>",
  },
   banner: {
    yes:"<:emoji_1:1309093521357013022>",
    no:"<a:emoji_4:1309094791950372965>",
  },
   checkpermisson: {
    yes:"<:emoji_1:1309093521357013022>",
    no:"<a:emoji_4:1309094791950372965>",
  },
    
  //commands/owner/revoke 
  revoke: {
    admin: "<:emoji_8:1309540446971887699>",
    bell: "<a:emoji_13:1309906833716150272>",
    no: "<a:emoji_5:1309094939841269760>",
    on: "<a:emoji_2:1309093853508407296>",
    off: "<a:emoji_2:1309093853508407296>",
    user: "<a:emoji_2:1309093853508407296>",
    yes: "<:emoji_1:1309093521357013022>",
  },

  /////////////////////////////////////////////////////

  //stat cmd (bcevl + global)
  cog: "<:emoji_14:1309920278935113869>",
  free: "<:emoji_25:1309927257925615636>",
  user: "<:emoji_25:1309927257925615636>",
  point: "<:emoji_22:1309927196395048991>",
  king: "<a:emoji_7:1309539322139119626>",
  bell: "<a:emoji_13:1309906833716150272>",
  cool: "<a:emoji_14:1309920016015294555>",
  warn: "<a:emoji_4:1309094791950372965>",
  yes: "<:emoji_1:1309093521357013022>",
  no: "<a:emoji_5:1309094939841269760>",
  helpline: "<:emoji_24:1309927239571341393>",
  supportjoined:"<:emoji_57:1335528825286561822>",
  staff:"<:emoji_58:1335529086474256427>",
  manager:"<:emoji_35:1319658695985987624>",
  voted:"<:emoji_31:1309940852788822097>",
  vip:"<:emoji_10:1309540701771530310>",
  friends:"<:emoji_43:1322086110788059177>",
  message: "<a:emoji_2:1309093853508407296>",
  free: "<:emoji_25:1309927257925615636>",
  new: "<a:emoji_2:1309093853508407296>",
  admin: "<:emoji_8:1309540446971887699>",
  rad: "<a:emoji_2:1309093853508407296>",
  diamond: "<:emoji_19:1309926206296166562>",
};
