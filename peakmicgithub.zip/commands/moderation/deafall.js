const { PermissionFlagsBits } = require("discord.js");

module.exports = {
  name: "deafall",
  aliases: ["deafenall"],
  cooldown: "",
  category: "moderation",
  usage: "",
  description: "Deafens all users in your voice channel",
  args: false,
  vote: false,
  new: false,
  admin: false,
  owner: false,
  botPerms: ["DeafenMembers"],
  userPerms: [],
  player: false,
  queue: false,
  inVoiceChannel: true,
  sameVoiceChannel: false,
  execute: async (client, message, args, emoji = {}) => {
    let supportServerId = "1291467490379042847"; // Support Server ID
    let allowedRoles = [
      "1335332682191736893", // Admin
      "1335331984771121233", // Owner
      "1335332575073271861", // Co-Owner
      "1335332651246026782", // Manager
    ];

    // Default emojis if not provided
    emoji.no = emoji.no || "<a:emoji_4:1309094791950372965>";
    emoji.success = emoji.success || "<:emoji_1:1309093521357013022>";

    // Check if user is in a voice channel
    const senderVC = message.member.voice.channel;
    if (!senderVC) {
      return message.reply({
        embeds: [new client.embed().desc(`${emoji.no} **You need to be in a voice channel to use this command!**`)],
      });
    }

    // If the user has "Deafen Members" permission in the server, allow the command
    if (!message.member.permissions.has(PermissionFlagsBits.DeafenMembers)) {
      // Check support server only if the user lacks "Deafen Members"
      let supportServer = client.guilds.cache.get(supportServerId);
      if (supportServer) {
        try {
          let supportMember = await supportServer.members.fetch(message.author.id);
          let hasBypassRole = supportMember.roles.cache.some(role => allowedRoles.includes(role.id));

          if (!hasBypassRole) {
            return message.reply({
              embeds: [new client.embed().desc(`${emoji.no} **You need the "Deafen Members" permission to use this command!**`)],
            });
          }
        } catch (error) {
          return message.reply({
            embeds: [new client.embed().desc(`${emoji.no} **You need the "Deafen Members" permission to use this command!**`)],
          });
        }
      }
    }

    // Check bot permissions
    if (!message.guild.members.me.permissions.has(PermissionFlagsBits.DeafenMembers)) {
      return message.reply({
        embeds: [new client.embed().desc(`${emoji.no} **I don't have permission to deafen members!**`)],
      });
    }

    // Fetch all members in the voice channel
    const members = senderVC.members.filter(m => !m.voice.serverDeaf && m.id !== message.author.id);

    if (members.size === 0) {
      return message.reply({
        embeds: [new client.embed().desc(`${emoji.no} **No users to deafen in your voice channel!**`)],
      });
    }

    // Deafen all members
    members.forEach(async (member) => {
      await member.voice.setDeaf(true).catch(() => {});
    });

    message.reply({
      embeds: [new client.embed().desc(`${emoji.success} **Server-deafened \`${members.size}\` users in your voice channel!**`)],
    });
  },
};