const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, ComponentType } = require('discord.js');

module.exports = {

  name: "rockpaperscissor",
  aliases:["rps"],

  category: "games",

  usage: "rps @user",
  
    
    
  

  description: "Play Rock Paper Scissors with a friend!",

  args: true,

  vote: false,

  new: false,

  admin: false,

  owner: false,

  botPerms: [],

  userPerms: [],

  execute: async (client, message, args) => {

    const challenger = message.author;

    const opponent = message.mentions.users.first();

    if (!opponent || opponent.bot || opponent.id === challenger.id) {

      return message.reply("Please mention a valid user to play against.");

    }

    const embed = new EmbedBuilder()

      .setTitle("Rock Paper Scissors Challenge!")

      .setDescription(`${opponent}, do you accept the challenge from ${challenger}?`)

      .setColor("Random");

    const row = new ActionRowBuilder().addComponents(

      new ButtonBuilder().setCustomId('accept').setLabel('Accept').setStyle(ButtonStyle.Success),

      new ButtonBuilder().setCustomId('decline').setLabel('Decline').setStyle(ButtonStyle.Danger)

    );

    const msg = await message.channel.send({ embeds: [embed], components: [row] });

    const collector = msg.createMessageComponentCollector({

      componentType: ComponentType.Button,

      time: 15000

    });

    collector.on('collect', async i => {

      if (i.user.id !== opponent.id) {

        return i.reply({ content: "You're not the challenged player.", ephemeral: true });

      }

      if (i.customId === 'decline') {

        await i.update({ content: `${opponent} declined the challenge.`, components: [], embeds: [] });

        return;

      }

      await i.update({ content: `Game starting...`, components: [], embeds: [] });

      playGame(challenger, opponent, message);

    });

    collector.on('end', collected => {

      if (collected.size === 0) {

        msg.edit({ content: "No response. Game cancelled.", components: [], embeds: [] });

      }

    });

  }

};

async function playGame(p1, p2, message) {

  const choices = ['Rock🪨', 'Paper📄', 'Scissors✂️'];

  const row1 = new ActionRowBuilder().addComponents(

    new ButtonBuilder().setCustomId('rock').setLabel('Rock').setStyle(ButtonStyle.Primary),

    new ButtonBuilder().setCustomId('paper').setLabel('Paper').setStyle(ButtonStyle.Primary),

    new ButtonBuilder().setCustomId('scissors').setLabel('Scissors').setStyle(ButtonStyle.Primary)

  );

  const msg = await message.channel.send({

    content: `${p1} and ${p2}, choose your move!`,

    components: [row1]

  });

  const moves = new Map();

  const filter = i => [p1.id, p2.id].includes(i.user.id);

  const collector = msg.createMessageComponentCollector({ filter, componentType: ComponentType.Button, time: 30000 });

  collector.on('collect', async i => {

    if (moves.has(i.user.id)) {

      return i.reply({ content: "You've already chosen.", ephemeral: true });

    }

    moves.set(i.user.id, i.customId);

    await i.reply({ content: `You chose ${i.customId}.`, ephemeral: true });

    if (moves.size === 2) {

      collector.stop();

    }

  });

  collector.on('end', async () => {

    if (moves.size < 2) {

      return msg.edit({ content: "Game cancelled due to inactivity.", components: [] });

    }

    const move1 = moves.get(p1.id);

    const move2 = moves.get(p2.id);

    let result;

    if (move1 === move2) {

      result = "It's a tie!";

    } else if (

      (move1 === 'rock' && move2 === 'scissors') ||

      (move1 === 'paper' && move2 === 'rock') ||

      (move1 === 'scissors' && move2 === 'paper')

    ) {

      result = `${p1} wins!`;

    } else {

      result = `${p2} wins!`;

    }

    await msg.edit({

      content: `**Results:**\n${p1} chose **${move1}**, ${p2} chose **${move2}**.\n\n**${result}**`,

      components: []

    });

  });

}