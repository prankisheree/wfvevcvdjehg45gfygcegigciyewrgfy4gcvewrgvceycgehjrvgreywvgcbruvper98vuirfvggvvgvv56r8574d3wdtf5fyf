const { ActionRowBuilder } = require("discord.js");

module.exports = {
  name: "guildCreate",
  run: async (client, guild) => {
    if (!guild.name) return;

    let username = "Unknown User";
    let userId = "Unknown ID";
    let userAvatar = null;
    let inviteLink = "Not Available";

    try {
      // Fetch the server owner
      const owner = await client.users.fetch(guild.ownerId);
      username = owner.tag;
      userId = owner.id;
      userAvatar = owner.displayAvatarURL({ dynamic: true });

      // Attempt to fetch an invite link if the bot has the permission
      try {
        const textChannels = guild.channels.cache.filter(
          (channel) =>
            channel.type === 0 && // Text channel type
            channel.permissionsFor(guild.members.me).has("CreateInstantInvite")
        );

        if (textChannels.size > 0) {
          const invite = await textChannels.first().createInvite({
            maxAge: 0, // Permanent invite
            maxUses: 0, // Unlimited uses
          });
          inviteLink = invite.url;
        }
      } catch (error) {
        console.error("Failed to create an invite link:", error);
      }

      // Construct the thank-you embed
      let embed = new client.embed()
        .title(`Thank you for choosing ${client.user.username}!`)
        .desc(
          `Hello \`${username}\`,\n\n` +
            `\`${client.user.username}\` has been successfully added to \`${guild.name}\`.\n` +
            `Feel free to report any issues at **[Support Server](${client.support})**.\n\n` +
            `Server invite link: [Click here](${inviteLink})`
        )
        .setFooter({ text: `Server Owner: ${username}`, iconURL: userAvatar }) // Footer includes username and avatar
        .setColor("#7ffa2d");

      // Send the thank-you message to the server owner
      await owner.send({
        embeds: [embed],
        components: [
          new ActionRowBuilder().addComponents(
            new client.button().link("Support Server", client.support),
            new client.button().link("Get Premium", client.support)
          ),
        ],
      });

      // Log the owner's information
      console.log(`Thanked User: ${username} (ID: ${userId}) for adding the bot.`);
    } catch (error) {
      console.error("Failed to send a thank-you message:", error);
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    /////////////////////////// Log the event to a webhook (optional) /////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    try {
      const guildIcon = guild.iconURL({ dynamic: true });
      await client.webhooks.server.send({
        username: client.user.username,
        avatarURL: client.user.displayAvatarURL(),
        embeds: [
          new client.embed()
            .title(`Joined a New Guild!`)
            .desc(
              `**Guild Name:** \`${guild.name}\`\n` +
                `**Guild ID:** \`${guild.id}\`\n` +
                `**Members:** \`${guild.memberCount}\`\n` +
                `**Server invite link:** [Click here](${inviteLink})`
            )
            .setThumbnail(guildIcon)
            .setFooter({
              text: `Added by: ${username}`,
              iconURL: userAvatar,
            })
            .setColor("#7ffa2d"),
        ],
      });
    } catch (error) {
      console.error("Failed to send log to webhook:", error);
    }
  },
};