/** @format
 *
 * Fuego By Painfuego
 * Version: 6.0.0-beta
 * © 2024 1sT-Services
 */

module.exports = {
  name: "guildDelete",
  run: async (client, guild) => {
    if (!guild.name) return;

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    /////////////////////////////////////// Delete 247 db entry ///////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    try {
      await client.db.pfx.delete(`${client.user.id}_${guild.id}`);
      await client.db.preset.delete(`${client.user.id}_${guild.id}`);
      await client.db.ignore.delete(`${client.user.id}_${guild.id}`);
      await client.db.premium.delete(`${client.user.id}_${guild.id}`);
      await client.db.twoFourSeven.delete(`${client.user.id}_${guild.id}`);
    } catch (err) {
      console.error("Error deleting database entries:", err);
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////// Send Leave Log to Webhook ////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////

    // Get guild icon
    const guildIcon = guild.iconURL({ dynamic: true, size: 1024 }) || null;

    // Send log to the webhook
    try {
      await client.webhooks.server.send({
        username: client.user.username,
        avatarURL: client.user.displayAvatarURL(),
        embeds: [
          new client.embed()
            .title(`Left a Guild`)
            .desc(
              `**Guild Name:** \`${guild.name}\`\n` +
                `**Guild ID:** \`${guild.id}\`\n` +
                `**Members:** \`${guild.memberCount}\``
            )
            .setThumbnail(guildIcon) // Guild icon as thumbnail
            .setFooter({
              text: `Bot has been removed.`,
              iconURL: client.user.displayAvatarURL(),
            })
            .setColor("#e63939"), // Red color for leaving
        ],
      });
    } catch (err) {
      console.error("Failed to send leave log to webhook:", err);
    }
  },
};