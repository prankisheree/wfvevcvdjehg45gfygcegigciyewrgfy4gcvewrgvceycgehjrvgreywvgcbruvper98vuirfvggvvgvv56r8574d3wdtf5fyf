/** @format

 *

 * Fuego By Painfuego

 * Version: 6.0.0-beta

 * © 2024 1sT-Services

 */

const axios = require("axios");

const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");

const MUSIXMATCH_API_KEY = "771d5d35b79464903df01f5f7f7fdc19"; // Replace with your Musixmatch API Key

const GENIUS_API_KEY = "3N428Yfjyfcwg8NvFRwFj-uAiZOun1RFog7UNVxZrQH5B6ipSqshE6hJJ4gQ5GtN"; // Replace with your Genius API Key

module.exports = {

  name: "lyrics",

  aliases: ["ly"],

  cooldown: "",

  category: "music",

  usage: "",

  description: "Shows the lyrics of the currently playing song.",

  args: false,

  vote: false,

  new: false,

  admin: false,

  owner: false,

  botPerms: [],

  userPerms: [],

  player: true,

  queue: true,

  inVoiceChannel: true,

  sameVoiceChannel: true,

  execute: async (client, message) => {

    const player = client.manager.players.get(message.guild.id);

    if (!player || !player.queue.current) {

      return message.reply({

        embeds: [new EmbedBuilder().setDescription("❌ No song is currently playing!").setColor("Red")],

      }).catch(() => {});

    }

    const songTitle = player.queue.current.title;

    const songArtist = player.queue.current.author;

    const loadingMessage = await message.reply({

      embeds: [new EmbedBuilder().setDescription("🔍 Searching for lyrics...").setColor("Yellow")],

    }).catch(() => {});

    let lyrics = await fetchLyricsFromMusixmatch(songTitle, songArtist);

    if (!lyrics) lyrics = await fetchLyricsFromBackup(songTitle, songArtist);

    if (!lyrics) lyrics = await fetchLyricsFromGenius(songTitle, songArtist);

    if (!lyrics) {

      return loadingMessage.edit({

        embeds: [new EmbedBuilder().setDescription("❌ Lyrics not found!").setColor("Red")],

      }).catch(() => {});

    }

    await displayLyrics(lyrics, message, player);

  },

};

// Fetch lyrics from Musixmatch

async function fetchLyricsFromMusixmatch(title, artist) {

  try {

    const res = await axios.get("https://api.musixmatch.com/ws/1.1/matcher.lyrics.get", {

      params: { q_track: title, q_artist: artist, apikey: MUSIXMATCH_API_KEY },

    });

    const lyrics = res.data?.message?.body?.lyrics?.lyrics_body;

    if (lyrics) return lyrics.match(/(.|[\r\n]){1,1000}/g) || []; // Split lyrics into chunks

  } catch (err) {

    console.log("Musixmatch API Error:", err.message);

  }

  return null;

}

// Backup lyrics provider (lyrics.ovh)

async function fetchLyricsFromBackup(title, artist) {

  try {

    const res = await axios.get(`https://api.lyrics.ovh/v1/${artist}/${title}`);

    const lyrics = res.data?.lyrics;

    if (lyrics) return lyrics.match(/(.|[\r\n]){1,1000}/g) || []; // Split lyrics into chunks

  } catch (err) {

    console.log("Backup API Error:", err.message);

  }

  return null;

}

// Fetch lyrics from Genius API

async function fetchLyricsFromGenius(title, artist) {

  try {

    const searchUrl = `https://api.genius.com/search?q=${encodeURIComponent(title + " " + artist)}`;

    const res = await axios.get(searchUrl, {

      headers: { Authorization: `Bearer ${GENIUS_API_KEY}` },

    });

    const hits = res.data.response.hits;

    if (hits.length === 0) return null;

    const lyricsPageUrl = hits[0].result.url;

    const lyrics = await scrapeGeniusLyrics(lyricsPageUrl);

    if (lyrics) return lyrics.match(/(.|[\r\n]){1,1000}/g) || [];

  } catch (err) {

    console.log("Genius API Error:", err.message);

  }

  return null;

}

// Scrape lyrics from Genius (requires cheerio or puppeteer)

async function scrapeGeniusLyrics(url) {

  try {

    const { data } = await axios.get(url);

    const lyrics = data.split('<div class="Lyrics__Container')[1]?.split("</div>")[0];

    if (lyrics) return lyrics.replace(/<[^>]*>/g, ""); // Remove HTML tags

  } catch (err) {

    console.log("Genius Scraping Error:", err.message);

  }

  return null;

}

// Display paginated lyrics

async function displayLyrics(lyricsArray, message, player) {

  let page = 0;

  const row = new ActionRowBuilder().addComponents(

    new ButtonBuilder().setCustomId("prev").setLabel("◀️").setStyle(ButtonStyle.Primary).setDisabled(true),

    new ButtonBuilder().setCustomId("next").setLabel("▶️").setStyle(ButtonStyle.Primary).setDisabled(lyricsArray.length === 1)

  );

  const embed = new EmbedBuilder()

    .setDescription(lyricsArray[page])

    .setColor("Green")

    .setFooter({ text: `Page ${page + 1}/${lyricsArray.length}` });

  const msg = await message.reply({ embeds: [embed], components: [row] });

  const filter = (i) => i.user.id === message.author.id;

  const collector = msg.createMessageComponentCollector({ filter, time: player.queue.current.length });

  collector.on("collect", async (i) => {

    if (i.customId === "prev" && page > 0) {

      page--;

    } else if (i.customId === "next" && page < lyricsArray.length - 1) {

      page++;

    }

    await i.update({

      embeds: [

        new EmbedBuilder()

          .setDescription(lyricsArray[page])

          .setColor("Green")

          .setFooter({ text: `Page ${page + 1}/${lyricsArray.length}` }),

      ],

      components: [

        new ActionRowBuilder().addComponents(

          new ButtonBuilder().setCustomId("prev").setLabel("◀️").setStyle(ButtonStyle.Primary).setDisabled(page === 0),

          new ButtonBuilder().setCustomId("next").setLabel("▶️").setStyle(ButtonStyle.Primary).setDisabled(page === lyricsArray.length - 1)

        ),

      ],

    });

  });

  collector.on("end", async () => {

    await msg.edit({ components: [] }).catch(() => {});

  });

}