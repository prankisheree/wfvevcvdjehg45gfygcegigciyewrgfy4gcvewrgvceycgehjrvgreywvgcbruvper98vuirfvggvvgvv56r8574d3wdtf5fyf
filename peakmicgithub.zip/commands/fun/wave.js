const axios = require("axios");
const randomNekoImage = require("../../functions/fun.js")

module.exports = {
  name: "wave",
  aliases: [],
  cooldown: "",
  category: "fun",
  usage: "",
  description: "wave someone",
  args: false,
  vote: false,
  new: false,
  admin: false,
  owner: false,
  botPerms: [],
  userPerms: [],
  player: false,
  queue: false,
  inVoiceChannel: false,
  sameVoiceChannel: false,
  execute: async (client, message, args, emoji) => {
      
      const id = message.mentions.users.first()?.id || args[0] || message.member.id;
    const user = await client.users.fetch(id).catch(() => null);
      
      if (!user) {
      return await message.reply({
        embeds: [
          new client.embed().desc(`${client.emoji.no} **Invalid/No User provided**`),
        ],
      });
    }

    await message.reply({
      embeds: [
        new client
          .embed()
          .desc(
            `${message.author} waved at ${message.mentions.users?.first() || "some random weirdo"}`
          )
          .setImage(await randomNekoImage("wave"))
      ]
    });
  }
}
