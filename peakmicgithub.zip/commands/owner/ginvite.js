/** @format

 *

 * Fuego By Painfuego

 * Version: 6.0.0-beta

 * © 2024 1sT-Services

 */

module.exports = {

  name: "ginvite",

  aliases: [],

  cooldown: "",

  category: "owner",

  usage: "<server_id>",

  description: "Generate an invite link from the given server ID.",

  args: true,

  vote: false,

  new: false,

  admin: false,

  owner: true,

  botPerms: ["CreateInstantInvite"],

  userPerms: [],

  player: false,

  queue: false,

  inVoiceChannel: false,

  sameVoiceChannel: false,

  execute: async (client, message, args, emoji) => {

    emoji = emoji || {

      yes: "<:emoji_1:1309093521357013022>",

      no: "<a:emoji_5:1309094939841269760>",

      cool: "<:emoji_9:1309540471042740384>",

    };

    const guildId = args[0];

    if (!guildId) {

      return message.reply({

        embeds: [new client.embed().desc(`**${emoji.no} | Please provide a valid server ID.**`)],

      });

    }

    const guild = client.guilds.cache.get(guildId);

    if (!guild) {

      return message.reply({

        embeds: [new client.embed().desc(`**${emoji.no} | I am not in a server with that ID.**`)],

      });

    }

    try {

      const channel = guild.channels.cache.find(

        (ch) => ch.type === 0 && ch.permissionsFor(guild.members.me).has("CreateInstantInvite")

      );

      if (!channel) {

        return message.reply({

          embeds: [new client.embed().desc(`**${emoji.no} | No accessible channel found to create an invite.**`)],

        });

      }

      const invite = await channel.createInvite({ maxAge: 0, maxUses: 0, unique: true });

      return message.reply({

        embeds: [new client.embed().desc(`**${emoji.yes} | Invite Created: ${invite.url}**`)],

      });

    } catch (err) {

      return message.reply({

        embeds: [new client.embed().desc(`**${emoji.no} | Failed to create invite.\n\`\`\`${err.message}\`\`\`**`)],

      });

    }

  },

};