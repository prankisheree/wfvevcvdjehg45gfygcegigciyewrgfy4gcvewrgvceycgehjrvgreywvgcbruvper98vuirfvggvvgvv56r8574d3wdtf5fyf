const { RateLimitManager } = require("@sapphire/ratelimits");

const adCooldownManager = new RateLimitManager(600000);

module.exports = {

  name: "playerStart",

  run: async (client, player, track) => {

    if (!track?.title) return;

    const premium = await client.db.premium.get(`${client.user.id}_${player.guildId}`);

    const path =

      (await client.db.preset.get(`${client.user.id}_${player.guildId}`)) ||

      `embeds/embed3.js`;

    let requester = track?.requester;

    const data = await require(`@presets/${path}`)(

      {

        title: track?.title.replace(/[^a-zA-Z0-9\s]/g, "").substring(0, 25) || "Something Good",

        author: track?.author.replace(/[^a-zA-Z0-9\s]/g, "").substring(0, 20) || "PeakMic",

        duration: track?.isStream

          ? "● LIVE"

          : client.formatTime(player.queue?.current?.length) || "06:09",

        thumbnail: track?.thumbnail || client.user.displayAvatarURL().replace("webp", "png"),

        color: client.color || "#FFFFFF",

        progress: Math.floor(Math.random() * 60) + 10 || 70,

        source: track?.sourceName,

        requester: requester,

      },

      client,

      player

    );

    await player.data.set("autoplaySystem", track);

    const ad = new client.embed()

      .desc(

        `Sponsored content [ Ends in 10s ]\n` +

        `**Want your server's AD here ? Join [Support Server](${client.support})**`

      )

      .img("https://cdn.discordapp.com/attachments/1351366361586073600/1409100560971337779/peak.png?ex=68ac26a9&is=68aad529&hm=0a228f17fdc54232cb5b59b194d8de85114bb122d7e376a3a62bead5f8e4a648&")

      .setFooter({

        text: `Its the sponsors that help us keep our services free for the users.`,

      });

    let channel = await client.channels.cache.get(player.textId);

    const adCooldownBucket = adCooldownManager.acquire(`${player.guildId}`);

    if (!adCooldownBucket.limited && !premium) {

      await channel?.send({ embeds: [ad] })

        .then((m) =>

          setTimeout(async () => {

            await m.delete().catch(() => {});

          }, 60000)

        )

        .catch(() => {});

      try {

        adCooldownBucket.consume();

      } catch (e) {}

    }

    const msg = await channel

      ?.send({

        embeds: data[0],

        files: data[1],

        components: data[2],

      })

      .catch(() => {});

    if (msg) player.data.set("message", msg);

    const vc = client.guilds.cache.get(player.guildId)?.members.me?.voice?.channel;

    if (vc) {

      const status = `♬ ** ${track.title?.substring(0, 50)} ** - ${track.author?.substring(0, 30)}`;

      const success = await setVCStatus(client, vc.id, status);

      
    }

    try {

      await client.webhooks.player.send({

        username: client.user.username,

        avatarURL: client.user.displayAvatarURL(),

        embeds: [

          new client.embed().desc(

            `**Playing** ${track?.title.replace(/[^a-zA-Z0-9\s]/g, "").substring(0, 35)} in [ ${client.guilds.cache.get(player.guildId)} ]`

          ),

        ],

      }).catch(() => {});

    } catch (e) {}

  },

};

async function setVCStatus(client, channelId, status) {

  try {

    if (typeof status !== "string" || status.length > 100) return false;

    const channel = client.channels.cache.get(channelId);

    if (!channel) return false;

    await client.rest.put(`/channels/${channel.id}/voice-status`, {

      body: { status },

    });

    return true;

  } catch (error) {

    return false;

  }

}

async function removeVCStatus(client, channelId) {

  try {

    const channel = client.channels.cache.get(channelId);

    if (!channel) return false;

    const status = "Peak Mic <a:emoji_63:1340606133458698301> <:emoji_57:1335528825286561822>";

    await client.rest.put(`/channels/${channel.id}/voice-status`, {

      body: { status },

    });

    return true;

  } catch (error) {

    return false;

  }

}