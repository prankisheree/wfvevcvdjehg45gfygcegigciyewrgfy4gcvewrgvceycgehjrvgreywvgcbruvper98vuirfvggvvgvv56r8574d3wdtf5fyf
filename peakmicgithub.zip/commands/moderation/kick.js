/** @format

 *

 * Kick Command

 * Category: Moderation

 */

const { EmbedBuilder } = require("discord.js");

module.exports = {

  name: "kick",

  aliases: [],

  category: "moderation",

  usage: "kick {user} {reason}",

  description: "Kick a user from the server with a reason.",

  args: true,

  botPerms: ["KickMembers"],

  userPerms: ["KickMembers"],

  execute: async (client, message, args) => {

    // Define emojis

    const noEmoji = "<a:emoji_4:1309094791950372965>";

    const dmSentEmoji = "<:emoji_59:1336350120601718887>";

    const dmFailedEmoji = "<:emoji_59:1336350103455268954>";

    const reasonEmoji = "<a:emoji_61:1336350683384778773>";

    const responsibleEmoji = "<:emoji_20:1309926239804592300>";

    const successEmoji = "<:emoji_35:1319658695985987624>";

    try {

      // Get the target member

      const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);

      if (!member) {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **Please mention a valid member to kick.**`);

        return message.reply({ embeds: [embed] });

      }

      // Check role hierarchy (skip if author is server owner)

      if (

        message.guild.ownerId !== message.author.id &&

        member.roles.highest.position >= message.member.roles.highest.position

      ) {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **You cannot kick this member.**`);

        return message.reply({ embeds: [embed] });

      }

      if (!member.kickable) {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **I don't have permission to kick this member.**`);

        return message.reply({ embeds: [embed] });

      }

      let reason = args.slice(1).join(" ") || "No reason provided.";

      // DM embed

      let dmSent = true;

      const dmEmbed = new EmbedBuilder()

        .setAuthor({ name: "You have been kicked!", iconURL: member.user.displayAvatarURL({ dynamic: true }) })

        .setDescription(

          `> ${reasonEmoji} **Reason:** ${reason}\n` +

          `> ${responsibleEmoji} **Responsible:** ${message.author.username}\n` +

          `> **Server:** ${message.guild.name}`

        )

        .setFooter({ text: "You can rejoin if you have an invite link." })

        .setColor("#FF0000");

      try {

        await member.send({ embeds: [dmEmbed] });

      } catch {

        dmSent = false;

      }

      // Kick the user

      await member.kick(reason).catch(() => {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **Failed to kick the member.**`);

        return message.reply({ embeds: [embed] });

      });

      // Confirmation embed

      const confirmationEmbed = new EmbedBuilder()

        .setAuthor({ name: "User Kicked", iconURL: member.user.displayAvatarURL({ dynamic: true }) })

        .setDescription(

          `> ${successEmoji} **Kicked:** ${member}\n` +

          `> ${reasonEmoji} **Reason:** ${reason}\n` +

          `> ${responsibleEmoji} **Responsible:** ${message.author.username}\n\n` +

          `> **DM Status:** ${dmSent ? `${dmSentEmoji} Sent` : `${dmFailedEmoji} Failed`}`

        )

        .setFooter({ text: `Moderation by ${message.author.tag}` })

        .setColor("#fb5984");

      // Send embed response

      await message.reply({ embeds: [confirmationEmbed] });

    } catch (error) {

      console.error("Error executing kick command:", error);

      const errorEmbed = new EmbedBuilder()

        .setColor("#fb5984")

        .setDescription(`${noEmoji} **An error occurred while kicking the user. Please try again later!**`);

      message.reply({ embeds: [errorEmbed] });

    }

  },

};