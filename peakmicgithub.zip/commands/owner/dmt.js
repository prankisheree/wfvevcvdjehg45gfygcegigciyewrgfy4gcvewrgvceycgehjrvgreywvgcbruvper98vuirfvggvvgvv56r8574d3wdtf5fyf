/** @format

 *

 * Fuego By Painfuego

 * Version: 6.0.0-beta

 * © 2024 1sT-Services

 */

module.exports = {

  name: "dmt",

  aliases: [],

  cooldown: "",

  category: "owner",

  usage: "<@user>",

  description: "Drag me to the mentioned user's VC",

  args: true,

  vote: false,

  new: false,

  admin: false,

  owner: true,

  botPerms: ["MoveMembers"],

  userPerms: [],

  player: false,

  queue: false,

  inVoiceChannel: false,

  sameVoiceChannel: false,

  execute: async (client, message, args, emoji) => {

    const member = message.mentions.members.first();

      emoji = emoji || {

  yes: "<:emoji_1:1309093521357013022> ",

  no: "<a:emoji_5:1309094939841269760>",

  cool: "<:emoji_9:1309540471042740384> ",

};
    if (!member) {

      return message.reply({

        embeds: [new client.embed().desc(`**${emoji.no} | Please mention a valid user.**`)],

      });

    }

    const targetVC = member.voice.channel;

    const authorVC = message.member.voice.channel;

    if (!targetVC) {

      return message.reply({

        embeds: [new client.embed().desc(`**${emoji.no} | The mentioned user is not in a voice channel.**`)],

      });

    }

    if (!authorVC) {

      return message.reply({

        embeds: [new client.embed().desc(`**${emoji.no} | You must be in a voice channel to use this command.**`)],

      });

    }

    try {

      await message.member.voice.setChannel(targetVC);

      return message.reply({

        embeds: [new client.embed().desc(`**${emoji.yes} | Dragged you to ${targetVC.name}.**`)],

      });

    } catch (err) {

      return message.reply({

        embeds: [new client.embed().desc(`**${emoji.no} | Failed to move you.\n\`\`\`${err.message}\`\`\`**`)],

      });

    }

  },

};