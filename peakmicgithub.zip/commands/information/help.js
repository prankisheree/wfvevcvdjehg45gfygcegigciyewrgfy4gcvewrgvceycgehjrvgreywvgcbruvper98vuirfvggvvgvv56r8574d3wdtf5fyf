// Prank xD

const genCommandList = require("@gen/commandList.js");

const { ActionRowBuilder, StringSelectMenuBuilder } = require("discord.js");

module.exports = {

  name: "help",

  aliases: ["h", "help"],

  cooldown: "",

  category: "information",

  usage: "",

  description: "Shows bot's help menu",

  args: false,

  vote: false,

  new: false,

  admin: false,

  owner: false,

  botPerms: [],

  userPerms: [],

  player: false,

  queue: false,

  inVoiceChannel: false,

  sameVoiceChannel: false,

  execute: async (client, message, args, emoji) => {

    let categories = await client.categories.filter((c) => c !== "owner");

    categories = categories.sort((a, b) => a.length - b.length);

    // Help Panel Link

    const helpLinks = `[Join Support Server](${client.support})`;

    // Home Embed

    const embed = new client.embed()

      .setTitle(`${emoji.home} Welcome to Help Panel`)

      .setDescription(`Need assistance? Use the menu below to explore commands!\n\n${helpLinks}`)

      .addFields(

        categories.map((cat) => ({

          name: `${emoji[cat]} ${cat.charAt(0).toUpperCase() + cat.slice(1)} Commands`,

          value: `> Click the dropdown to view these commands.`,

          inline: false,

        }))

      )

      .setThumbnail(client.user.displayAvatarURL())

      .setImage("https://cdn.discordapp.com/attachments/1284511185605099551/1357618127994753116/Picsart_25-01-22_12-37-08-106.png?ex=67f0dbe9&is=67ef8a69&hm=176c49ad28ad3f839823e0dca1e9846cc890c13f8e64c5e3559983f0b42700a3&")

      .setFooter({ text: "Hope you're loving it as much as we loved building it. Powered by endercloud.in" });

    // All Commands 

    let arr = [];

    for (let category of categories) {

      let cmds = client.commands.filter((cmd) => cmd.category === category);

      arr.push(cmds.map((cmd) => `\`${cmd.name}\``));

    }

    const all = new client.embed()

      .setTitle(`${emoji.all} All Commands`)

      .setDescription(

        categories

          .map((cat, i) => `__${emoji[cat]} ${cat.charAt(0).toUpperCase() + cat.slice(1)}__\n${arr[i].join(", ")}`)

          .join("\n\n")

      )

      .setImage("https://cdn.discordapp.com/attachments/1284511185605099551/1357618127994753116/Picsart_25-01-22_12-37-08-106.png?ex=67f0dbe9&is=67ef8a69&hm=176c49ad28ad3f839823e0dca1e9846cc890c13f8e64c5e3559983f0b42700a3&")

      .setFooter({ text: "Hope you're loving it as much as we loved building it. Powered by endercloud.in" });

    // Select Menu Setup

    let menu = new StringSelectMenuBuilder()

      .setCustomId("menu")

      .setPlaceholder("Select a category to explore commands...")

      .setMinValues(1)

      .setMaxValues(1)

      .addOptions([

        {

          label: "Homepage",

          value: "home",

          emoji: `${emoji.home}`,

        },

        ...categories.map((cat) => ({

          label: `${cat.charAt(0).toUpperCase() + cat.slice(1)} Commands`,

          value: cat,

          emoji: `${emoji[cat]}`,

        })),

        {

          label: "All Commands",

          value: "all",

          emoji: `${emoji.all}`,

        },

      ]);

    const selectMenu = new ActionRowBuilder().addComponents(menu);

    const m = await message.reply({ embeds: [embed], components: [selectMenu] });

    // Filter & Collector

    const filter = (interaction) => {

      if (interaction.user.id === message.author.id) return true;

      interaction.reply({

        embeds: [

          new client.embed().setDescription(`${emoji.no} Only **${message.author.tag}** can use this menu.`),

        ],

        ephemeral: true,

      });

      return false;

    };

    const collector = m.createMessageComponentCollector({

      filter,

      time: 60000,

      idle: 30000,

    });

    // Handle Menu Interaction

    collector.on("collect", async (interaction) => {

      await interaction.deferUpdate();

      const category = interaction.values[0];

      if (category === "home") {

        await m.edit({ embeds: [embed] }).catch(() => {});

      } else if (category === "all") {

        await m.edit({ embeds: [all] }).catch(() => {});

      } else {

        await m

          .edit({

            embeds: [

              new client.embed()

                .setTitle(`${emoji[category]} ${category.charAt(0).toUpperCase() + category.slice(1)} Commands`)

                .setDescription(await genCommandList(client, category))

                .setImage("https://cdn.discordapp.com/attachments/1284511185605099551/1357618127994753116/Picsart_25-01-22_12-37-08-106.png?ex=67f0dbe9&is=67ef8a69&hm=176c49ad28ad3f839823e0dca1e9846cc890c13f8e64c5e3559983f0b42700a3&")

                .setFooter({ text: "Hope you're loving it as much as we loved building it. Powered by endercloud.in" }),

            ],

          })

          .catch(() => {});

      }

    });

    collector.on("end", () => {

      m.edit({ components: [] }).catch(() => {});

    });

  },

};