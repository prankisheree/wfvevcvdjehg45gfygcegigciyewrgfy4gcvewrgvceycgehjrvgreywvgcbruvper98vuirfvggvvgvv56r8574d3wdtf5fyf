const { EmbedBuilder, PermissionFlagsBits } = require("discord.js");

module.exports = {

  name: "sremoverole",

  aliases: ["superremoverole"],

  category: "owner",

  usage: "sremoverole {user} {role ID}",

  description: "Forcefully removes a role from any user by role ID. Only bot owners can use this.",

  args: true,

  botPerms: ["ManageRoles"],

  userPerms: [],

  owner: true,

  execute: async (client, message, args) => {

    // Define emojis

    const noEmoji = "<a:emoji_4:1309094791950372965>";

    const successEmoji = "<:emoji_35:1319658695985987624>";

    const roleEmoji = "<:chudgyeguru:1357998308643045488>";

    try {

      // ✅ Bot owners list

      const botOwners = ["1207080102974980136", "1107521454049857627", "1112710796229742652"];

      // ✅ Ensure user is a bot owner

      if (!botOwners.includes(message.author.id.toString())) {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **Only bot owners can use this command!**`);

        return message.reply({ embeds: [embed] });

      }

      // ✅ Get target user

      const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);

      if (!member) {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **Please mention a valid user.**`);

        return message.reply({ embeds: [embed] });

      }

      // ✅ Get role by ID

      const roleId = args[1];

      const role = message.guild.roles.cache.get(roleId);

      if (!role) {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **No role found with the provided ID.**`);

        return message.reply({ embeds: [embed] });

      }

      // ✅ Check if member has that role

      if (!member.roles.cache.has(roleId)) {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **The user doesn't have this role.**`);

        return message.reply({ embeds: [embed] });

      }

      // ✅ Check bot role position

      const botTopRole = message.guild.members.me.roles.highest;

      if (role.position >= botTopRole.position) {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **I cannot manage this role as it is higher than or equal to my highest role.**`);

        return message.reply({ embeds: [embed] });

      }

      // ✅ Remove role

      await member.roles.remove(roleId, `Removed by ${message.author.tag}`);

      // ✅ Success embed

      const successEmbed = new EmbedBuilder()

        .setAuthor({ name: "Role Removed", iconURL: member.user.displayAvatarURL({ dynamic: true }) })

        .setDescription(

          `> ${successEmoji} **Role Removed:** \`${role.name}\` (${roleId})\n` +

          `> ${roleEmoji} **User:** ${member}\n` +

          `> **By:** ${message.author}`

        )

        .setFooter({ text: `Moderation by ${message.author.tag}` })

        .setColor("#fb5984");

      return message.reply({ embeds: [successEmbed] });

    } catch (error) {

      console.error("Error executing sremoverole command:", error);

      const errorEmbed = new EmbedBuilder()

        .setColor("#fb5984")

        .setDescription(`${noEmoji} **An error occurred while removing the role. Please try again later!**`);

      return message.reply({ embeds: [errorEmbed] });

    }

  },

};