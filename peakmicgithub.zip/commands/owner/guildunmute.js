const { EmbedBuilder } = require("discord.js");

module.exports = {

  name: "guildunmute",

  aliases: ["g-unmute", "untimeout"],

  category: "owner",

  usage: "guildunmute <server_id> <@user or user_id>",

  description: "Remove timeout from a user in a specific server. Bot owners only.",

  args: true,

  botPerms: [],

  userPerms: [],

  owner: true,

  execute: async (client, message, args) => {

    const noEmoji = "<a:emoji_4:1309094791950372965>";

    const successEmoji = "<:emoji_35:1319658695985987624>";

    const responsibleEmoji = "<:emoji_20:1309926239804592300>";

    try {

      const botOwners = ["1207080102974980136", "1107521454049857627"];

      if (!botOwners.includes(message.author.id.toString())) {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **Only bot owners can use this command!**`);

        return message.reply({ embeds: [embed] });

      }

      const [guildId, userIdOrMention] = args;

      if (!guildId || !userIdOrMention) {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **Usage: guildunmute <server_id> <@user or user_id>**`);

        return message.reply({ embeds: [embed] });

      }

      const guild = await client.guilds.fetch(guildId).catch(() => null);

      if (!guild) {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **I am not in the specified server or server not found.**`);

        return message.reply({ embeds: [embed] });

      }

      const userId = userIdOrMention.replace(/[<@!>]/g, "");

      const member = await guild.members.fetch(userId).catch(() => null);

      if (!member) {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **User not found in the specified server.**`);

        return message.reply({ embeds: [embed] });

      }

      if (!member.communicationDisabledUntilTimestamp) {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **This user is not timed out in the server.**`);

        return message.reply({ embeds: [embed] });

      }

      await member.timeout(null, `Timeout removed by bot owner ${message.author.tag}`);

      const confirmationEmbed = new EmbedBuilder()

        .setAuthor({ name: "User Untimed Out", iconURL: member.user.displayAvatarURL({ dynamic: true }) })

        .setDescription(

          `> ${successEmoji} **Unmuted:** ${member}\n` +

          `> ${responsibleEmoji} **Responsible:** ${message.author.username}\n` +

          `> **Server:** ${guild.name}`

        )

        .setFooter({ text: `Moderation by ${message.author.tag}` })

        .setColor("#fb5984");

      return message.reply({ embeds: [confirmationEmbed] });

    } catch (error) {

      console.error("Error executing guildunmute command:", error);

      const errorEmbed = new EmbedBuilder()

        .setColor("#fb5984")

        .setDescription(`${noEmoji} **An error occurred while unmuting the user. Please try again later!**`);

      return message.reply({ embeds: [errorEmbed] });

    }

  },

};