const {

  ActionRowBuilder,

  ButtonBuilder,

  ButtonStyle,

  ComponentType,

} = require("discord.js");

module.exports = {

  name: "tictactoe",

  aliases: ["ttt"],

  cooldown: "",

  category: "games",

  usage: "ttt @user",

  description: "Play Tic Tac Toe with a friend",

  args: true,

  vote: false,

  new: false,

  admin: false,

  owner: false,

  botPerms: [],

  userPerms: [],

  player: false,

  queue: false,

  inVoiceChannel: false,

  sameVoiceChannel: false,

  execute: async (client, message, args) => {

    const opponent =

      message.mentions.users.first() ||

      (await client.users.fetch(args[0]).catch(() => null));

    if (!opponent || opponent.bot || opponent.id === message.author.id)

      return message.reply({

        embeds: [

          new client.embed().desc(

            `${client.emoji.no} **Please mention a valid user to play with.**`

          ),

        ],

      });

    const players = [message.author.id, opponent.id];

    const symbols = ["❌", "⭕"];

    let board = Array(9).fill(null);

    let current = 0;

    let winner = null;

    const checkWin = () => {

      const wins = [

        [0, 1, 2],

        [3, 4, 5],

        [6, 7, 8],

        [0, 3, 6],

        [1, 4, 7],

        [2, 5, 8],

        [0, 4, 8],

        [2, 4, 6],

      ];

      return wins.find(

        ([a, b, c]) =>

          board[a] && board[a] === board[b] && board[a] === board[c]

      );

    };

    const isDraw = () => board.every((x) => x);

    const getButtons = () =>

      Array.from({ length: 3 }).map((_, r) =>

        new ActionRowBuilder().addComponents(

          ...Array.from({ length: 3 }).map((__, c) => {

            const i = r * 3 + c;

            return new ButtonBuilder()

              .setCustomId(`ttt_${i}`)

              .setLabel(board[i] ?? (i + 1).toString())

              .setStyle(board[i] ? ButtonStyle.Secondary : ButtonStyle.Primary)

              .setDisabled(!!board[i]);

          })

        )

      );

    const msg = await message.reply({

      embeds: [

        new client

          .embed()

          .desc(

            `Tic Tac Toe - ${message.author} vs ${opponent}\n**Turn:** <@${players[current]}> (${symbols[current]})`

          ),

      ],

      components: getButtons(),

    });

    const collector = msg.createMessageComponentCollector({

      componentType: ComponentType.Button,

      time: 60000, // 60 seconds

    });

    collector.on("collect", async (i) => {

      if (![players[0], players[1]].includes(i.user.id))

        return i.reply({

          content:

            "You're not part of this game. Use the command to play with a friend.",

          ephemeral: true,

        });

      if (i.user.id !== players[current])

        return i.reply({

          content: "It's not your turn!",

          ephemeral: true,

        });

      const index = parseInt(i.customId.split("_")[1]);

      if (board[index])

        return i.reply({

          content: "This cell is already taken!",

          ephemeral: true,

        });

      board[index] = symbols[current];

      const winCombo = checkWin();

      if (winCombo) {

        winner = players[current];

        collector.stop("win");

      } else if (isDraw()) {

        collector.stop("draw");

      } else {

        current = current === 0 ? 1 : 0;

        await i.update({

          embeds: [

            new client

              .embed()

              .desc(

                `Tic Tac Toe - ${message.author} vs ${opponent}\n**Turn:** <@${players[current]}> (${symbols[current]})`

              ),

          ],

          components: getButtons(),

        });

      }

    });

    collector.on("end", async (_, reason) => {

      let endText = "";

      if (reason === "win")

        endText = `Game over! <@${winner}> (${symbols[players.indexOf(winner)]}) won!`;

      else if (reason === "draw") endText = "Game ended in a draw!";

      else endText = "Game ended due to inactivity.";

      await msg.edit({

        embeds: [new client.embed().desc(endText)],

        components: getButtons().map((row) => {

          row.components.forEach((btn) => btn.setDisabled(true));

          return row;

        }),

      });

    });

  },

};