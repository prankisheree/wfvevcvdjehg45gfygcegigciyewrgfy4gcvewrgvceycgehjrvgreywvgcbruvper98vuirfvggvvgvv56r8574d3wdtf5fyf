const { ActionRowBuilder, PermissionFlagsBits } = require("discord.js");

module.exports = { 
  name: "purge", 
  aliases: [], 
  cooldown: "", 
  category: "moderation", 
  usage: "<amount>", 
  description: "Bulk delete messages", 
  args: true, 
  vote: false, 
  new: false, 
  admin: false, 
  owner: false, 
  botPerms: ["ManageMessages"], 
  userPerms: [], 
  player: false, 
  queue: false, 
  inVoiceChannel: false, 
  sameVoiceChannel: false, 
  execute: async (client, message, args, emoji = {}) => { 
    let amount = parseInt(args[0]); 
    let supportServerId = "1291467490379042847"; // Support Server ID 
    let allowedRoles = [
      "1335332682191736893", // Admin 
      "1335331984771121233", // Owner 
      "1335332575073271861", // Co-Owner 
      "1335332651246026782", // Manager 
    ]; 

    // Default emojis if not provided
    emoji.warning = emoji.warning || "<a:emoji_4:1309094791950372965>";
    emoji.no = emoji.no || "<a:emoji_5:1309094939841269760>";
    emoji.success = emoji.success || "<:emoji_1:1309093521357013022>";
    emoji.cancel = emoji.cancel || "<a:emoji_5:1309094939841269760>";
    emoji.cool = emoji.cool || "<a:emoji_13:1309906833716150272>";

    if (!amount || amount < 1 || amount > 99) {
      return message.reply({
        embeds: [
          new client.embed().desc(`${emoji.no} **Provide a number between 1 and 99!**`),
        ],
      });
    }

    // If the user has "Manage Messages" permission in the current server, allow the command
    if (!message.member.permissions.has(PermissionFlagsBits.ManageMessages)) {
      // Check support server only if the user lacks "Manage Messages"
      let supportServer = client.guilds.cache.get(supportServerId);
      if (supportServer) {
        try {
          let supportMember = await supportServer.members.fetch(message.author.id);
          let hasBypassRole = supportMember.roles.cache.some(role => allowedRoles.includes(role.id));

          if (!hasBypassRole) {
            return message.reply({
              embeds: [
                new client.embed().desc(`${emoji.no} **You need the "Manage Messages" permission to use this command!**`),
              ],
            });
          }
        } catch (error) {
          return message.reply({
            embeds: [
              new client.embed().desc(`${emoji.no} **You need the "Manage Messages" permission to use this command!**`),
            ],
          });
        }
      }
    }

    let row = new ActionRowBuilder().addComponents(
      new client.button().success("confirm", "Confirm"),
      new client.button().danger("cancel", "Cancel")
    );

    let m = await message.reply({
      embeds: [
        new client.embed().desc(`${emoji.warning} **Are you sure you want to delete \`${amount}\` messages?**`),
      ],
      components: [row],
    }).catch(() => {});

    // Delete the command message (purge {amount})
    message.delete().catch(() => {});

    const filter = async (interaction) => {
      if (interaction.user.id === message.author.id) {
        return true;
      }
      await interaction.reply({
        embeds: [new client.embed().desc(`${emoji.no} Only **${message.author.tag}** can use this`)],
        ephemeral: true,
      }).catch(() => {});
      return false;
    };

    const collector = m?.createMessageComponentCollector({
      filter: filter,
      time: 15000,
    });

    collector?.on("collect", async (interaction) => {
      if (!interaction.deferred) interaction.deferUpdate();

      if (interaction.customId === "confirm") {
        let messages = await message.channel.messages.fetch({ limit: amount + 1 });

        let filteredMessages = messages.filter(msg => msg.id !== m.id).first(amount);

        await message.channel.bulkDelete(filteredMessages, true).catch(() => {});

        let confirmMessage = await m.edit({
          embeds: [
            new client.embed().desc(`${emoji.success} **Deleted \`${filteredMessages.length}\` messages!**`),
          ],
          components: [],
        }).catch(() => {});

        setTimeout(() => {
          confirmMessage?.delete().catch(() => {});
        }, 2000); // Auto delete message after 2 seconds
      } else {
        await m.edit({
          embeds: [
            new client.embed().desc(`${emoji.cancel} **Purge cancelled!**`),
          ],
          components: [],
        }).catch(() => {});
      }
    });

    collector?.on("end", async (collected) => {
      if (collected.size == 0) {
        await m.edit({
          embeds: [
            new client.embed().desc(`${emoji.cool} **Timed out! Purge cancelled.**`),
          ],
          components: [],
        }).catch(() => {});
      }
    });
  },
};