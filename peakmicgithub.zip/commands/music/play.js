/** @format
 *
 * Fuego By Painfuego
 * Version: 6.0.0-beta
 * © 2024 1sT-Services
 */

const yt =
  /^(?:(?:(?:https?:)?\/\/)?(?:www\.)?)?(?:youtube\.com\/(?:[^\/\s]+\/\S+\/|(?:c|channel|user)\/\S+|embed\/\S+|watch\?(?=.*v=\S+)(?:\S+&)*v=\S+)|(?:youtu\.be\/\S+)|yt:\S+)$/i;

const voiceManager = require("@functions/voiceConnectionManager");

module.exports = {
  name: "play",
  aliases: ["p"],
  cooldown: "",
  category: "music",
  usage: "<uri / name / file>",
  description: "play song via query (supports Spotify, Apple Music, and YouTube Music)",
  args: false,
  vote: false,
  new: false,
  admin: false,
  owner: false,
  botPerms: ["AttachFiles"],
  userPerms: [],
  player: false,
  queue: false,
  inVoiceChannel: true,
  sameVoiceChannel: true,
  execute: async (client, message, args, emoji) => {
    const { channel } = message.member.voice;
    const file = message.attachments.first();
    let query = file ? file.url : args.join(" ");

    if (!query) {
      return await message
        .reply({
          embeds: [
            new client.embed().desc(
              `${emoji.bell} **Umm, It looks like you didn't entered any song name : \`${client.prefix}p (song name)\`**`,
            ),
          ],
        })
        .catch(() => {});
    }

    // Remove automatic music addition - let the original query be searched as-is
    // This improves search accuracy by not modifying user intent

    const loadingMessage = await message
      .reply({
        embeds: [
          new client.embed().desc(
            `${emoji.search} **Searching across platforms, please wait...**`,
          ),
        ],
      })
      .catch(() => {});

    try {
      // Check if player already exists
      let player = client.manager.players.get(message.guild.id);
      
      if (!player) {
        // Get voice manager status
        const status = voiceManager.getStatus();
        
        // Show queue status if connections are at limit
        if (status.activeConnections >= status.maxConcurrentConnections) {
          await loadingMessage.edit({
            embeds: [
              new client.embed().desc(
                `${emoji.time} **Connection queued due to high server load**\n` +
                `Queue position: **${status.queuedConnections + 1}**\n` +
                `Active connections: **${status.activeConnections}/${status.maxConcurrentConnections}**\n` +
                `Please wait...`
              ),
            ],
          }).catch(() => {});
        }

        // Request connection through voice manager
        try {
          player = await voiceManager.requestConnection(
            client,
            message.guild.id,
            channel.id,
            message.channel.id
          );
          
          client.logger.log(`Successfully connected to voice for guild ${message.guild.id}`, "debug");
          
        } catch (connectionError) {
          client.logger.log(`Voice connection failed for guild ${message.guild.id}: ${connectionError.message}`, "error");
          
          const errorEmbed = {
            embeds: [
              new client.embed().desc(
                connectionError.message.includes('timeout') 
                  ? `${emoji.no} **Connection timeout!** The server may be experiencing high load. Please try again in a few moments.`
                  : connectionError.message.includes('queue')
                  ? `${emoji.no} **Request timed out in queue.** Please try again.`
                  : `${emoji.no} **Failed to connect to voice channel.** Please try again.`
              ),
            ],
          };
          
          return loadingMessage
            ? await loadingMessage.edit(errorEmbed).catch(() => {})
            : await message.reply(errorEmbed).catch(() => {});
        }
      }

      let result;
      let searchSource = "Unknown";

      // Check if it's a direct Apple Music URL
      if (query.includes('music.apple.com')) {
        await loadingMessage.edit({
          embeds: [
            new client.embed().desc(
              `${emoji.search} **Processing Apple Music URL...**`,
            ),
          ],
        }).catch(() => {});

        result = await player.search(query, {
          requester: message.author,
        });
        searchSource = "Apple Music (Direct URL)";
      } 
      // Check if it's a direct Spotify URL
      else if (query.includes('open.spotify.com')) {
        await loadingMessage.edit({
          embeds: [
            new client.embed().desc(
              `${emoji.search} **Processing Spotify URL...**`,
            ),
          ],
        }).catch(() => {});

        result = await player.search(query, {
          requester: message.author,
        });
        searchSource = "Spotify (Direct URL)";
      }
      // Check if it's a YouTube/YouTube Music URL
      else if (query.includes('youtube.com') || query.includes('youtu.be') || query.includes('music.youtube.com')) {
        await loadingMessage.edit({
          embeds: [
            new client.embed().desc(
              `${emoji.search} **Processing YouTube URL...**`,
            ),
          ],
        }).catch(() => {});

        result = await player.search(query, {
          requester: message.author,
        });
        searchSource = "YouTube Music (Direct URL)";
      }
      // Regular search query - try platforms in order with improved accuracy
      else {
        // Try Spotify first with original query
        await loadingMessage.edit({
          embeds: [
            new client.embed().desc(
              `${emoji.search} **Searching on different platforms...**`,
            ),
          ],
        }).catch(() => {});

        result = await player.search(query, {
          requester: message.author,
          source: "spsearch:",
        });

        if (result.tracks.length) {
          searchSource = "Spotify";
        } else {
          // Try Apple Music search with original query
          await loadingMessage.edit({
            embeds: [
              new client.embed().desc(
                `${emoji.search} **Searching on different platforms...**`,
              ),
            ],
          }).catch(() => {});

          result = await player.search(query, {
            requester: message.author,
            source: "amsearch:",
          });

          if (result.tracks.length) {
            searchSource = "Apple Music";
          } else {
            // Try YouTube Music with original query first
            await loadingMessage.edit({
              embeds: [
                new client.embed().desc(
                  `${emoji.search} **Searching on different platforms...**`,
                ),
              ],
            }).catch(() => {});

            result = await player.search(query, {
              requester: message.author,
              source: "ytmsearch:",
            });

            if (result.tracks.length) {
              searchSource = "YouTube Music";
            } else {
              // Final fallback: try regular YouTube search
              await loadingMessage.edit({
                embeds: [
                  new client.embed().desc(
                    `${emoji.search} **Searching on different platforms...**`,
                  ),
                ],
              }).catch(() => {});

              result = await player.search(query, {
                requester: message.author,
                source: "ytsearch:",
              });

              if (result.tracks.length) {
                searchSource = "YouTube";
              }
            }
          }
        }
      }

      if (!result.tracks.length) {
        const noResultsEmbed = {
          embeds: [
            new client.embed().desc(`${emoji.no} **No results found for "${query}" across all platforms**\n\nTry being more specific with:\n• Artist name + song title\n• Full song name\n• Alternative spellings`),
          ],
        };
        return loadingMessage
          ? await loadingMessage.edit(noResultsEmbed).catch(() => {})
          : await message.reply(noResultsEmbed).catch(() => {});
      }

      const tracks = result.tracks;
      
      if (result.type === "PLAYLIST") {
        tracks.forEach((track) => player.queue.add(track));
      } else {
        if (tracks[0].length < 10000) {
          return await message
            .reply({
              embeds: [
                new client.embed().desc(
                  `${emoji.no} **Songs of duration less than \`30s\` cannot be played!**`,
                ),
              ],
            })
            .catch(() => {});
        }
        player.queue.add(tracks[0]);
      }

      // Create response embed (removed source indicators as requested)
      const addedEmbed =
        result.type === "PLAYLIST"
          ? {
              embeds: [
                new client.embed().desc(
                  `${emoji.yes} **Added ${tracks.length} tracks from playlist: [${result.playlistName}](${result.uri || tracks[0].uri})**`,
                ),
              ],
            }
          : {
              embeds: [
                new client.embed().desc(
                  `${emoji.yes} **Added to queue: [${tracks[0].title
                    .replace("[", "")
                    .replace("]", "")}](${tracks[0].uri})**`,
                ),
              ],
            };

      // Start playing if not already playing
      if (!player.playing && !player.paused) {
        player.play();
      }

      await loadingMessage.edit(addedEmbed).catch(() => {});

      // Log successful play command with source info
      client.logger.log(
        `Play command executed successfully for guild ${message.guild.id} - Source: ${searchSource} - Original Query: "${args.join(' ')}" - ${result.type === "PLAYLIST" ? `Playlist: ${tracks.length} tracks` : `Track: ${tracks[0].title}`}`,
        "debug"
      );

    } catch (error) {
      client.logger.log(`Play command error for guild ${message.guild.id}: ${error.message}`, "error");
      
      const errorEmbed = {
        embeds: [
          new client.embed().desc(
            `${emoji.no} **An unexpected error occurred while processing your request.**\n` +
            `Please try again. If the issue persists, contact support.`
          ),
        ],
      };
      
      return loadingMessage
        ? await loadingMessage.edit(errorEmbed).catch(() => {})
        : await message.reply(errorEmbed).catch(() => {});
    }
  },
};
