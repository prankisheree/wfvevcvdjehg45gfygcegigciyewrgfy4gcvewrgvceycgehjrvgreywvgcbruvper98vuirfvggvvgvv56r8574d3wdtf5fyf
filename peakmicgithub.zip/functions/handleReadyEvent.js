module.exports = async (client) => { 
  await client.user.setPresence({ 
    status: 'idle', 
    activities: [{ 
      name: 'Tired?', 
      type: require("discord.js").ActivityType.Streaming, 
      url: 'https://www.youtube.com/watch?v=gVKEM4K8J8A' 
    }] 
  });

  let mcount = 0;
  let gcount = client.guilds.cache.size;

  client.guilds.cache.forEach((g) => {
    mcount += g.memberCount;
  });

  let eventsSize = {};
  let commandsSize = {};
  commandsSize.slash = {};

  [
    eventsSize.client,
    eventsSize.node,
    eventsSize.player,
    eventsSize.custom,
    commandsSize.message,
  ] = await Promise.all([
    await require("@loaders/clientEvents.js")(client),
    await require("@loaders/nodeEvents")(client),
    await require("@loaders/playerEvents")(client),
    await require("@loaders/customEvents.js")(client),
    await require("@loaders/commands.js")(client),
  ]);

  client.invite = {
    required: `https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=37080065&scope=bot`,
    admin: `https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot`,
  };

  client.endEmbed = new client.embed()
    .desc(
      "**Enjoying Music with me ?**\n" +
      "If yes, Consider Joining Our Support Server Link in Bio,"
    )
    .thumb(client.user.displayAvatarURL())
    .setAuthor({
      iconURL: client.user.displayAvatarURL(),
      name: client.user.username,
    })
    .setFooter({ text: "PRANKLtd." });

  client.log(
    `Loaded \nClient: ${eventsSize.client} \nNode: ${eventsSize.node} \nPlayer: ${eventsSize.player} \nCustom: ${eventsSize.custom}`,
    "event",
  );

  client.log(`Loaded  Message: ${commandsSize.message}`, "cmd");
  client.log(`Ready for ${gcount} Servers | ${mcount} Users`, "ready");

  // Enhanced voice connection management and cleanup
  setInterval(() => {
    const voiceManager = require("@functions/voiceConnectionManager");
    const status = voiceManager.getStatus();
    
    // Log status every 5 minutes
    client.logger.log(
      `Voice Status - Active: ${status.activeConnections}/${status.maxConcurrentConnections}, Queued: ${status.queuedConnections}`,
      "debug"
    );

    // Clean up stale voice connections
    client.manager.players.forEach((player, guildId) => {
      const guild = client.guilds.cache.get(guildId);
      const botInVC = guild?.members.cache.get(client.user.id)?.voice.channelId;
      
      if (!botInVC) {
        client.logger.log(`Cleaning stale connection for guild: ${guildId}`, "debug");
        player.destroy().catch(() => {});
        voiceManager.onPlayerDestroy(guildId);
      }
    });

    // Clean up stale connections in voice manager
    voiceManager.cleanupStaleConnections(client);
    
  }, 300000); // Every 5 minutes

  // More frequent basic cleanup
  setInterval(() => {
    const voiceManager = require("@functions/voiceConnectionManager");
    
    // Check for any connections that might have been missed
    client.manager.players.forEach((player, guildId) => {
      if (!client.guilds.cache.has(guildId)) {
        // Guild no longer exists, cleanup
        player.destroy().catch(() => {});
        voiceManager.onPlayerDestroy(guildId);
      }
    });
  }, 60000); // Every minute
};
