const { EmbedBuilder, PermissionFlagsBits } = require("discord.js");

module.exports = {

  name: "skick",

  aliases: ["superkick"],

  category: "owner",

  usage: "skick {user} {reason}",

  description: "Forcefully kick any user, even if they have higher roles. Only bot owners can use this.",

  args: true,

  botPerms: ["KickMembers"],

  userPerms: [],

  owner: true, // Ensures only bot owners can use this

  execute: async (client, message, args) => {

    // Define emojis

    const noEmoji = "<a:emoji_4:1309094791950372965>";

    const successEmoji = "<:emoji_35:1319658695985987624>";

    const reasonEmoji = "<a:emoji_61:1336350683384778773>";

    const responsibleEmoji = "<:emoji_20:1309926239804592300>";

    try {

      // ✅ Bot owners list (multiple allowed)

      const botOwners = ["1207080102974980136", "1107521454049857627", "1112710796229742652"];

      // ✅ Ensure user is a bot owner

      if (!botOwners.includes(message.author.id.toString())) {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **Only bot owners can use this command!**`);

        return message.reply({ embeds: [embed] });

      }

      // ✅ Get the target member

      const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);

      if (!member) {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **Please mention a valid member to kick.**`);

        return message.reply({ embeds: [embed] });

      }

      // ✅ Check if bot has kick permission

      if (!message.guild.members.me.permissions.has(PermissionFlagsBits.KickMembers)) {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **I don't have permission to kick members!**`);

        return message.reply({ embeds: [embed] });

      }

      // ✅ Check if the target user has a higher role than the bot

      if (member.roles.highest.position >= message.guild.members.me.roles.highest.position) {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **I cannot kick this user as they have a higher role than me!**`);

        return message.reply({ embeds: [embed] });

      }

      let reason = args.slice(1).join(" ") || "No reason provided.";

      // ✅ DM embed

      let dmSent = true;

      const dmEmbed = new EmbedBuilder()

        .setAuthor({ name: "You have been kicked!", iconURL: member.user.displayAvatarURL({ dynamic: true }) })

        .setDescription(

          `> ${reasonEmoji} **Reason:** ${reason}\n` +

          `> ${responsibleEmoji} **Responsible:** ${message.author.username}\n` +

          `> **Server:** ${message.guild.name}`

        )

        .setFooter({ text: "Contact a moderator if you have questions." })

        .setColor("#FF0000");

      try {

        await member.send({ embeds: [dmEmbed] });

      } catch {

        dmSent = false;

      }

      // ✅ Kick the member

      await member.kick(reason).catch(() => {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **Failed to kick the member.**`);

        return message.reply({ embeds: [embed] });

      });

      // ✅ Confirmation embed

      const confirmationEmbed = new EmbedBuilder()

        .setAuthor({ name: "User Kicked", iconURL: member.user.displayAvatarURL({ dynamic: true }) })

        .setDescription(

          `> ${successEmoji} **Kicked:** ${member}\n` +

          `> ${reasonEmoji} **Reason:** ${reason}\n` +

          `> ${responsibleEmoji} **Responsible:** ${message.author.username}\n\n` +

          `> **DM Status:** ${dmSent ? "<:emoji_59:1336350120601718887> Sent" : "<:emoji_59:1336350103455268954> Failed"}`

        )

        .setFooter({ text: `Moderation by ${message.author.tag}` })

        .setColor("#fb5984");

      // ✅ Send confirmation message

      await message.reply({ embeds: [confirmationEmbed] });

    } catch (error) {

      console.error("Error executing skick command:", error);

      const errorEmbed = new EmbedBuilder()

        .setColor("#fb5984")

        .setDescription(`${noEmoji} **An error occurred while kicking the user. Please try again later!**`);

      message.reply({ embeds: [errorEmbed] });

    }

  },

};