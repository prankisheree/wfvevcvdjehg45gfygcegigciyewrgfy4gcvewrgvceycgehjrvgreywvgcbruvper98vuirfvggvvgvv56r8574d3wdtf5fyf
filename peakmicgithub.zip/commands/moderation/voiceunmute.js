const { PermissionFlagsBits } = require("discord.js");

module.exports = {
  name: "voiceunmute",
  aliases: ["vunmute"],
  cooldown: "",
  category: "moderation",
  usage: "{user}",
  description: "Unmutes the mentioned user in voice chat",
  args: true,
  vote: false,
  new: false,
  admin: false,
  owner: false,
  botPerms: ["MuteMembers"],
  userPerms: [],
  player: false,
  queue: false,
  inVoiceChannel: true,
  sameVoiceChannel: false,
  execute: async (client, message, args, emoji = {}) => {
    let supportServerId = "1291467490379042847"; // Support Server ID
    let allowedRoles = [
      "1335332682191736893", // Admin
      "1335331984771121233", // Owner
      "1335332575073271861", // Co-Owner
      "1335332651246026782", // Manager
    ];

    // Default emojis if not provided
    emoji.no = emoji.no || "<a:emoji_4:1309094791950372965>";
    emoji.success = emoji.success || "<:emoji_1:1309093521357013022>";

    // Check if user is in a voice channel
    const senderVC = message.member.voice.channel;
    if (!senderVC) {
      return message.reply({
        embeds: [new client.embed().desc(`${emoji.no} **You need to be in a voice channel to use this command!**`)],
      });
    }

    // Fetch the mentioned user
    let target = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
    if (!target) {
      return message.reply({
        embeds: [new client.embed().desc(`${emoji.no} **Please mention a user to voice unmute!**`)],
      });
    }

    if (!target.voice.channel || target.voice.channel.id !== senderVC.id) {
      return message.reply({
        embeds: [new client.embed().desc(`${emoji.no} **The user is not in your voice channel!**`)],
      });
    }

    // If the user has "Mute Members" permission in the server, allow the command
    if (!message.member.permissions.has(PermissionFlagsBits.MuteMembers)) {
      let supportServer = client.guilds.cache.get(supportServerId);
      if (supportServer) {
        try {
          let supportMember = await supportServer.members.fetch(message.author.id);
          let hasBypassRole = supportMember.roles.cache.some(role => allowedRoles.includes(role.id));

          if (!hasBypassRole) {
            return message.reply({
              embeds: [new client.embed().desc(`${emoji.no} **You need the "Mute Members" permission to use this command!**`)],
            });
          }
        } catch (error) {
          return message.reply({
            embeds: [new client.embed().desc(`${emoji.no} **You need the "Mute Members" permission to use this command!**`)],
          });
        }
      }
    }

    // Check bot permissions
    if (!message.guild.members.me.permissions.has(PermissionFlagsBits.MuteMembers)) {
      return message.reply({
        embeds: [new client.embed().desc(`${emoji.no} **I don't have permission to unmute members!**`)],
      });
    }

    // Unmute the target user
    try {
      await target.voice.setMute(false);
      message.reply({
        embeds: [new client.embed().desc(`${emoji.success} **Unmuted ${target.user.tag} in voice chat!**`)],
      });
    } catch (error) {
      message.reply({
        embeds: [new client.embed().desc(`${emoji.no} **Failed to unmute ${target.user.tag}!**`)],
      });
    }
  },
};