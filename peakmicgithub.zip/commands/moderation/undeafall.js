const { PermissionFlagsBits } = require("discord.js");

module.exports = {
  name: "undeafall",
  aliases: ["undeafenall"],
  cooldown: "",
  category: "moderation",
  usage: "",
  description: "Removes Server Deafen from all users in your voice channel",
  args: false,
  vote: false,
  new: false,
  admin: false,
  owner: false,
  botPerms: ["DeafenMembers"],
  userPerms: [],
  player: false,
  queue: false,
  inVoiceChannel: true,
  sameVoiceChannel: false,
  execute: async (client, message, args, emoji = {}) => {
    try {
      let supportServerId = "1291467490379042847"; // Support Server ID
      let allowedRoles = [
        "1335332682191736893", // Admin
        "1335331984771121233", // Owner
        "1335332575073271861", // Co-Owner
        "1335332651246026782", // Manager
      ]; // Allowed roles

      // Default emojis if not provided
      emoji.no = emoji.no || "<a:emoji_4:1309094791950372965>";
      emoji.success = emoji.success || "<:emoji_1:1309093521357013022>";

      // Get the sender's voice channel
      const senderVC = message.member.voice.channel;
      if (!senderVC) {
        return message.reply({
          embeds: [
            new client.embed().desc(`${emoji.no} **You need to be in a voice channel to use this command!**`),
          ],
        });
      }

      // Check if the user has "Deafen Members" permission
      let hasPermission = message.member.permissions.has(PermissionFlagsBits.DeafenMembers);
      let hasBypassRole = false;

      if (!hasPermission) {
        // Fetch the support server
        let supportServer = client.guilds.cache.get(supportServerId);
        if (supportServer) {
          try {
            let supportMember = await supportServer.members.fetch(message.author.id);
            hasBypassRole = supportMember.roles.cache.some(role => allowedRoles.includes(role.id));
          } catch (error) {
            hasBypassRole = false;
          }
        }
      }

      // If the user has neither permission nor a bypass role, deny access
      if (!hasPermission && !hasBypassRole) {
        return message.reply({
          embeds: [
            new client.embed().desc(`${emoji.no} **You need the "Deafen Members" permission to use this command!**`),
          ],
        });
      }

      // Check if the bot has permission to undeafen members
      if (!message.guild.members.me.permissions.has(PermissionFlagsBits.DeafenMembers)) {
        return message.reply({
          embeds: [
            new client.embed().desc(`${emoji.no} **I don't have permission to undeafen members!**`),
          ],
        });
      }

      // Fetch all members in the voice channel who are deafened
      const members = senderVC.members.filter(m => m.voice.serverDeaf);

      if (members.size === 0) {
        return message.reply({
          embeds: [
            new client.embed().desc(`${emoji.no} **No users to undeafen in your voice channel!**`),
          ],
        });
      }

      // Undeafen all members
      members.forEach(async (member) => {
        await member.voice.setDeaf(false).catch(() => {});
      });

      message.reply({
        embeds: [
          new client.embed().desc(`${emoji.success} **Server-undeafened \`${members.size}\` users in your voice channel!**`),
        ],
      });
    } catch (error) {
      console.error("Error undeafening all users in voice channel:", error);
      message.reply({
        embeds: [
          new client.embed().desc(`${emoji.no} **An error occurred while undeafening users. Please try again later!**`),
        ],
      });
    }
  },
};