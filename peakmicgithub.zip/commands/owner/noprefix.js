const ms = require("ms");

module.exports = {

  name: "noprefix",

  aliases: ["nop"],

  cooldown: "",

  category: "owner",

  usage: "<add/remove> <mention|id> <time>",

  description: "Add or remove no prefix access",

  args: true,

  vote: false,

  new: false,

  admin: true,

  owner: true,

  botPerms: [],

  userPerms: [],

  player: false,

  queue: false,

  inVoiceChannel: false,

  sameVoiceChannel: false,

  execute: async (client, message, args, emoji) => {

    // Check database setup

    if (!client.db?.noprefix || typeof client.db.noprefix.get !== "function") {

      return message.reply({

        embeds: [

          new client.embed().desc(

            `<:chudgyeguru:1357998308643045488> **Database not set up properly.**`

          ),

        ],

      });

    }

    const subcmd = args[0]?.toLowerCase();

    const id =

      message.mentions.members.first()?.user.id ||

      args[1]?.replace(/[^0-9]/g, "");

    const time = args[2] ?? null;

    const user = id

      ? await client.users.fetch(id, { force: true }).catch(() => null)

      : null;

    if (!user) {

      return message.reply({

        embeds: [

          new client.embed().desc(

            `<:chudgyeguru:1357998308643045488> **Invalid or no user provided.**`

          ),

        ],

      });

    }

    let noprefix = null;

    try {

      noprefix = await client.db.noprefix.get(user.id);

    } catch (e) {

      console.error(`DB error while getting ${user.id}:`, e);

    }

    if (subcmd === "add") {

      if (noprefix) {

        return message.reply({

          embeds: [

            new client.embed().desc(

              `<:chudgyeguru:1357998308643045488> **User already has no prefix access.**`

            ),

          ],

        });

      }

      const dur = time ? ms(time) : null;

      try {

        await client.db.noprefix.set(user.id, dur ? Date.now() + dur : true);

      } catch (e) {

        console.error(`DB error while setting ${user.id}:`, e);

        return message.reply({

          embeds: [

            new client.embed().desc(

              `<:chudgyeguru:1357998308643045488> **Failed to add user to noprefix.**`

            ),

          ],

        });

      }

      return message.channel.send({

        embeds: [

          new client.embed()

            .desc(

              `<:chudgyeguru:1357998308643045488> **Added** \`${user.tag}\` to my no prefix list.\n${

                dur

                  ? `**Ends**: <t:${Math.round(

                      (Date.now() + dur) / 1000

                    )}:f>`

                  : ""

              }`

            )

            .setAuthor({

              name: `Manage NoPrefix`,

              iconURL: client.user.displayAvatarURL(),

            }),

        ],

      });

    }

    if (subcmd === "remove") {

      if (!noprefix) {

        return message.reply({

          embeds: [

            new client.embed().desc(

              `<:chudgyeguru:1357998308643045488> **User doesn't have no prefix access.**`

            ),

          ],

        });

      }

      try {

        await client.db.noprefix.delete(user.id);

      } catch (e) {

        console.error(`DB error while deleting ${user.id}:`, e);

        return message.reply({

          embeds: [

            new client.embed().desc(

              `<:chudgyeguru:1357998308643045488> **Failed to remove user from noprefix.**`

            ),

          ],

        });

      }

      return message.channel.send({

        embeds: [

          new client.embed()

            .desc(

              `<:chudgyeguru:1357998308643045488> **Removed** \`${user.tag}\` from my no prefix list.`

            )

            .setAuthor({

              name: `Manage NoPrefix`,

              iconURL: client.user.displayAvatarURL(),

            }),

        ],

      });

    }

    return message.reply({

      embeds: [

        new client.embed().desc(

          `<:chudgyeguru:1357998308643045488> **Invalid subcommand. Use \`add\` or \`remove\`**`

        ),

      ],

    });

  },

};