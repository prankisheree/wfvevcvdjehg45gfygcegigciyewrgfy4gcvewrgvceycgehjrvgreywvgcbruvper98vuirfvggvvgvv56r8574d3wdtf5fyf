/** @format

 *

 * Peak Mic - User Info Command

 * Version: 1.0.0

 * Â© 2024 Bhootiya Bangla

 */

const { EmbedBuilder } = require('discord.js');

module.exports = {

  name: "userinfo",

  aliases: ["ui"],

  cooldown: "",

  category: "utilities",

  usage: "userinfo @mention / userID",

  description: "Displays detailed information about a user.",

  args: false,

  vote: false,

  new: false,

  admin: false,

  owner: false,

  botPerms: [],

  userPerms: [],

  player: false,

  queue: false,

  inVoiceChannel: false,

  sameVoiceChannel: false,

  execute: async (client, message, args, emoji = {}) => {

    try {

      let user = message.mentions.users.first();

      let member = message.mentions.members?.first();

      if (!user && args[0]) {

        try {

          user = await client.users.fetch(args[0]);

        } catch (error) {

          console.error("Error fetching user:", error);

          return message.reply({

            embeds: [

              new EmbedBuilder()

                .setColor("#FF0000")

                .setTitle(`${emoji.error || "<a:emoji_4:1309094791950372965>"} Error`)

                .setDescription("User not found!\nUsage: `userinfo @mention / userID`"),

            ],

          });

        }

      }

      if (!user) {

        user = message.author;

        member = message.member;

      }

      if (!member) {

        member = await message.guild.members.fetch(user.id).catch(() => null);

      }

      let bannerURL = null;

      try {

        const userFetch = await user.fetch();

        if (userFetch.banner) {

          bannerURL = userFetch.bannerURL({ size: 1024, dynamic: true });

        }

      } catch (error) {

        console.error("Error fetching banner:", error);

      }

      const roles = member

        ? member.roles.cache.filter(r => r.id !== message.guild.id).map(r => r.name).join(", ") || "None"

        : "Unknown";

      let permissions = "Unknown";

      if (member) {

        permissions = member.permissions.toArray().map(perm => `\`${perm}\``).join(", ") || "None";

      }

      const embed = new EmbedBuilder()

        .setColor("#DEAD52")

        .setTitle(`${emoji.user || "<a:emoji_63:1340606133458698301>"} ${user.username}'s Information`)

        .setThumbnail(user.displayAvatarURL({ dynamic: true, size: 1024 }))

        .addFields(

          { name: `${emoji.id || "<:emoji_49:1333314042852544582>"} User ID`, value: `\`${user.id}\``, inline: true },

          { name: `${emoji.calendar || "<a:emoji_48:1332570355914641499>"} Account Created`, value: `<t:${Math.floor(user.createdTimestamp / 1000)}:R>`, inline: true },

          { name: `${emoji.roles || "<a:emoji_7:1309539322139119626>"} Roles`, value: roles, inline: false },

          { name: `${emoji.perms || "<:emoji_9:1309540471042740384>"} Permissions`, value: permissions, inline: false }

        )

        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) });

      if (bannerURL) {

        embed.setImage(bannerURL);

      }

      await message.reply({ embeds: [embed] });

    } catch (error) {

      console.error("Error executing userinfo command:", error);

      message.reply(`${emoji.error || "<a:emoji_4:1309094791950372965>"} **An error occurred while fetching user information. Please try again later!**`);

    }

  },

};