const { PermissionFlagsBits } = require("discord.js");

module.exports = {

  name: "nick",

  aliases: [],

  cooldown: "",

  category: "moderation",

  usage: "<user> [nickname]",

  description: "Change or reset a user's nickname",

  args: true,

  vote: false,

  new: false,

  admin: false,

  owner: false,

  botPerms: ["ManageNicknames"],

  userPerms: [],

  player: false,

  queue: false,

  inVoiceChannel: false,

  sameVoiceChannel: false,

  execute: async (client, message, args, emoji = {}) => {

    let supportServerId = "1291467490379042847";

    let allowedRoles = [

      "1335332682191736893", // Admin

      "1335331984771121233", // Owner

      "1335332575073271861", // Co-Owner

      "1335332651246026782", // Manager

    ];

    emoji.warning = emoji.warning || "<a:emoji_4:1309094791950372965>";

    emoji.no = emoji.no || "<a:emoji_5:1309094939841269760>";

    emoji.success = emoji.success || "<:emoji_1:1309093521357013022>";

    // Check if member has permission or bypass

    if (!message.member.permissions.has(PermissionFlagsBits.ManageNicknames)) {

      let supportServer = client.guilds.cache.get(supportServerId);

      if (supportServer) {

        try {

          let supportMember = await supportServer.members.fetch(message.author.id);

          let hasBypassRole = supportMember.roles.cache.some(role => allowedRoles.includes(role.id));

          if (!hasBypassRole) {

            return message.reply({

              embeds: [new client.embed().desc(`${emoji.no} **You need the "Manage Nicknames" permission to use this command!**`)],

            });

          }

        } catch (error) {

          return message.reply({

            embeds: [new client.embed().desc(`${emoji.no} **You need the "Manage Nicknames" permission to use this command!**`)],

          });

        }

      }

    }

    let member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);

    if (!member) {

      return message.reply({

        embeds: [new client.embed().desc(`${emoji.no} **Please mention a valid user!**`)],

      });

    }

    let nickname = args.slice(1).join(" ");

    try {

      if (!nickname) {

        await member.setNickname(null);

        return message.reply({

          embeds: [new client.embed().desc(`${emoji.success} **Reset nickname of \`${member.user.tag}\`!**`)],

        });

      } else {

        await member.setNickname(nickname);

        return message.reply({

          embeds: [new client.embed().desc(`${emoji.success} **Changed nickname of \`${member.user.tag}\` to \`${nickname}\`!**`)],

        });

      }

    } catch (err) {

      return message.reply({

        embeds: [new client.embed().desc(`${emoji.no} **Failed to change nickname. Maybe I don't have permission!**`)],

      });

    }

  },

};