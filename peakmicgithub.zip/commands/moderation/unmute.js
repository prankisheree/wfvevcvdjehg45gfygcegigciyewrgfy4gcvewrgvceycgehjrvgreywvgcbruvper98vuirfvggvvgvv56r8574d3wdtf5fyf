/** @format
 *
 * Unmute Command for Peak Mic
 * Category: Moderation
 */

const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "unmute",
  aliases: ["removetimeout"],
  category: "moderation",
  usage: "unmute {user} {reason}",
  description: "Removes a user's timeout (mute).",
  args: true,
  botPerms: ["ModerateMembers"],
  userPerms: ["ModerateMembers"],
  execute: async (client, message, args) => {
    try {
      // Custom emojis
      const yesEmoji = "<:emoji_1:1309093521357013022>";
      const noEmoji = "<a:emoji_4:1309094791950372965>";
      const dmSentEmoji = "<:emoji_59:1336350120601718887>";
      const dmFailedEmoji = "<:emoji_59:1336350103455268954>";
      const reasonEmoji = "<a:emoji_61:1336350683384778773>";
      const responsibleEmoji = "<:emoji_20:1309926239804592300>";

      // Get the target member
      const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
      if (!member) {
        const embed = new EmbedBuilder()
          .setColor("#fb5984")
          .setDescription(`${noEmoji} **Please mention a valid member to unmute.**`);
        return message.reply({ embeds: [embed] });
      }

      // Check role hierarchy
      if (member.roles.highest.position >= message.member.roles.highest.position) {
        const embed = new EmbedBuilder()
          .setColor("#fb5984")
          .setDescription(`${noEmoji} **You cannot unmute this member.**`);
        return message.reply({ embeds: [embed] });
      }

      // Check if user is muted
      if (!member.communicationDisabledUntilTimestamp) {
        const embed = new EmbedBuilder()
          .setColor("#fb5984")
          .setDescription(`${noEmoji} **This user is not muted.**`);
        return message.reply({ embeds: [embed] });
      }

      // Get reason
      let reason = args.slice(1).join(" ") || "No reason provided.";

      // DM embed
      let dmSent = true;
      const dmEmbed = new EmbedBuilder()
        .setAuthor({ name: "You have been unmuted!", iconURL: member.user.displayAvatarURL({ dynamic: true }) })
        .setDescription(
          `> ${reasonEmoji} **Reason:** ${reason}\n` +
          `> ${responsibleEmoji} **Responsible:** ${message.author.username}\n` +
          `> **Server:** ${message.guild.name}`
        )
        .setFooter({ text: "You can now talk again!" })
        .setColor("#00ff00");

      try {
        await member.send({ embeds: [dmEmbed] });
      } catch {
        dmSent = false;
      }

      // Remove timeout (unmute)
      await member.timeout(null).catch(() => {
        const embed = new EmbedBuilder()
          .setColor("#fb5984")
          .setDescription(`${noEmoji} **Failed to unmute the member.**`);
        return message.reply({ embeds: [embed] });
      });

      // Confirmation embed
      const confirmationEmbed = new EmbedBuilder()
        .setAuthor({ name: "User Unmuted", iconURL: member.user.displayAvatarURL({ dynamic: true }) })
        .setDescription(
          `> ${yesEmoji} **Unmuted:** ${member}\n` +
          `> ${reasonEmoji} **Reason:** ${reason}\n` +
          `> ${responsibleEmoji} **Responsible:** ${message.author.username}\n\n` +
          `> **DM Status:** ${dmSent ? `${dmSentEmoji} Sent` : `${dmFailedEmoji} Failed`}`
        )
        .setFooter({ text: `Moderation by ${message.author.tag}` })
        .setColor("#00ff00");

      // Send embed response
      await message.reply({ embeds: [confirmationEmbed] });
    } catch (error) {
      console.error("Error executing unmute command:", error);
      const errorEmbed = new EmbedBuilder()
        .setColor("#fb5984")
        .setDescription(`${noEmoji} **An error occurred while unmuting the user. Please try again later!**`);
      message.reply({ embeds: [errorEmbed] });
    }
  },
};