/** @format
 *
 * Fuego By Painfuego
 * Version: 6.0.0-beta
 * © 2024 1sT-Services
 */

const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");

module.exports = {
  name: "vote",
  aliases: [],
  cooldown: "",
  category: "information",
  usage: "",
  description: "Shows bot's vote link",
  args: false,
  vote: false,
  new: false,
  admin: false,
  owner: false,
  botPerms: [],
  userPerms: [],
  player: false,
  queue: false,
  inVoiceChannel: false,
  sameVoiceChannel: false,
  execute: async (client, message, args, emoji) => {
    const voteLink = "https://top.gg/bot/1309465466351259648?s=014b0bfee1be1";

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setLabel("Click here to vote for me")
        .setStyle(ButtonStyle.Link)
        .setURL(voteLink)
    );

    await message.reply({
      embeds: [
        new client.embed().desc(
          `${emoji.vote} **Considering voting for me on Top.gg?**`
        ),
      ],
      components: [row],
    });
  },
};