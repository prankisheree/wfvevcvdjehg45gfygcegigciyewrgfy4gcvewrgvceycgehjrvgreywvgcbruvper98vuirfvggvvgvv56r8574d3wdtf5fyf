/** @format

 *

 * Peak Mic Bot - Stats Command

 * Version: 6.0.0-beta

 * © 2024 1sT-Services

 */

const genGraph = require("@gen/pingGraph.js");

const { ActionRowBuilder } = require("discord.js");

module.exports = {

  name: "stats",

  aliases: ["shard", "status", "stat", "st", "node"],

  cooldown: "",

  category: "information",

  usage: "",

  description: "Shows bot's stats",

  args: false,

  vote: false,

  new: false,

  admin: false,

  owner: false,

  botPerms: [],

  userPerms: [],

  player: false,

  queue: false,

  inVoiceChannel: false,

  sameVoiceChannel: false,

  execute: async (client, message, args, emoji) => {

    let loadingEmbed = new client.embed().desc(`Fetching stats, please wait...`);

    let wait = await message.reply({ embeds: [loadingEmbed] });

    let v = await client.cluster.broadcastEval(async (x) => {

      let cpu = "[ N/A ]";

      await new Promise(async (resolve) => {

        require("os-utils").cpuUsage((v) => resolve(v));

      }).then((value) => {

        cpu = value;

      });

      return [

        `**Processor:** \`${require("os").cpus()[0].model}\`

**OS:** \`${process.platform}\`

**Ping:** \`${x.ws.ping}ms\`

**Uptime:** \`${x.formatTime(x.uptime)}\`

**Servers:** \`${x.guilds.cache.size}\`

**Users:** \`${(await x.guilds.cache.reduce((a, g) => a + g.memberCount, 0))}\`

**RAM:** \`${x.formatBytes(process.memoryUsage().heapUsed)}\`

**CPU:** \`${cpu.toFixed(2)}% vCPU\``,

      ];

    });

    const overviewEmbed = new client.embed()

      .title(`${client.user.username} Status`)

      .setFooter({ text: `Page: [1/4] <3 Powered by endercloud.in ` })

      .setImage(

        `https://cdn.discordapp.com/attachments/1284511185605099551/1357618127994753116/Picsart_25-01-22_12-37-08-106.png`

      );

    for (let i = 0; i < v.length; i++) {

      overviewEmbed.addFields({

        name: `Cluster [${i}]`,

        value: v[i][0],

        inline: true,

      });

    }

    const nodeStatsEmbed = new client.embed()

      .title(`${client.user.username} Node Status`)

      .desc(

        [...client.manager.shoukaku.nodes.values()]

          .map(

            (node) =>

              `**Node: ${node.name}**

**Players:** \`${node.stats.players}\`

**CPU:** \`${(

                node.stats.cpu.systemLoad + node.stats.cpu.lavalinkLoad

              ).toFixed(2)}/${node.stats.cpu.cores * 100} %vCPU\`

**RAM:** \`${(

                node.stats.memory.used / 1024 / 1024 / 1024

              ).toFixed(1)}/${(

                (node.stats.memory.reservable + node.stats.memory.allocated) /

                1024 /

                1024 /

                1024

              ).toFixed(1)} GiB\`

**Uptime:** \`${client.formatTime(node.stats.uptime)}\``

          )

          .join("\n\n")

      )

      .setFooter({ text: `Page: [2/4] <3 Powered by endercloud.in` });

    const uri = await genGraph(

      client.ws.ping,

      wait.createdAt - message.createdAt

    );

    const graphEmbed = new client.embed()

      .title("Ping Graph")

      .img(uri)

      .setFooter({ text: `Page: [3/4] <3 Powered by endercloud.in ` });

    const partnerEmbed = new client.embed()

      .title("Our Partner ❤️")

      .setImage(

        `https://cdn.discordapp.com/attachments/1351366361586073600/1409100560971337779/peak.png?ex=68ac26a9&is=68aad529&hm=0a228f17fdc54232cb5b59b194d8de85114bb122d7e376a3a62bead5f8e4a648&`

      )

      .setFooter({

        text: `Powered by endercloud.in`,

        iconURL: `https://endercloud.in/favicon.ico`,

      });

    let page = 0;

    let pages = [overviewEmbed, nodeStatsEmbed, graphEmbed, partnerEmbed];

    const btn1 = new client.button().secondary("stats", "Overview");

    const btn2 = new client.button().secondary("node", "Node Stats");

    const btn3 = new client.button().secondary("graph", "Ping Graph");

    const btn4 = new client.button().secondary("partner", "Partner");

    const btn5 = new client.button().danger("stop", "Close");

    const row = new ActionRowBuilder().addComponents(btn1, btn2, btn3, btn4, btn5);

    let m = await wait

      .edit({ embeds: [pages[page]], components: [row] })

      .catch(() => {});

    const filter = (i) => i.user.id === message.author.id;

    const collector = m?.createMessageComponentCollector({

      filter,

      time: 60000,

      idle: 30000,

    });

    collector?.on("collect", async (c) => {

      if (!c.deferred) await c.deferUpdate();

      switch (c.customId) {

        case "stats":

          page = 0;

          break;

        case "node":

          page = 1;

          break;

        case "graph":

          page = 2;

          break;

        case "partner":

          page = 3;

          break;

        case "stop":

          return collector.stop();

      }

      await m.edit({ embeds: [pages[page]] }).catch(() => {});

    });

    collector?.on("end", async () => {

      await m.edit({ components: [] }).catch(() => {});

    });

  },

};