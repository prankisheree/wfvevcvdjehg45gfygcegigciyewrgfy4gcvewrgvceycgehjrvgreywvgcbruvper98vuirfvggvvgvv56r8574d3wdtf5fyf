
/** @format
 *
 * Fuego By Painfuego
 * Version: 6.0.0-beta
 * © 2024 1sT-Services
 */

module.exports = {
  name: "checksvrs",
  aliases: [],
  cooldown: "",
  category: "owner",
  usage: "",
  description: "Shows server details",
  args: false,
  vote: false,
  new: false,
  admin: true,
  owner: true,
  botPerms: [],
  userPerms: [],
  player: false,
  queue: false,
  inVoiceChannel: false,
  sameVoiceChannel: false,
  execute: async (client, message, args, emoji) => {
    const Discord = require("discord.js");
    const CHUNK_SIZE = 4; // Number of servers per page
    const TOGGLE_ON = "<:emoji_41:1321375320221155338>";
    const TOGGLE_OFF = "<:emoji_41:1321375320221155338>";

    // Function to create the server embed
    const createServerEmbed = async (currentPage, totalPages, guildChunk) => {
      const embed = new Discord.EmbedBuilder()
        .setTitle("Server Details")
        .setDescription(`Page ${currentPage + 1}/${totalPages}`)
        .setColor(Discord.Colors.Blue);

      for (const guild of guildChunk) {
        const fetchedGuild = client.guilds.cache.get(guild.id);
        if (!fetchedGuild) continue;

        // Fetch the guild owner manually
        const owner = await client.users.fetch(fetchedGuild.ownerId).catch(() => null);
        const ownerName = owner ? owner.username : "Unknown";
        const memberCount = fetchedGuild.memberCount;

        const setupStatus = TOGGLE_OFF; // Default status (update based on logic)

        embed.addFields(
          { name: " ", value: `**${fetchedGuild.name}** | \`${fetchedGuild.id}\``, inline: false },
          { name: "**Owner**", value: `${ownerName}`, inline: true },
          { name: "**Members**", value: `${memberCount}`, inline: true },
          { name: "**Status**", value: `${setupStatus}`, inline: true }
        );
      }

      return embed;
    };

    // Fetch guilds and divide into chunks
    const guilds = Array.from(client.guilds.cache.values());
    const chunks = [];
    for (let i = 0; i < guilds.length; i += CHUNK_SIZE) {
      chunks.push(guilds.slice(i, i + CHUNK_SIZE));
    }

    // Handle no servers case
    if (chunks.length === 0) {
      return message.reply("No servers to display.");
    }

    let currentPage = 0;

    // Create a function to send the embed with pagination buttons
    const sendEmbed = async () => {
      const embed = await createServerEmbed(currentPage, chunks.length, chunks[currentPage]);

      // Create "Previous Page" and "Next Page" buttons
      const row = new Discord.ActionRowBuilder().addComponents(
        new Discord.ButtonBuilder()
          .setCustomId('previous_page')
          .setLabel('Previous Page')
          .setStyle(Discord.ButtonStyle.Primary)
          .setDisabled(currentPage === 0), // Disable the button on the first page
        new Discord.ButtonBuilder()
          .setCustomId('next_page')
          .setLabel('Next Page')
          .setStyle(Discord.ButtonStyle.Primary)
          .setDisabled(currentPage === chunks.length - 1) // Disable the button on the last page
      );

      const msg = await message.reply({ embeds: [embed], components: [row] });

      // Collect button interactions
      const filter = (interaction) => interaction.user.id === message.author.id; // Filter for the command author
      const collector = msg.createMessageComponentCollector({
        filter,
        time: 300000, // 1 minute timeout for interaction
      });

      collector.on('collect', async (interaction) => {
        if (interaction.customId === 'next_page') {
          // Increment the page number
          currentPage = Math.min(currentPage + 1, chunks.length - 1);
        } else if (interaction.customId === 'previous_page') {
          // Decrement the page number
          currentPage = Math.max(currentPage - 1, 0);
        }

        // Update the embed and the buttons with the new page
        const newEmbed = await createServerEmbed(currentPage, chunks.length, chunks[currentPage]);
        await interaction.update({
          embeds: [newEmbed],
          components: [
            new Discord.ActionRowBuilder().addComponents(
              new Discord.ButtonBuilder()
                .setCustomId('previous_page')
                .setLabel('Previous Page')
                .setStyle(Discord.ButtonStyle.Primary)
                .setDisabled(currentPage === 0), // Disable if on first page
              new Discord.ButtonBuilder()
                .setCustomId('next_page')
                .setLabel('Next Page')
                .setStyle(Discord.ButtonStyle.Primary)
                .setDisabled(currentPage === chunks.length - 1) // Disable if on last page
            ),
          ],
        });
      });

      collector.on('end', () => {
        // Remove all components (buttons) after the timeout
        msg.edit({ components: [] });
      });
    };

    // Check if user has permissions
    if (message.author.id !== "1207080102974980136") {
      return message.reply("<a:emoji_4:1309094791950372965> You don't have permission to use this command.");
    }

    // Send the first embed
    await sendEmbed();
  },
};