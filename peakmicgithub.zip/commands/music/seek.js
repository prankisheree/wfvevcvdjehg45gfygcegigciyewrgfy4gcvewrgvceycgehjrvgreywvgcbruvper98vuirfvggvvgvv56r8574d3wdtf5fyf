/** @format
 *
 * Fuego By Painfuego
 * Version: 6.0.0-beta
 * © 2024 1sT-Services
 */

const progressbar = require("@gen/progressbar");
const { ActionRowBuilder } = require("discord.js");

module.exports = {
  name: "seek",
  aliases: [],
  cooldown: "",
  category: "music",
  usage: "[ Xmin or s eg. 5s, 5min ]",
  description: "Seek the current song to a specific duration",
  args: false,
  vote: false,
  new: false,
  admin: false,
  owner: false,
  botPerms: [],
  userPerms: [],
  player: true,
  queue: true,
  inVoiceChannel: true,
  sameVoiceChannel: true,
  execute: async (client, message, args, emoji) => {
    let player = await client.getPlayer(message.guild.id);

    if (!player) {
      return message.reply({
        embeds: [
          new client.embed().desc(
            `${emoji.no} **There is no player active in this server.**`
          ),
        ],
      });
    }

    if (args[0]) {
      let track = player.queue.current;

      const parseTime = (input) => {
        const timeRegex = /^((\d+)\s*(min|m|minutes?))?\s*((\d+)\s*(s|sec)?)?$/;
        const match = input.match(timeRegex);

        if (!match) return null;

        const minutes = match[2] ? parseInt(match[2], 10) : 0;
        const seconds = match[4] ? parseInt(match[4], 10) : 0;

        return minutes * 60 + seconds;
      };

      const timeInSeconds = parseTime(args.join(" "));
      const time = timeInSeconds ? timeInSeconds * 1000 : null;

      if (time) {
        if (track.isStream) {
          return message.reply({
            embeds: [
              new client.embed().desc(
                `${emoji.no} **Seek Failed!**\n${emoji.bell} \`◉ LIVE\` tracks cannot be seeked.`
              ),
            ],
          });
        }

        if (time > track.length) {
          return message.reply({
            embeds: [
              new client.embed().desc(
                `${emoji.no} **Seek Failed!**\n${emoji.bell} Seek duration must be less than the song duration.`
              ),
            ],
          });
        }

        await player.seek(time);

        return message.reply({
          embeds: [
            new client.embed().desc(
              `${emoji.yes} **Seeked to \`${require("ms")(time)}\`**`
            ),
          ],
        });
      }
    }

    const generateEmbed = async () => {
      let track = player.queue.current;

      const total = track.isStream
        ? `◉ LIVE`
        : client.formatTime(player.queue.current.length);
      const current = client.formatTime(player.position);

      const progressBarLength = 14;
      const progress = Math.round(
        (player.position / player.queue.current.length) * progressBarLength
      );

      const progressBar = Array(progressBarLength)
        .fill("<:Yellow_Line:1310203351002120252>")
        .map((emoji, index) =>
          index === progress ? "<a:emoji_33:1310665543623381093>" : emoji
        )
        .join("");

      let embed = new client.embed().addFields({
        name: `Progress - [ ${current} / ${total} ]`,
        value: `${progressBar}`,
        inline: false,
      });

      return embed;
    };

    const track = player.queue.current;
    const row1 = new ActionRowBuilder().addComponents(
      new client.button().secondary("-30s", "- 30", ``, false),
      new client.button().secondary("-10s", "- 10", ``, false),
      new client.button().secondary("+10s", "+ 10", ``, false),
      new client.button().secondary("+30s", "+ 30", ``, false)
    );

    const row2 = new ActionRowBuilder().addComponents(
      new client.button().secondary("-30s", "- 30", ``, true),
      new client.button().secondary("-10s", "- 10", ``, true),
      new client.button().secondary("+10s", "+ 10", ``, true),
      new client.button().secondary("+30s", "+ 30", ``, true)
    );

    const row = track.isStream ? row2 : row1;
    const m = await message
      .reply({
        embeds: [await generateEmbed()],
        components: [row],
      })
      .catch(() => {});

    const seek = async (m, time) => {
      await player.seek(time);
      await client.sleep(300);
      await m.edit({ embeds: [await generateEmbed()] }).catch(() => {});
    };

    const filter = (interaction) => {
      if (interaction.user.id === message.author.id) {
        return true;
      }
      interaction
        .reply({
          embeds: [
            new client.embed().desc(
              `${emoji.no} Only **${message.author.tag}** can use this.`
            ),
          ],
          ephemeral: true,
        })
        .catch(() => {});
      return false;
    };

    const collector = m?.createMessageComponentCollector({
      filter: filter,
      time: 60000,
      idle: 30000,
    });

    collector?.on("collect", async (interaction) => {
      let time;
      switch (interaction.customId) {
        case "-30s":
          time = player.position - 30000;
          if (time < 0) time = 0;
          await seek(m, time);
          break;
        case "-10s":
          time = player.position - 10000;
          if (time < 0) time = 0;
          await seek(m, time);
          break;
        case "+10s":
          time = player.position + 10000;
          if (time > track.length) time = track.length;
          await seek(m, time);
          break;
        case "+30s":
          time = player.position + 30000;
          if (time > track.length) time = track.length;
          await seek(m, time);
          break;
      }
      if (!interaction.deferred) interaction.deferUpdate();
    });

    collector?.on("end", async () => {
      m.edit({ components: [row2] }).catch(() => {});
    });
  },
};