module.exports = {

  name: "skipto",

  aliases: [],

  cooldown: "",

  category: "music",

  usage: "<position in queue>",

  description: "Skip to a specific song in the queue",

  args: true,

  vote: false,

  new: false,

  admin: false,

  owner: false,

  botPerms: [],

  userPerms: [],

  player: true,

  queue: true,

  inVoiceChannel: true,

  sameVoiceChannel: true,

  execute: async (client, message, args, emoji) => {

    const player = await client.getPlayer(message.guild.id);

    const position = Number(args[0]);

    // Check if the input is not a number

    if (isNaN(position)) {

      return message.reply({

        embeds: [

          new client.embed().desc(

            `${emoji.no} **It looks like you're typing text. Please write a number — for example: \`skipto 10\`**`

          )

        ]

      }).catch(() => {});

    }

    // Check if the number is valid within the queue

    if (position < 1 || position > player.queue.length) {

      return message.reply({

        embeds: [

          new client.embed().desc(

            `${emoji.no} **Please provide a valid position between 1 and ${player.queue.length}**`

          )

        ]

      }).catch(() => {});

    }

    player.queue.splice(0, position - 1);

    await player.skip();

    let emb = new client.embed().desc(

      `${"<:emoji_1:1309093521357013022>"} **Skipped to [${player.queue.current.title

        .replace("[", "")

        .replace("]", "")}](${player.queue.current.uri})**`

    );

    return message.reply({ embeds: [emb] }).catch(() => {});

  },

};