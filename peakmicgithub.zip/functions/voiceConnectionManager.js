/** @format
 *
 * Voice Connection Manager
 * Handles voice connection queueing, rate limiting, and cleanup
 */

class VoiceConnectionManager {
  constructor() {
    this.connectionQueue = new Map(); // guildId -> array of connection requests
    this.activeConnections = new Set(); // Set of active guild IDs
    this.maxConcurrentConnections = 8; // Reduced from unlimited to prevent rate limits
    this.connectionTimeouts = new Map(); // guildId -> timeout ID
    this.requestTimeouts = new Map(); // guildId -> request timeout ID
  }

  /**
   * Request a voice connection with queueing support
   */
  async requestConnection(client, guildId, voiceChannelId, textChannelId) {
    return new Promise((resolve, reject) => {
      const connectionRequest = {
        guildId,
        voiceChannelId,
        textChannelId,
        resolve,
        reject,
        timestamp: Date.now(),
        client
      };

      // Check if we can process immediately
      if (this.activeConnections.size < this.maxConcurrentConnections) {
        this.processConnection(connectionRequest);
      } else {
        // Add to queue
        if (!this.connectionQueue.has(guildId)) {
          this.connectionQueue.set(guildId, []);
        }
        this.connectionQueue.get(guildId).push(connectionRequest);
        
        client.logger.log(
          `Connection queued for guild ${guildId}. Queue size: ${this.connectionQueue.get(guildId).length}`,
          "debug"
        );

        // Set timeout for queued requests (3 minutes)
        const timeoutId = setTimeout(() => {
          this.timeoutQueuedRequest(guildId, connectionRequest);
        }, 180000);
        
        this.requestTimeouts.set(`${guildId}_${connectionRequest.timestamp}`, timeoutId);
      }
    });
  }

  /**
   * Process a connection request
   */
  async processConnection(request) {
    const { guildId, voiceChannelId, textChannelId, resolve, reject, client } = request;
    
    this.activeConnections.add(guildId);
    
    try {
      client.logger.log(`Processing voice connection for guild: ${guildId}`, "debug");

      // Set connection timeout (2 minutes)
      const timeoutId = setTimeout(() => {
        client.logger.log(`Voice connection timeout for guild: ${guildId}`, "warning");
        this.handleConnectionFailure(client, guildId);
        reject(new Error('Voice connection timeout after 120 seconds'));
      }, 120000);

      this.connectionTimeouts.set(guildId, timeoutId);

      // Create player with enhanced configuration
      const player = await client.manager.createPlayer({
        voiceId: voiceChannelId,
        textId: textChannelId,
        guildId: guildId,
        shardId: client.guilds.cache.get(guildId)?.shardId || 0,
        loadBalancer: true,
        deaf: true,
      });

      // Clear connection timeout on success
      clearTimeout(timeoutId);
      this.connectionTimeouts.delete(guildId);

      client.logger.log(`Successfully connected to voice in guild: ${guildId}`, "debug");
      resolve(player);

      // Process next in queue after short delay
      setTimeout(() => this.processNextInQueue(client), 2000);

    } catch (error) {
      client.logger.log(`Voice connection error for guild ${guildId}: ${error.message}`, "error");
      this.handleConnectionFailure(client, guildId);
      reject(error);
    }
  }

  /**
   * Handle connection failure
   */
  handleConnectionFailure(client, guildId) {
    // Clear connection timeout
    const timeoutId = this.connectionTimeouts.get(guildId);
    if (timeoutId) {
      clearTimeout(timeoutId);
      this.connectionTimeouts.delete(guildId);
    }

    // Remove from active connections
    this.activeConnections.delete(guildId);

    // Clean up any existing player
    try {
      const player = client.manager.players.get(guildId);
      if (player) {
        player.destroy().catch(() => {});
      }
    } catch (error) {
      client.logger.log(`Error during cleanup for guild ${guildId}: ${error.message}`, "error");
    }

    // Process next in queue
    this.processNextInQueue(client);
  }

  /**
   * Process next connection in queue
   */
  processNextInQueue(client) {
    if (this.activeConnections.size >= this.maxConcurrentConnections) {
      return;
    }

    // Find next queued request
    for (const [guildId, queue] of this.connectionQueue.entries()) {
      if (queue.length > 0) {
        const request = queue.shift();
        
        // Clear request timeout
        const timeoutKey = `${guildId}_${request.timestamp}`;
        const reqTimeoutId = this.requestTimeouts.get(timeoutKey);
        if (reqTimeoutId) {
          clearTimeout(reqTimeoutId);
          this.requestTimeouts.delete(timeoutKey);
        }
        
        // Check if request hasn't expired (3 minutes)
        if (Date.now() - request.timestamp < 180000) {
          this.processConnection(request);
        } else {
          request.reject(new Error('Request timed out in queue'));
          // Continue to next request
          continue;
        }

        if (queue.length === 0) {
          this.connectionQueue.delete(guildId);
        }
        break;
      }
    }
  }

  /**
   * Timeout a queued request
   */
  timeoutQueuedRequest(guildId, targetRequest) {
    const queue = this.connectionQueue.get(guildId);
    if (queue) {
      const index = queue.findIndex(req => req === targetRequest);
      if (index !== -1) {
        queue.splice(index, 1);
        targetRequest.reject(new Error('Request timed out while queued'));
        
        if (queue.length === 0) {
          this.connectionQueue.delete(guildId);
        }
      }
    }
    
    // Clean up timeout reference
    const timeoutKey = `${guildId}_${targetRequest.timestamp}`;
    this.requestTimeouts.delete(timeoutKey);
  }

  /**
   * Get current status
   */
  getStatus() {
    const queuedTotal = Array.from(this.connectionQueue.values())
      .reduce((total, queue) => total + queue.length, 0);
    
    return {
      activeConnections: this.activeConnections.size,
      queuedConnections: queuedTotal,
      maxConcurrentConnections: this.maxConcurrentConnections
    };
  }

  /**
   * Called when a player is destroyed
   */
  onPlayerDestroy(guildId) {
    this.activeConnections.delete(guildId);
    
    // Clear any pending timeouts
    const timeoutId = this.connectionTimeouts.get(guildId);
    if (timeoutId) {
      clearTimeout(timeoutId);
      this.connectionTimeouts.delete(guildId);
    }

    // Process next in queue after short delay
    if (global.client) {
      setTimeout(() => this.processNextInQueue(global.client), 1000);
    }
  }

  /**
   * Cleanup stale connections
   */
  cleanupStaleConnections(client) {
    const staleGuilds = [];
    
    for (const guildId of this.activeConnections) {
      const guild = client.guilds.cache.get(guildId);
      const botInVC = guild?.members.cache.get(client.user.id)?.voice.channelId;
      
      if (!botInVC) {
        staleGuilds.push(guildId);
      }
    }
    
    for (const guildId of staleGuilds) {
      client.logger.log(`Cleaning stale connection for guild: ${guildId}`, "debug");
      this.onPlayerDestroy(guildId);
    }
  }
}

module.exports = new VoiceConnectionManager();
