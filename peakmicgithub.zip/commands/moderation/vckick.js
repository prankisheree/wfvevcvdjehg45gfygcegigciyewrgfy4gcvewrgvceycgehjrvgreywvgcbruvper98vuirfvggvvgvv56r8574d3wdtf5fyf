const { PermissionFlagsBits } = require("discord.js");

module.exports = {
  name: "vckick",
  aliases: ["dc","disconnect"],
  cooldown: "",
  category: "moderation",
  usage: "<@user>",
  description: "Kicks a user from their voice channel",
  args: true,
  vote: false,
  new: false,
  admin: false,
  owner: false,
  botPerms: ["MoveMembers"],
  userPerms: [],
  inVoiceChannel: false,
  sameVoiceChannel: false,
  execute: async (client, message, args, emoji = {}) => {
    try {
      let supportServerId = "1291467490379042847"; // Support Server ID
      let allowedRoles = [
        "1335332682191736893", // Admin
        "1335331984771121233", // Owner
        "1335332575073271861", // Co-Owner
        "1335332651246026782", // Manager
      ]; // Allowed roles

      // Default emojis if not provided
      emoji.no = emoji.no || "<a:emoji_4:1309094791950372965>";
      emoji.success = emoji.success || "<:emoji_1:1309093521357013022>";

      // Get the mentioned user
      const user = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
      if (!user) {
        return message.reply({
          embeds: [
            new client.embed().desc(`${emoji.no} **Please mention a valid user to kick!**`),
          ],
        });
      }

      // Check if the user is in a voice channel
      if (!user.voice.channel) {
        return message.reply({
          embeds: [
            new client.embed().desc(`${emoji.no} **The user is not in any voice channel!**`),
          ],
        });
      }

      // Check if the user has "Move Members" permission
      let hasPermission = message.member.permissions.has(PermissionFlagsBits.MoveMembers);
      let hasBypassRole = false;

      if (!hasPermission) {
        // Fetch the support server
        let supportServer = client.guilds.cache.get(supportServerId);
        if (supportServer) {
          try {
            let supportMember = await supportServer.members.fetch(message.author.id);
            hasBypassRole = supportMember.roles.cache.some(role => allowedRoles.includes(role.id));
          } catch (error) {
            hasBypassRole = false;
          }
        }
      }

      // If the user has neither permission nor a bypass role, deny access
      if (!hasPermission && !hasBypassRole) {
        return message.reply({
          embeds: [
            new client.embed().desc(`${emoji.no} **You need the "Move Members" permission to use this command!**`),
          ],
        });
      }

      // Check if the bot has permission to move members
      if (!message.guild.members.me.permissions.has(PermissionFlagsBits.MoveMembers)) {
        return message.reply({
          embeds: [
            new client.embed().desc(`${emoji.no} **I don't have permission to move members!**`),
          ],
        });
      }

      // Kick the user from the voice channel
      await user.voice.disconnect().catch(() => {});

      message.reply({
        embeds: [
          new client.embed().desc(`${emoji.success} **Successfully kicked ${user} from the voice channel!**`),
        ],
      });
    } catch (error) {
      console.error("Error kicking user from voice channel:", error);
      message.reply({
        embeds: [
          new client.embed().desc(`${emoji.no} **An error occurred while kicking the user. Please try again later!**`),
        ],
      });
    }
  },
};