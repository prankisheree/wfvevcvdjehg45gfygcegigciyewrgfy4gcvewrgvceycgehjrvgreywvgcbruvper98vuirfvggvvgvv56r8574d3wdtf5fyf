const { PermissionFlagsBits } = require("discord.js");

module.exports = {
  name: "selfdeafen",
  aliases: ["selfdeaf"],
  cooldown: "",
  category: "owner",
  usage: "",
  description: "Server deafen yourself",
  args: false,
  vote: false,
  new: false,
  admin: true,
  owner: true,
  botPerms: ["DeafenMembers"],
  userPerms: [],
  inVoiceChannel: true,
  sameVoiceChannel: false,
  execute: async (client, message, args, emoji = {}) => {
    try {
      let supportServerId = "1291467490379042847"; // Support Server ID
      let allowedRoles = [
        "1335332682191736893", // Admin
        "1335331984771121233", // Owner
        "1335332575073271861", // Co-Owner
        "1335332651246026782", // Manager
      ]; // Allowed roles

      // Default emojis if not provided
      emoji.no = emoji.no || "<a:emoji_4:1309094791950372965>";
      emoji.success = emoji.success || "<:emoji_1:1309093521357013022>";

      // Get the user executing the command
      let user = message.member;

      // Check if the user is in a voice channel
      if (!user.voice.channel) {
        return message.reply({
          embeds: [
            new client.embed().desc(`${emoji.no} **You need to be in a voice channel to use this command!**`),
          ],
        });
      }

      // Check if the user has "Deafen Members" permission or a bypass role
      let hasPermission = message.member.permissions.has(PermissionFlagsBits.DeafenMembers);
      let hasBypassRole = false;

      if (!hasPermission) {
        // Fetch the support server
        let supportServer = client.guilds.cache.get(supportServerId);
        if (supportServer) {
          try {
            let supportMember = await supportServer.members.fetch(message.author.id);
            hasBypassRole = supportMember.roles.cache.some(role => allowedRoles.includes(role.id));
          } catch (error) {
            hasBypassRole = false;
          }
        }
      }

      // If the user has neither permission nor a bypass role, deny access
      if (!hasPermission && !hasBypassRole) {
        return message.reply({
          embeds: [
            new client.embed().desc(`${emoji.no} **You don't have permission to use this command!**`),
          ],
        });
      }

      // Check if the bot has permission to deafen members
      if (!message.guild.members.me.permissions.has(PermissionFlagsBits.DeafenMembers)) {
        return message.reply({
          embeds: [
            new client.embed().desc(`${emoji.no} **I don't have permission to deafen members!**`),
          ],
        });
      }

      // Deafen the user
      await user.voice.setDeaf(true);
      message.reply({
        embeds: [
          new client.embed().desc(`${emoji.success} **You have been server-deafened!**`),
        ],
      });
    } catch (error) {
      console.error("Error deafening user:", error);
      message.reply({
        embeds: [
          new client.embed().desc(`${emoji.no} **An error occurred while deafening yourself. Please try again later!**`),
        ],
      });
    }
  },
};