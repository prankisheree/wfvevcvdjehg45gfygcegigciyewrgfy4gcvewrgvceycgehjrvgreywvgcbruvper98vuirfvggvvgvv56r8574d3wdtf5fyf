module.exports = {
  name: "mention",
  run: async (client, message) => {
    /**
     * Handles replies when the bot is mentioned.
     */

    try {
      // Get the server's custom prefix
      const pfxg = await client.db.pfx.get(`${client.user.id}_${message.guild.id}`);
      
      // Determine which prefix to show (server prefix if exists, otherwise default)
      const displayPrefix = pfxg || client.prefix;

      const embed = new client.embed()
        .setThumbnail(client.user.displayAvatarURL())
        .setTitle(`Hey there! I'm **${client.user.username}**, your ultimate music bot! <a:heart1:1274259636106821684>`)
        .setDescription(
          "I provide the **best music quality** and features to elevate your Discord experience. <:emoji_43:1322086110788059177>" +
          "\n\n**Invite me to your server and let the music play!**"
        )
        .addFields([
          {
            name: "Bot Invite Link",
            value: "[Click here to invite me!](https://discord.com/oauth2/authorize?client_id=1309465466351259648)",
          },
          {
            name: "Get Started",
            value: `Use \`${displayPrefix}help\` to see all my commands and features.`,
          },
        ])
        .setFooter({ text: " Powered by endercloud.in" })
        .setTimestamp();

      await message.reply({ embeds: [embed] });
    } catch (error) {
      console.error("Error handling mention command:", error);
    }
  },
};
