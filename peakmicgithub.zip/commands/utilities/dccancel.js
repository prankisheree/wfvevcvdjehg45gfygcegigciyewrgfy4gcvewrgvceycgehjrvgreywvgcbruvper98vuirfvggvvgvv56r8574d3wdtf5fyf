/** @format

 *

 * Peak Mic Bot - dccancel Command

 * Version: 1.0.0

 * © 2025 1sT-Services

 */

module.exports = {

  name: "dccancel",

  aliases: [],

  cooldown: "",

  category: "utilities",

  usage: "",

  description: "Cancels your scheduled disconnect if set by dcmeafter",

  args: false,

  vote: false,

  new: false,

  admin: false,

  owner: false,

  botPerms: [],

  userPerms: [],

  player: false,

  queue: false,

  inVoiceChannel: false,

  sameVoiceChannel: false,

  execute: async (client, message) => {

    if (!client.dcTimers) client.dcTimers = new Map();

    const timeout = client.dcTimers.get(message.author.id);

    if (!timeout) {

      return message.reply({

        embeds: [

          new client.embed().setColor("Orange").desc(

            "You don't have any scheduled disconnect!"

          ),

        ],

      });

    }

    clearTimeout(timeout);

    client.dcTimers.delete(message.author.id);

    return message.reply({

      embeds: [

        new client.embed().setColor("Green").desc(

          "Cancelled your scheduled disconnect successfully!"

        ),

      ],

    });

  },

};