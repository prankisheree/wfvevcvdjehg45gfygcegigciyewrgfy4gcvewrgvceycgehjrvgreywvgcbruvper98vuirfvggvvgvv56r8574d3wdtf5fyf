const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle
} = require("discord.js");

module.exports = {
  name: "listadmins",
  aliases: ["admins", "adminlist", "la"],
  category: "maybeuseful",
  usage: "listadmins",
  description: "List all users who have administrator permissions in the server.",
  args: false,
  botPerms: ["ViewAuditLog"],
  userPerms: ["Administrator"],
  execute: async (client, message) => {
    const noEmoji = "<a:emoji_4:1309094791950372965>";
    const adminEmoji = "<:emoji_49:1333314042852544582>";
    const crownEmoji = "<a:emoji_7:1309539322139119626>";

    try {
      const members = await message.guild.members.fetch();
      const adminMembers = members.filter(
        (m) => m.permissions.has("Administrator")
      );

      if (adminMembers.size === 0) {
        const noEmbed = new EmbedBuilder()
          .setColor("#fb5984")
          .setDescription(`${noEmoji} **No members with administrator permissions found in this server.**`);
        return message.reply({ embeds: [noEmbed] });
      }

      const pages = [];
      const membersArray = Array.from(adminMembers.values());

      for (let i = 0; i < membersArray.length; i++) {
        const member = membersArray[i];
        const joinedAt = `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>`;
        const createdAt = `<t:${Math.floor(member.user.createdTimestamp / 1000)}:R>`;
        const avatar = member.user.displayAvatarURL({ dynamic: true, size: 512 });
        
        // Get highest role
        const highestRole = member.roles.highest.name !== "@everyone" 
          ? member.roles.highest.name 
          : "No roles";

        const embed = new EmbedBuilder()
          .setColor("#fb5984")
          .setAuthor({
            name: `${member.user.tag}`,
            iconURL: avatar
          })
          .setThumbnail(avatar)
          .setTitle(`${crownEmoji} Administrator`)
          .setDescription(
            `${adminEmoji} **User:** ${member}\n` +
            `<:emoji_19:1309926206296166562> **Highest Role:** ${highestRole}\n` +
            `<a:emoji_63:1340606133458698301> **Joined Server:** ${joinedAt}\n` +
            `<:emoji_23:1309927218398367825> **Account Created:** ${createdAt}`
          )
          .setFooter({
            text: `Page ${i + 1} of ${membersArray.length} • Requested by ${message.author.tag}`,
            iconURL: message.author.displayAvatarURL({ dynamic: true })
          });

        pages.push(embed);
      }

      let page = 0;

      const backBtn = new ButtonBuilder()
        .setCustomId("prev")
        .setLabel("◀️")
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(true);

      const nextBtn = new ButtonBuilder()
        .setCustomId("next")
        .setLabel("▶️")
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(pages.length === 1);

      const row = new ActionRowBuilder().addComponents(backBtn, nextBtn);

      const msg = await message.reply({
        embeds: [pages[page]],
        components: [row]
      });

      const collector = msg.createMessageComponentCollector({
        time: 15000
      });

      collector.on("collect", async (interaction) => {
        if (interaction.user.id !== message.author.id) {
          return interaction.reply({
            content: "Only the command author can navigate!",
            ephemeral: true
          });
        }

        await interaction.deferUpdate();

        if (interaction.customId === "next") page++;
        else if (interaction.customId === "prev") page--;

        backBtn.setDisabled(page === 0);
        nextBtn.setDisabled(page === pages.length - 1);

        await msg.edit({ embeds: [pages[page]], components: [row] });
        collector.resetTimer();
      });

      collector.on("end", async () => {
        backBtn.setDisabled(true);
        nextBtn.setDisabled(true);
        await msg.edit({ components: [row] });
      });

    } catch (error) {
      console.error("Admin List Error:", error);
      const errorEmbed = new EmbedBuilder()
        .setColor("#fb5984")
        .setDescription(
          `${noEmoji} **An error occurred while fetching administrators. Please try again later!**`
        );
      return message.reply({ embeds: [errorEmbed] });
    }
  }
};