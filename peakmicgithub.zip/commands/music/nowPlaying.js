/** @format
 *
 * Fuego By Painfuego
 * Version: 6.0.0-beta
 * © 2024 1sT-Services
 */

const { createCanvas, loadImage } = require("canvas");
const { AttachmentBuilder } = require("discord.js");
const { exec } = require("child_process");

// Ensure canvas is installed
try {
  require("canvas");
} catch (err) {
  console.log("Canvas not found. Installing...");
  exec("npm install canvas", (error, stdout, stderr) => {
    if (error) console.error(`Error installing canvas: ${error.message}`);
    console.log(stdout);
    console.error(stderr);
  });
}

module.exports = {
  name: "np",
  aliases: ["nowplaying"],
  cooldown: "",
  category: "music",
  usage: "",
  description: "Displays the currently playing song as an image with a progress bar",
  args: false,
  vote: false,
  new: false,
  admin: false,
  owner: false,
  botPerms: [],
  userPerms: [],
  player: true,
  queue: true,
  inVoiceChannel: false,
  sameVoiceChannel: false,
  execute: async (client, message, args, emoji) => {
    const player = await client.getPlayer(message.guild.id);

    if (!player.queue?.current) {
      let noSongEmbed = new client.embed()
        .setDescription(`${emoji.error} **| No song is currently playing.**`)
        .setColor("#FF0000");
      return message.reply({ embeds: [noSongEmbed] });
    }

    const song = player.queue.current;
    const progress = player.position;
    const duration = song.length;
    const requester = song.requester?.username || "Unknown";

    // Generate the Now Playing image
    const imageBuffer = await generateNowPlayingImage(
      song.title,
      song.author,
      requester,
      song.thumbnail, // Artwork URL
      progress,
      duration
    );

    const attachment = new AttachmentBuilder(imageBuffer, { name: "nowplaying.png" });
    return message.reply({ files: [attachment] });
  },
};

// Generate the Now Playing image
async function generateNowPlayingImage(
  title,
  author,
  requester,
  thumbnailURL,
  currentPosition,
  totalDuration
) {
  const width = 900;
  const height = 300;

  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext("2d");

  // Background gradient (blue to green)
  const gradient = ctx.createLinearGradient(0, 0, width, height);
  gradient.addColorStop(0, "#1c92d2"); // Blue
  gradient.addColorStop(1, "#f2fcfe"); // Green
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, width, height);

  // Add "PEAK MIC" text at the top-left corner
  ctx.fillStyle = "#FFFFFF";
  ctx.font = "bold 24px Arial";
  ctx.fillText("PEAK MIC", 20, 30);

  // Draw rounded thumbnail
  if (thumbnailURL) {
    const thumbnail = await loadImage(thumbnailURL);
    const thumbX = 50;
    const thumbY = 50;
    const thumbWidth = 200;
    const thumbHeight = 200;
    const radius = 30;

    ctx.save();
    ctx.beginPath();
    ctx.moveTo(thumbX + radius, thumbY);
    ctx.arcTo(thumbX + thumbWidth, thumbY, thumbX + thumbWidth, thumbY + thumbHeight, radius);
    ctx.arcTo(
      thumbX + thumbWidth,
      thumbY + thumbHeight,
      thumbX,
      thumbY + thumbHeight,
      radius
    );
    ctx.arcTo(thumbX, thumbY + thumbHeight, thumbX, thumbY, radius);
    ctx.arcTo(thumbX, thumbY, thumbX + thumbWidth, thumbY, radius);
    ctx.closePath();
    ctx.clip();
    ctx.drawImage(thumbnail, thumbX, thumbY, thumbWidth, thumbHeight);
    ctx.restore();
  }

  // Song Title
  ctx.fillStyle = "#FFFFFF";
  ctx.font = "bold 28px Arial";
  ctx.fillText(title.length > 40 ? title.substring(0, 40) + "..." : title, 280, 100);

  // Song Author (Yellow color for "By")
  ctx.font = "22px Arial";
  ctx.fillStyle = "#FFFF00"; // Yellow
  ctx.fillText(`By: ${author || "Unknown"}`, 280, 140);

  // Requested by (Yellow color for text)
  ctx.fillText(`Requested by: ${requester}`, 280, 180);

  // Draw progress bar background with rounded ends
  const barX = 280;
  const barY = 220;
  const barWidth = 550;
  const barHeight = 20;

  ctx.fillStyle = "#555555"; // Gray background
  ctx.beginPath();
  ctx.arc(barX + barHeight / 2, barY + barHeight / 2, barHeight / 2, Math.PI / 2, -Math.PI / 2, false);
  ctx.arc(
    barX + barWidth - barHeight / 2,
    barY + barHeight / 2,
    barHeight / 2,
    -Math.PI / 2,
    Math.PI / 2,
    false
  );
  ctx.closePath();
  ctx.fill();

  // Draw progress bar (foreground, green) with rounded ends
  const progressWidth = (currentPosition / totalDuration) * barWidth;

  ctx.fillStyle = "#1DB954"; // Spotify green
  ctx.beginPath();

  if (progressWidth <= barHeight) {
    // If progress is less than the height of the bar, draw a full circle
    ctx.arc(
      barX + progressWidth,
      barY + barHeight / 2,
      barHeight / 2,
      0,
      2 * Math.PI
    );
  } else {
    // Draw the foreground bar with rounded ends
    ctx.arc(barX + barHeight / 2, barY + barHeight / 2, barHeight / 2, Math.PI / 2, -Math.PI / 2, false);
    ctx.arc(
      barX + progressWidth - barHeight / 2,
      barY + barHeight / 2,
      barHeight / 2,
      -Math.PI / 2,
      Math.PI / 2,
      false
    );
    ctx.closePath();
  }

  ctx.fill();

  // Add circular dot at the current progress
  ctx.fillStyle = "#FFFFFF";
  ctx.beginPath();
  ctx.arc(barX + progressWidth, barY + barHeight / 2, 10, 0, 2 * Math.PI);
  ctx.fill();

  // Time indicators
  ctx.fillStyle = "#FFFFFF";
  ctx.font = "18px Arial";
  ctx.fillText(formatTime(currentPosition), barX, barY + 40);
  ctx.fillText(formatTime(totalDuration), barX + barWidth - 50, barY + 40);

  return canvas.toBuffer();
}

// Format time in MM:SS
function formatTime(ms) {
  const seconds = Math.floor(ms / 1000);
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;
  return `${minutes}:${remainingSeconds < 10 ? "0" : ""}${remainingSeconds}`;
}