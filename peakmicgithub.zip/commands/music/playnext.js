module.exports = {

  name: "playnext",

  aliases: ["aau","addasupcoming"],

  cooldown: "",

  category: "music",

  usage: "<position in queue>",

  description: "Add a song as upcoming (drag it to next position)",

  args: true,

  vote: false,

  new: false,

  admin: false,

  owner: false,

  botPerms: [],

  userPerms: [],

  player: true,

  queue: true,

  inVoiceChannel: true,

  sameVoiceChannel: true,

  execute: async (client, message, args, emoji) => {

    const player = await client.getPlayer(message.guild.id);

    const position = Number(args[0]);

    // Check if the input is a number

    if (isNaN(position)) {

      return message.reply({

        embeds: [

          new client.embed().desc(

            `${emoji.no} **It looks like you're typing text. Please write a number — for example: \`aau 5\`**`

          )

        ]

      }).catch(() => {});

    }

    // Check if the number is valid in the queue

    if (position < 2 || position > player.queue.length) {

      return message.reply({

        embeds: [

          new client.embed().desc(

            `${emoji.no} **Please provide a valid position between 2 and ${player.queue.length}**`

          )

        ]

      }).catch(() => {});

    }

    const song = player.queue[position - 1];

    player.queue.splice(position - 1, 1); // Remove the song from current position

    player.queue.splice(0, 0, song); // Add it right after the currently playing song

    const emb = new client.embed().desc(

      `${"<:emoji_1:1309093521357013022>"} **Moved [${song.title.replace("[", "").replace("]", "")}](${song.uri}) as the next upcoming song.**`

    );

    return message.reply({ embeds: [emb] }).catch(() => {});

  },

};