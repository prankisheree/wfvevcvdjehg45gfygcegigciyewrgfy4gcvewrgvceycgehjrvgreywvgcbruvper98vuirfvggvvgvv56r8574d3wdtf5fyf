module.exports = (client) => {

  process.on("unhandledRejection", async (reason, promise) => {

    console.error("Unhandled Rejection:", reason);

    if (reason && reason.message && reason.message.includes("voice connection is not established")) {

      console.log("Voice connection timeout detected. Attempting recovery.");

      const playerMap = client.manager.players;

      for (const [guildId, player] of playerMap) {

        try {

          console.log(`Destroying player in guild ${guildId} due to connection failure.`);

          const currentTrack = player.queue.current;

          await player.destroy();

          setTimeout(async () => {

            const newPlayer = await client.manager.createPlayer({

              guildId,

              voiceId: player.voiceId,

              textId: player.textId,

              deaf: true,

            });

            if (currentTrack) {

              newPlayer.queue.add(currentTrack);

              newPlayer.play();

              console.log(`Player restarted and resumed in guild ${guildId}`);

            }

          }, 3000);

        } catch (err) {

          console.error(`Failed to recover player in guild ${guildId}:`, err);

        }

      }

    }

  });

};