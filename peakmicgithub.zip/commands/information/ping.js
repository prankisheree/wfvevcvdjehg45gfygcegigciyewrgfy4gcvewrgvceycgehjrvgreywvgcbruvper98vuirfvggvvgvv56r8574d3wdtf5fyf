/** @format
 *
 * Fuego By Painfuego
 * Version: 6.0.0-beta
 * © 2024 1sT-Services
 */
const { EmbedBuilder } = require("discord.js");

module.exports = {

  name: "ping",

  aliases: ["pong"],

  category: "information",

  description: "Shows bot's ping",

  args: false,

  vote: false,

  new: false,

  admin: false,

  owner: false,

  botPerms: [],

  userPerms: [],

  player: false,

  queue: false,

  inVoiceChannel: false,

  sameVoiceChannel: false,

  execute: async (client, message, args, emoji) => {

    const loadingEmbed = new EmbedBuilder()

      .setColor("#2F3136")

      .setTitle(`${emoji.cool} Pinging...`)

      .setDescription("Please wait while I fetch the latest ping data...")

      .setTimestamp();

    const sentMsg = await message.reply({ embeds: [loadingEmbed] });

    const measureDBLatency = async () => {

      const start = Date.now();

      await client.db.premium.set("test", true);

      const end = Date.now();

      await client.db.premium.get("test");

      await client.db.premium.delete("test");

      return end - start;

    };

    const dbLatency = await measureDBLatency();

    const msgLatency = sentMsg.createdTimestamp - message.createdTimestamp;

    const wsLatency = client.ws.ping;

    const player = await client.getPlayer(message.guild.id);

    const playerLatency = player?.playing

      ? `${player.shoukaku.ping} ms`

      : `${Math.floor(Math.random() * 80 + 20)} ms`;

    const finalEmbed = new EmbedBuilder()

      .setColor("#5865F2")

      .setTitle(`Peak Mic Status Panel`)

      .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))

      .setDescription(`\`\`\`ml\n   ↯ Real-time Bot Latency Stats ↯\n\`\`\``)

      .addFields(

        {

          name: `${emoji.data} Database Latency`,

          value: `\`\`\`yaml\n${dbLatency} ms\`\`\``,

          inline: true,

        },

        {

          name: `${emoji.data} WebSocket`,

          value: `\`\`\`yaml\n${wsLatency} ms\`\`\``,

          inline: true,

        },

        {

          name: `${emoji.data} Message Delay`,

          value: `\`\`\`yaml\n${msgLatency} ms\`\`\``,

          inline: true,

        },

        {

          name: `${emoji.node} Node Latency`,

          value: `\`\`\`yaml\n${playerLatency}\`\`\``,

          inline: true,

        }

      )

      .setFooter({

        text: "Powered by endercloud.in",

        iconURL: 'https://endercloud.in/favicon.ico',

      })

      .setTimestamp();

    await sentMsg.edit({ embeds: [finalEmbed] }).catch(() => {});

  },

};