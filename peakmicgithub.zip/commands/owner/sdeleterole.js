const { EmbedBuilder, PermissionFlagsBits } = require("discord.js");

module.exports = {

  name: "sdeleterole",

  aliases: ["superdeleterole"],

  category: "owner",

  usage: "sremoverole {role ID}",

  description: "Forcefully deletes a role by its ID. Only bot owners can use this.",

  args: true,

  botPerms: ["ManageRoles"],

  userPerms: [],

  owner: true,

  execute: async (client, message, args) => {

    // Define emojis

    const noEmoji = "<a:emoji_4:1309094791950372965>";

    const successEmoji = "<:emoji_35:1319658695985987624>";

    const roleEmoji = "<:chudgyeguru:1357998308643045488>";

    try {

      // ✅ Bot owners list

      const botOwners = ["1207080102974980136", "1107521454049857627", "1112710796229742652"];

      // ✅ Ensure user is a bot owner

      if (!botOwners.includes(message.author.id.toString())) {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **Only bot owners can use this command!**`);

        return message.reply({ embeds: [embed] });

      }

      // ✅ Get role ID and fetch role

      const roleId = args[0];

      const role = message.guild.roles.cache.get(roleId);

      if (!role) {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **No role found with the provided ID.**`);

        return message.reply({ embeds: [embed] });

      }

      // ✅ Check if role is higher than bot

      const botTopRole = message.guild.members.me.roles.highest;

      if (role.position >= botTopRole.position) {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **I cannot delete this role because it is higher than or equal to my highest role.**`);

        return message.reply({ embeds: [embed] });

      }

      // ✅ Delete the role

      await role.delete(`Deleted by ${message.author.tag}`);

      // ✅ Success embed

      const successEmbed = new EmbedBuilder()

        .setAuthor({ name: "Role Deleted", iconURL: message.author.displayAvatarURL({ dynamic: true }) })

        .setDescription(

          `> ${successEmoji} **Role Deleted:** \`${role.name}\` (${roleId})\n` +

          `> ${roleEmoji} **Deleted By:** ${message.author}`

        )

        .setFooter({ text: `Moderation by ${message.author.tag}` })

        .setColor("#fb5984");

      return message.reply({ embeds: [successEmbed] });

    } catch (error) {

      console.error("Error executing sremoverole command:", error);

      const errorEmbed = new EmbedBuilder()

        .setColor("#fb5984")

        .setDescription(`${noEmoji} **An error occurred while deleting the role. Please try again later!**`);

      return message.reply({ embeds: [errorEmbed] });

    }

  },

};