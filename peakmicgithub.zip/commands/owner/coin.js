module.exports = {
  name: "coin",
  aliases: [],
  cooldown: "",
  category: "owner",
  usage: "<add/rem/reset> <mention> <amount>",
  description: "Add static",
  args: true,
  vote: false,
  new: false,
  admin: true,
  owner: true,
  botPerms: [],
  userPerms: [],
  player: false,
  queue: false,
  inVoiceChannel: false,
  sameVoiceChannel: false,
  execute: async (client, message, args, emoji) => {
    // Ensure at least 3 arguments are provided
    if (args.length < 3) {
      return await message.reply({
        embeds: [
          new client.embed().desc(
            `${emoji.no} **Invalid syntax! Use: ${this.usage}**`
          ),
        ],
      });
    }

    // Extract user ID and validate user
    const id = message.mentions.users.first()?.id || args[1];
    const validUser = await client.users.fetch(id).catch(() => null);

    if (!validUser) {
      return await message.reply({
        embeds: [
          new client.embed().desc(`${emoji.no} **Invalid/No User provided**`),
        ],
      });
    }

    // Parse task and amount
    const task = args[0].toLowerCase();
    const amount = parseInt(args[2]);

    // Validate amount
    if (isNaN(amount) || amount <= 0) {
      return await message.reply({
        embeds: [
          new client.embed().desc(`${emoji.no} **Invalid/No amount provided**`),
        ],
      });
    }

    // Fetch current coins
    const currentCoins = parseInt((await client.db.coins.get(`${id}`)) || 0);
    let total = currentCoins;

    // Process task
    if (task === "add") {
      total += amount;
    } else if (task === "rem") {
      total -= amount;
    } else if (task === "reset") {
      total = 0;
    } else {
      return await message.reply({
        embeds: [
          new client.embed().desc(`${emoji.no} **Invalid task provided**`),
        ],
      });
    }

    // Update database and reply
    await client.db.coins.set(`${validUser.id}`, total);
    await message.reply({
      embeds: [
        new client.embed().desc(
          `${emoji.yes} **Operation successful**\n` +
            `${emoji.coin} Total coins for ${validUser} is \`${total}\``
        ),
      ],
    });
  },
};