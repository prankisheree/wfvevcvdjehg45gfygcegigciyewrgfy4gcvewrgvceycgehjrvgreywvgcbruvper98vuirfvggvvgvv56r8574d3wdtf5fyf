/** @format

 *

 * Ban Command for Peak Mic

 * Category: Moderation

 */

const { EmbedBuilder } = require("discord.js");

module.exports = {

  name: "ban",

  aliases: [],

  category: "moderation",

  usage: "ban {user} {duration(optional)} {reason}",

  description: "Ban a user permanently or for a specified duration with a reason.",

  args: true,

  botPerms: ["BanMembers"],

  userPerms: ["BanMembers"],

  execute: async (client, message, args) => {

    // Define emojis

    const noEmoji = "<a:emoji_4:1309094791950372965>";

    const dmSentEmoji = "<:emoji_59:1336350120601718887>";

    const dmFailedEmoji = "<:emoji_59:1336350103455268954>";

    const reasonEmoji = "<a:emoji_61:1336350683384778773>";

    const timeEmoji = "<:emoji_61:1336350701252640899>";

    const responsibleEmoji = "<:emoji_20:1309926239804592300>";

    const successEmoji = "<:emoji_35:1319658695985987624>";

    try {

      // Get the target member

      const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);

      if (!member) {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **Please mention a valid member to ban.**`);

        return message.reply({ embeds: [embed] });

      }

      // Check role hierarchy (skip if author is server owner)

      if (

        message.guild.ownerId !== message.author.id &&

        member.roles.highest.position >= message.member.roles.highest.position

      ) {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **You cannot ban this member.**`);

        return message.reply({ embeds: [embed] });

      }

      if (!member.bannable) {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **I don't have permission to ban this member.**`);

        return message.reply({ embeds: [embed] });

      }

      let duration = null;

      if (args[1] && !isNaN(args[1])) {

        duration = parseInt(args[1]) * 1000; // Convert seconds to milliseconds

      }

      let reason = args.slice(duration ? 2 : 1).join(" ") || "No reason provided.";

      // DM embed

      let dmSent = true;

      const dmEmbed = new EmbedBuilder()

        .setAuthor({ name: "You have been banned!", iconURL: member.user.displayAvatarURL({ dynamic: true }) })

        .setDescription(

          `> ${timeEmoji} **Duration:** ${duration ? `${duration / 1000} seconds` : "Permanent"}\n` +

          `> ${reasonEmoji} **Reason:** ${reason}\n` +

          `> ${responsibleEmoji} **Responsible:** ${message.author.username}\n` +

          `> **Server:** ${message.guild.name}`

        )

        .setFooter({ text: "Contact a moderator if you have questions." })

        .setColor("#FF0000");

      try {

        await member.send({ embeds: [dmEmbed] });

      } catch {

        dmSent = false;

      }

      // Ban the user

      await member.ban({ reason }).catch(() => {

        const embed = new EmbedBuilder()

          .setColor("#fb5984")

          .setDescription(`${noEmoji} **Failed to ban the member.**`);

        return message.reply({ embeds: [embed] });

      });

      // Confirmation embed

      const confirmationEmbed = new EmbedBuilder()

        .setAuthor({ name: "User Banned", iconURL: member.user.displayAvatarURL({ dynamic: true }) })

        .setDescription(

          `> ${successEmoji} **Banned:** ${member}\n` +

          `> ${timeEmoji} **Duration:** ${duration ? `${duration / 1000} seconds` : "Permanent"}\n` +

          `> ${reasonEmoji} **Reason:** ${reason}\n` +

          `> ${responsibleEmoji} **Responsible:** ${message.author.username}\n\n` +

          `> **DM Status:** ${dmSent ? `${dmSentEmoji} Sent` : `${dmFailedEmoji} Failed`}`

        )

        .setFooter({ text: `Moderation by ${message.author.tag}` })

        .setColor("#fb5984");

      // Send embed response

      await message.reply({ embeds: [confirmationEmbed] });

      // If duration is provided, schedule an unban

      if (duration) {

        setTimeout(async () => {

          await message.guild.members.unban(member.id).catch(() => null);

        }, duration);

      }

    } catch (error) {

      console.error("Error executing ban command:", error);

      const errorEmbed = new EmbedBuilder()

        .setColor("#fb5984")

        .setDescription(`${noEmoji} **An error occurred while banning the user. Please try again later!**`);

      message.reply({ embeds: [errorEmbed] });

    }

  },

};