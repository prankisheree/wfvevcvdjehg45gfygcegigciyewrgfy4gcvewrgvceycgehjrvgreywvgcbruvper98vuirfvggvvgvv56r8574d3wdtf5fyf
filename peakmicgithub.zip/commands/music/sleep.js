const { ActionRowBuilder } = require("discord.js");
const ms = require("ms");

module.exports = {
  name: "sleep",
  aliases: ["sl"],
  cooldown: "",
  category: "music",
  usage: "<time | remove>",
  description: "Set a timer to stop music or remove an existing timer",
  args: true,
  vote: false,
  new: false,
  admin: false,
  owner: false,
  botPerms: [],
  userPerms: [],
  player: true,
  queue: true,
  inVoiceChannel: true,
  sameVoiceChannel: true,
  execute: async (client, message, args, emoji = {}) => {
    const clockEmoji = emoji.clock || "<:emoji_61:1336350701252640899>";
    const checkEmoji = emoji.check || "<:emoji_1:1309093521357013022>";
    const crossEmoji = emoji.cross || "<a:emoji_4:1309094791950372965>";
    const stopEmoji = emoji.stop || "<:emoji_22:1309927196395048991>";
    const noEmoji = emoji.no || "<a:emoji_5:1309094939841269760>";

    const player = await client.getPlayer(message.guild.id);
    const input = args[0]?.toLowerCase();

    if (!input) {
      return message.reply({
        embeds: [
          new client.embed().desc(
            `${noEmoji} **You need to provide a valid time (e.g., \`10m\`, \`2h\`) or use \`remove\` to cancel the sleep.**`
          ),
        ],
      });
    }

    // Handle removing sleep
    if (input === "remove") {
      if (!player.sleepTimeout) {
        return message.reply({
          embeds: [
            new client.embed().desc(
              `${noEmoji} **There is no active sleep timer to remove.**`
            ),
          ],
        });
      }

      player.sleepTimeout = null;
      return message.reply({
        embeds: [
          new client.embed().desc(
            `${checkEmoji} **Sleep timer has been successfully removed!**`
          ),
        ],
      });
    }

    // Handle setting sleep
    if (!/^\d+[smhd]$/.test(input)) {
      return message.reply({
        embeds: [
          new client.embed().desc(
            `${noEmoji} **Invalid input! Please provide a valid time duration (e.g., \`10m\`, \`2h\`).**`
          ),
        ],
      });
    }

    const time = ms(input);
    const maxTime = ms("6h");

    if (!time || time <= 0) {
      return message.reply({
        embeds: [
          new client.embed().desc(
            `${noEmoji} **Invalid time format. Use something like \`10m\` or \`2h\`.**`
          ),
        ],
      });
    }

    if (time > maxTime) {
      return message.reply({
        embeds: [
          new client.embed().desc(
            `${noEmoji} **The maximum time limit is \`6 hours\`. Please specify a shorter duration.**`
          ),
        ],
      });
    }

    if (player.sleepTimeout) {
      const remainingTime = ms(player.sleepTimeout - Date.now(), { long: true });
      return message.reply({
        embeds: [
          new client.embed().desc(
            `${clockEmoji} **Sleep mode is already active! Music will stop in \`${remainingTime}\`.**`
          ),
        ],
      });
    }

    const confirmationEmbed = new client.embed().desc(
      `${clockEmoji} **Music will stop playing after \`${input}\`. Do you want to confirm this?**`
    );

    const row = new ActionRowBuilder().addComponents(
      new client.button().success("confirm", "Confirm", checkEmoji),
      new client.button().danger("cancel", "Cancel", crossEmoji)
    );

    const m = await message.reply({
      embeds: [confirmationEmbed],
      components: [row],
    });

    const filter = (interaction) => interaction.user.id === message.author.id;
    const collector = m.createMessageComponentCollector({ filter, time: 30000 });

    collector.on("collect", async (interaction) => {
      if (!interaction.deferred) interaction.deferUpdate();

      if (interaction.customId === "confirm") {
        const endTime = Date.now() + time;
        player.sleepTimeout = endTime;

        message.channel.send(
          `${clockEmoji} **Timer started! Music will stop in \`${input}\`.**`
        );

        // Set 30-second warning
        setTimeout(() => {
          if (player && player.sleepTimeout === endTime) {
            const warningEmbed = new client.embed().desc(
              `${clockEmoji} **Music will stop playing in 30 seconds. Do you want to continue?**`
            );

            const warningRow = new ActionRowBuilder().addComponents(
              new client.button().success("continue", "Yes", checkEmoji),
              new client.button().danger("stop", "No", crossEmoji)
            );

            message.channel
              .send({
                embeds: [warningEmbed],
                components: [warningRow],
              })
              .then((warningMsg) => {
                const warningCollector = warningMsg.createMessageComponentCollector({
                  filter,
                  time: 30000,
                });

                warningCollector.on("collect", async (warningInteraction) => {
                  if (!warningInteraction.deferred) warningInteraction.deferUpdate();

                  if (warningInteraction.customId === "continue") {
                    player.sleepTimeout = null;
                    message.channel.send(
                      `${checkEmoji} **Sleep timer cancelled. Music will continue playing.**`
                    );
                  } else if (warningInteraction.customId === "stop") {
                    if (player.stop) player.stop();
                    else if (player.destroy) player.destroy();

                    player.sleepTimeout = null;
                    message.channel.send(
                      `${stopEmoji} **Music has been stopped as per the sleep timer.**`
                    );
                  }

                  warningCollector.stop();
                });
              })
              .catch(console.error); // Log errors
          }
        }, time - 30000);

        // Set final stop timeout
        setTimeout(() => {
          if (player && player.sleepTimeout === endTime) {
            if (player.stop) player.stop();
            else if (player.destroy) player.destroy();

            player.sleepTimeout = null;
            message.channel.send(
              `${stopEmoji} **Music has been stopped as per the sleep command.**`
            );
          }
        }, time);
      } else if (interaction.customId === "cancel") {
        message.channel.send(`${crossEmoji} **Sleep command cancelled.**`);
      }

      collector.stop();
    });

    collector.on("end", (_, reason) => {
      if (reason === "time") {
        m.edit({
          embeds: [
            new client.embed().desc(
              `${coolEmoji} **Timed out! No action was taken.**`
            ),
          ],
          components: [],
        });
      }
    });
  },
};